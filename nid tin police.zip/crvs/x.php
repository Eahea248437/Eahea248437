<?php
// Function to fetch the token
function getToken() {
    // URL to fetch the token
    $url = 'http://govbd.top/crvs/auth.json';

    // Initialize cURL session
    $ch = curl_init();
    
    // Disable SSL verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    // Set the URL
    curl_setopt($ch, CURLOPT_URL, $url);
    
    // Return the response as a string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the GET request
    $response = curl_exec($ch);

    // Check if cURL execution failed
    if (curl_errno($ch)) {
        echo 'cURL Error: ' . curl_error($ch);
        return null;
    }

    // Decode the JSON response
    $data = json_decode($response, true);

    // Close the cURL session
    curl_close($ch);

    // Return the token if it exists
    return isset($data['token']) ? $data['token'] : null;
}

// Function to make a request with the token
function makeRequestWithToken($nid, $dob) {
    $token = getToken();

    if (!$token) {
        echo 'Failed to obtain token.';
        return;
    }

    // Initialize cURL session
    $ch = curl_init();
    
    // Disable SSL verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    // Set the URL and POST data
    curl_setopt($ch, CURLOPT_URL, 'https://crvs.dpe.gov.bd/thirdparty/nid/getNIDInfo');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "nid10Digit" => $nid,
        "dateOfBirth" => $dob
    ]));

    // Set headers
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $token,
        'Content-Type: application/json',
        'Accept: application/json, text/plain, */*',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.120 Safari/537.36',
        'Origin: https://crvs.dpe.gov.bd',
        'Referer: https://crvs.dpe.gov.bd/'
    ]);

    // Return the response as a string
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute the POST request
    $response = curl_exec($ch);

    // Check if cURL execution failed
    if (curl_errno($ch)) {
        echo 'cURL Error: ' . curl_error($ch);
    } else {
        // Output the response
        header('Content-Type: application/json');
        echo $response;
    }

    // Close the cURL session
    curl_close($ch);
}

// Check if `nid` and `dob` parameters are set in the query string
if (isset($_GET['nid']) && isset($_GET['dob'])) {
    $nid = $_GET['nid'];
    $dob = $_GET['dob'];
    
    // Make the request with the token
    makeRequestWithToken($nid, $dob);
} else {
    echo 'Error: Missing `nid` or `dob` parameter.';
}
?>
