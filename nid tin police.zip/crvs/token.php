<?php
// Initialize cURL session
$ch = curl_init();
// Disable SSL verification
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

// Set the URL and POST data
curl_setopt($ch, CURLOPT_URL, 'https://crvs.dpe.gov.bd/core/login/token/generate-token');
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
    "userName" => "01725421802",
    "userPassword" => "Afroja82%",
    "branchID" => 1,
    "companyID" => 1
]));

// Set headers
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json, text/plain, */*',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.120 Safari/537.36',
    'Origin: https://crvs.dpe.gov.bd',
    'Referer: https://crvs.dpe.gov.bd/'
]);

// Return the response as a string
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the POST request
$response = curl_exec($ch);

// Check if cURL execution failed
if (curl_errno($ch)) {
    echo 'cURL Error: ' . curl_error($ch);
} else {
    // Decode the JSON response
    $data = json_decode($response, true);

    // Check if the token exists and is valid
    if (isset($data['token']['token'])) {
        $token = $data['token']['token'];
        echo "Token: " . $token . "\n";
        
        // Create an array to store the token in JSON format
        $tokenData = [
            'token' => $token
        ];

        // Convert the array to JSON
        $jsonToken = json_encode($tokenData, JSON_PRETTY_PRINT);

        // Write the token to auth.json file
        file_put_contents('auth.json', $jsonToken);

        echo "Token successfully stored in auth.json\n";
    } else {
        echo "Failed to obtain token.\n";
    }
}

// Close the initial cURL session
curl_close($ch);
