<?php

function perform_request($url, $follow_redirects = false) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $follow_redirects);
    $response = curl_exec($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($response, 0, $header_size);
    $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cookies = [];
    foreach (explode("\n", $header) as $line) {
        if (strpos($line, 'Set-Cookie:') === 0) {
            $cookie = substr($line, 11);
            $cookie = explode(';', $cookie)[0]; 
            $cookies[] = $cookie;
        }
    }
    curl_close($ch);
    return [$status_code, $header, $cookies];
}

function extract_hidden_inputs($html) {
    if (empty($html)) {
        throw new Exception('HTML content is empty.');
    }

    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    $inputs = $doc->getElementsByTagName('input');
    $result = [];
    foreach ($inputs as $input) {
        if ($input->getAttribute('type') === 'hidden') {
            $result[$input->getAttribute('id')] = $input->getAttribute('value');
        }
    }
    return $result;
}

// Step 1: Perform the initial request
list($status_code, $header, $cookies) = perform_request('https://cdms.police.gov.bd/cdms/f?p=105');

if ($status_code == 302) {
    preg_match_all('/^Location:\s*(.*)$/mi', $header, $matches);
    if (isset($matches[1][0])) {
        $location = trim($matches[1][0]);
        $url = 'https://cdms.police.gov.bd/cdms/' . $location;
        list($status_code, $header, $cookies) = perform_request($url);

        if ($status_code == 302) {
            preg_match_all('/^Location:\s*(.*)$/mi', $header, $matches);
            if (isset($matches[1][0])) {
                $second_location = trim($matches[1][0]);
                $final_url = 'https://cdms.police.gov.bd/cdms/' . $second_location;
                
                $ch = curl_init($final_url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_COOKIE => implode('; ', $cookies),
                ]);
                $response = curl_exec($ch);
                curl_close($ch);

                // Check if the response is empty
                if (empty($response)) {
                    echo json_encode(['error' => 'No HTML content received from the server.']);
                    exit;
                }

                $hidden_inputs = extract_hidden_inputs($response);
                $cookies_string = implode('; ', $cookies);

                $result = array_merge($hidden_inputs, ['cookies' => $cookies_string]);

                header('Content-Type: application/json');
                echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
                exit;
            }
        }
    }
}

// Step 2: Handle the POST request with the extracted data
$initialCurl = curl_init();
curl_setopt_array($initialCurl, [
    CURLOPT_URL => 'Bypass.php',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Accept: application/json']
]);
$initialResponse = curl_exec($initialCurl);
curl_close($initialCurl);

$data = json_decode($initialResponse, true);

if (!isset($data['pFlowId'])) {
    echo json_encode(['error' => 'Failed to retrieve flow ID.']);
    exit;
}

$curl = curl_init();
$postFields = http_build_query([
    'p_flow_id' => $data['pFlowId'],
    'p_flow_step_id' => $data['pFlowStepId'],
    'p_instance' => $data['pInstance'],
    'p_page_submission_id' => $data['pPageSubmissionId'],
    'p_request' => $data['pRequest'],
    'p_reload_on_submit' => $data['pReloadOnSubmit'],
    'p_json' => json_encode([
        'salt' => $data['pSalt'],
        'pageItems' => [
            'itemsToSubmit' => [
                ['n' => 'P0_IP', 'v' => $data['P0_IP']],
                ['n' => 'P0_G_IP', 'v' => $data['P0_G_IP']],
                ['n' => 'P0_CURR_URL', 'v' => $data['P0_CURR_URL']],
                ['n' => 'P101_USERNAME', 'v' => '7997030154'],
                ['n' => 'P101_PASSWORD', 'v' => 'Baba665#'],
                ['n' => 'P101_TOTAL_LOGIN_USER', 'v' => $data['P101_TOTAL_LOGIN_USER']],
                ['n' => 'P101_CLINT_IP', 'v' => $data['P101_CLINT_IP']],
                ['n' => 'P101_OTP_FLAG', 'v' => $data['P101_OTP_FLAG']],
            ],
            'protected' => $data['pPageItemsProtected'],
            'rowVersion' => $data['pPageItemsRowVersion'],
        ],
    ]),
]);

curl_setopt_array($curl, [
    CURLOPT_URL => 'https://cdms.police.gov.bd/cdms/wwv_flow.accept',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $postFields,
    CURLOPT_COOKIE => $data['cookies'],
    CURLOPT_HEADER => true,
    CURLOPT_HTTPHEADER => [
        'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
        'Content-Type: application/x-www-form-urlencoded',
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

if ($err) {
    curl_close($curl);
    echo json_encode(['error' => 'cURL Error #:' . $err]);
    exit;
}

curl_close($curl);

echo $response;

?>
