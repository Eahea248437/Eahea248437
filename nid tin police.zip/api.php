<?php
header('Content-Type: application/json; charset=UTF-8');

// Initialize cURL and cookie handling
$cookieFile = tempnam(sys_get_temp_dir(), 'cookie');
$ch = curl_init();
$initial_url = "https://ibas.finance.gov.bd/acs/general/sales";
curl_setopt($ch, CURLOPT_URL, $initial_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);

// Execute the initial request
$response = curl_exec($ch);

// Extract XSRF token
preg_match('/<input[^>]*name="__RequestVerificationToken"[^>]*value="([^"]*)"/i', $response, $matches);
$xsrf_token = $matches[1] ?? null;

if (!$xsrf_token) {
    echo json_encode(['error' => 'X-Xsrf-Token not found'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Get NID and DOB from the request
$nid = $_GET['nid'] ?? '';
$dob = $_GET['dob'] ?? '';
if (!$nid || !$dob) {
    echo json_encode(['error' => 'NID and DOB are required parameters.'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$retry = 0;
$max_retry = 1;

do {
    // Step 1: Validate NID
    $url_1 = "https://ibas.finance.gov.bd/acs/general/NidValidate";
    $data_1 = json_encode(["nationalId" => $nid, "dob" => $dob]);
    $headers = [
        "X-Xsrf-Token: $xsrf_token",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.100 Safari/537.36",
        "Content-Type: application/json",
        "Accept: */*",
        "X-Requested-With: XMLHttpRequest",
        "Origin: https://ibas.finance.gov.bd",
        "Referer: https://ibas.finance.gov.bd/acs/general/sales"
    ];
    curl_setopt($ch, CURLOPT_URL, $url_1);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response_1 = curl_exec($ch);

    // Step 2: Submit Challan Data
    $url_2 = "https://ibas.finance.gov.bd/acs/general/SaveClientData";
    $data_2 = json_encode([
        "challanData" => [
            "ChallanTypeId" => "33",
            "OrganaizationId" => "127632255",
            "ClientTypeId" => 2,
            "NID" => $nid,
            "PersonIdentityTypeId" => 1,
            "MobileNo" => "01711661954",
            "Economic" => [
                ["EconomicId" => "193", "Amount" => "3500.00"],
                ["EconomicId" => "143", "Amount" => "525.00"]
            ],
            "CashCheque" => [
                ["AmountTypeId" => "6", "Amount" => 4025]
            ],
            "IsDraft" => true
        ]
    ]);
    curl_setopt($ch, CURLOPT_URL, $url_2);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_2);

    $response_2 = curl_exec($ch);

    $save_client_data = json_decode($response_2, true);
    $retry++;
} while (!isset($save_client_data[0]['CLIENT_DOB']) && $retry < $max_retry);

// Close cURL and clean up
curl_close($ch);
unlink($cookieFile);

// Process final result
if (isset($save_client_data[0])) {
    // Mapping fields
    $mapped_fields = [
        "nameBangla" => "CLIENT_NAME_BN",
        "nameEnglish" => "CLIENT_NAME_EN",
        "nationalId" => "CLIENT_SMART_NID_NO",
        "dateOfBirth" => "CLIENT_DOB",
        "pin" => "CLIENT_NID_NO"
    ];

    $mapped_data = [];
    foreach ($mapped_fields as $key => $value) {
        if (isset($save_client_data[0][$value])) {
            if ($key === "dateOfBirth") {
                $date = new DateTime($save_client_data[0][$value]);
                $mapped_data[$key] = $date->format('d M Y');
            } else {
                $mapped_data[$key] = $save_client_data[0][$value];
            }
        }
    }

    // Parse address
    function parse_address($address) {
        $parts = explode(", ", $address);
        $address_parts = [
            "HomeOrHoldingNo" => "",
            "AdditionalVillageOrRoad" => "",
            "PostOffice" => "",
            "Upozila" => "",
            "District" => "",
            "Division" => ""
        ];
        foreach ($parts as $part) {
            if (strpos($part, 'বাসা/হোল্ডিং: ') === 0) {
                $address_parts["HomeOrHoldingNo"] = substr($part, strlen('বাসা/হোল্ডিং: '));
            } elseif (strpos($part, 'গ্রাম/রাস্তা: ') === 0) {
                $address_parts["AdditionalVillageOrRoad"] = substr($part, strlen('গ্রাম/রাস্তা: '));
            } elseif (strpos($part, 'ডাকঘর: ') === 0) {
                $address_parts["PostOffice"] = substr($part, strlen('ডাকঘর: '));
            } elseif (strpos($part, 'উপজেলা: ') === 0) {
                $address_parts["Upozila"] = substr($part, strlen('উপজেলা: '));
            } elseif (strpos($part, 'জেলা: ') === 0) {
                $address_parts["District"] = substr($part, strlen('জেলা: '));
            } elseif (strpos($part, 'বিভাগ: ') === 0) {
                $address_parts["Division"] = substr($part, strlen('বিভাগ: '));
            }
        }
        return $address_parts;
    }

    $perm_address_parts = parse_address($save_client_data[0]['CLIENT_PERM_ADDRESS']);
    $curr_address_parts = parse_address($save_client_data[0]['CLIENT_CURR_ADDRESS']);
    $mapped_data = array_merge($mapped_data, [
        "presentHomeOrHoldingNo" => $curr_address_parts["HomeOrHoldingNo"],
        "presentAdditionalVillageOrRoad" => $curr_address_parts["AdditionalVillageOrRoad"],
        "presentPostOffice" => $curr_address_parts["PostOffice"],
        "presentUpozila" => $curr_address_parts["Upozila"],
        "presentDistrict" => $curr_address_parts["District"],
        "presentDivision" => $curr_address_parts["Division"],
        "permanentHomeOrHoldingNo" => $perm_address_parts["HomeOrHoldingNo"],
        "permanentAdditionalVillageOrRoad" => $perm_address_parts["AdditionalVillageOrRoad"],
        "permanentPostOffice" => $perm_address_parts["PostOffice"],
        "permanentUpozila" => $perm_address_parts["Upozila"],
        "permanentDistrict" => $perm_address_parts["District"],
        "permanentDivision" => $perm_address_parts["Division"]
    ]);

    echo json_encode($mapped_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['error' => 'Failed to retrieve data after maximum retries.'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
?>