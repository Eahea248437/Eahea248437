<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the posted data
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input['nid']) && isset($input['dob'])) {
        $nid = $input['nid'];
        $dob = $input['dob'];

        // API request to get data
        $api_url = "http://govbd.top/Police.php?nid=$nid&dob=$dob";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        curl_close($ch);

        if ($response) {
            // Return the response in JSON format
            header('Content-Type: application/json');
            echo $response;
        } else {
            echo json_encode(['error' => 'No data found for the given NID and DOB.']);
        }
    } else {
        echo json_encode(['error' => 'Invalid request.']);
    }
}
?>
