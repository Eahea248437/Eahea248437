<?php
// Login and subsequent request URLs
$loginUrl = 'https://secure.incometax.gov.bd/Registration/Login';
$tinhomeUrl = 'https://secure.incometax.gov.bd/TINHome';

// Login credentials
$data = http_build_query([
    'LOGON_NAME' => 'tc42dhaka',  // Replace with your username
    'LOGON_PASS' => 'deputy42'    // Replace with your password
]);

// Headers for the request
$headers = [
    'Content-Type: application/x-www-form-urlencoded',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.120 Safari/537.36',
    'Origin: https://secure.incometax.gov.bd',
    'Referer: https://secure.incometax.gov.bd/Registration/Login',
    'Accept-Encoding: gzip, deflate, br',
];

// Initialize cURL session for login
$ch = curl_init();

// Set cURL options for login
curl_setopt($ch, CURLOPT_URL, $loginUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true); // Capture headers to extract cookies
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false); // Manual redirect handling

// Execute the POST request (login)
$response = curl_exec($ch);

// Separate headers and body
list($headerContent, $bodyContent) = explode("\r\n\r\n", $response, 2);

// Extract cookies from the headers
preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $headerContent, $matches);
$cookies = [];
foreach ($matches[1] as $cookie) {
    parse_str($cookie, $tempCookie);
    $cookies = array_merge($cookies, $tempCookie);
}

// Store cookies in auth.json
file_put_contents('auth.json', json_encode($cookies, JSON_PRETTY_PRINT));

// Convert cookies to a string format for further requests
$cookieString = '';
foreach ($cookies as $key => $value) {
    $cookieString .= "$key=$value; ";
}

// Close the cURL session
curl_close($ch);

echo "Login successful. Cookies stored in auth.json.\n";

// Initialize a new cURL session to access /TINHome using stored cookies
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $tinhomeUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge($headers, [
    "Cookie: $cookieString"
]));
$responseTINHome = curl_exec($ch);
curl_close($ch);

// Display TINHome page response
echo "TINHome Page Response: \n" . $responseTINHome . "\n";

// Optionally, print the cookies for confirmation
echo "Stored Cookies: \n";
echo json_encode($cookies, JSON_PRETTY_PRINT);
?>
