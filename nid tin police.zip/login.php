<?php
// Fetch payload and cookies from govbd.top
$apiData = [
    'pFlowId' => '105',
    'pFlowStepId' => '101',
    'pInstance' => '11869705620124',
    'pPageSubmissionId' => '214243408759511728443473151661301701023',
    'pRequest' => '',
    'pReloadOnSubmit' => 'A',
    'pSalt' => '214243408759511728443473151661301701023',
    'P0_IP' => '',
    'P0_G_IP' => '103.98.77.12',
    'P0_CURR_URL' => 'CDMS',
    'P101_TOTAL_LOGIN_USER' => '',
    'P101_CLINT_IP' => '',
    'P101_OTP_FLAG' => '',
    'pPageItemsRowVersion' => '',
    'pPageItemsProtected' => 'v1Qio3-TX7r88SuaitgSMw',
    'cookies' => 'ORA_WWV_APP_105=ORA_WWV-PK_VlmBkR_YqH8kCArmQ_61h'
];

// Fetching NID and DOB from GET request parameters
$nid = isset($_GET['nid']) ? trim($_GET['nid']) : '';
$dob = isset($_GET['dob']) ? trim($_GET['dob']) : '';

// Check if NID or DOB is missing
if (empty($nid) || empty($dob)) {
    echo json_encode(['error' => 'Enter NID and DOB'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Manually constructing itemsToSubmit
$itemsToSubmit = [
    [
        'n' => 'P600_NATIONALID',
        'v' => $nid
    ],
    [
        'n' => 'P600_DOB',
        'v' => $dob
    ]
];

// API URL for the POST request to the police server
$url_1 = 'https://cdms.police.gov.bd/cdms/wwv_flow.accept';

// Preparing POST data
$postFields = http_build_query([
    'p_flow_id' => 105,
    'p_flow_step_id' => 600,
    'p_instance' => $apiData['pInstance'],
    'p_debug' => '',
    'p_request' => 'Search_In_NID',
    'p_reload_on_submit' => 'S',
    'p_page_submission_id' => $apiData['pPageSubmissionId'],
    'p_json' => json_encode([
        'pageItems' => [
            'itemsToSubmit' => $itemsToSubmit,
            'protected' => $apiData['pPageItemsProtected'],
            'rowVersion' => $apiData['pPageItemsRowVersion']
        ],
        'salt' => $apiData['pSalt']
    ])
]);

// Request headers
$headers_1 = [
    'User-Agent: Mozilla/5.0 (Linux; Android 13; Infinix X6528 Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.103 Mobile Safari/537.36',
    'Accept: application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'sec-ch-ua: "Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
    'sec-ch-ua-platform: "Android"',
    'X-Requested-With: XMLHttpRequest',
    'sec-ch-ua-mobile: ?1',
    'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
    'Origin: https://cdms.police.gov.bd',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://cdms.police.gov.bd/cdms/f?p=105:600:14816587623995:::600::',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: ' . $apiData['cookies'] // Using the cookies from the fetched API data
];

// Initialize CURL for the POST request to the police server
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_1);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_VERBOSE, true); // Enable verbose mode for debugging

$response_1 = curl_exec($ch);

// Check for CURL errors
if (curl_errno($ch)) {
    echo json_encode(['error' => 'Curl error: ' . curl_error($ch)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    curl_close($ch);
    exit;
}

// Close CURL connection
curl_close($ch);

// Decode the response
$response_data = json_decode($response_1, true);

// Log the full response for debugging purposes
echo "<pre>";
print_r($response_data);
echo "</pre>";

// Extracting the redirect URL from the response
$redirectURL = $response_data['redirectURL'] ?? '';

// If no redirect URL is found, output an error message
if (empty($redirectURL)) {
    echo json_encode(['success' => false, 'message' => 'No redirect URL found'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Second CURL request to the redirect URL
$url_2 = 'https://cdms.police.gov.bd/cdms/' . $redirectURL . '::NO:::';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Request headers for the second request
$headers_2 = [
    'User-Agent: Mozilla/5.0 (Linux; Android 13; Infinix X6528 Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.103 Mobile Safari/537.36',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'sec-ch-ua: "Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'Upgrade-Insecure-Requests: 1',
    'dnt: 1',
    'X-Requested-With: mark.via.gp',
    'Sec-Fetch-Site: none',
    'Sec-Fetch-Mode: navigate',
    'Sec-Fetch-User: ?1',
    'Sec-Fetch-Dest: document',
    'Referer: https://cdms.police.gov.bd/cdms/f?p=105:600:14816587623995:::600::',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: ' . $apiData['cookies'] // Reuse the same cookies
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_2);
$response_2 = curl_exec($ch);

// Check for CURL errors in the second request
if (curl_errno($ch)) {
    echo json_encode(['error' => 'Curl error: ' . curl_error($ch)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo $response_2;
}

// Close CURL connection for the second request
curl_close($ch);
?>
