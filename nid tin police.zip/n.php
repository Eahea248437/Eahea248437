<?php
header('Content-Type: application/json');
function performCurlRequest($url, $postData = null, $headers = []) {
    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_POST => $postData !== null,
        CURLOPT_POSTFIELDS => $postData,
    ]);
    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);
    
    if ($err) {
        http_response_code(500);
        echo json_encode(['error' => $err], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }
    return json_decode($response, true);
}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $nid = $_GET['nid'] ?? '';
    $brn = $_GET['brn'] ?? '';
    $dob = $_GET['dob'] ?? '';
    if (!$dob || (!$nid && !$brn)) {
        http_response_code(400);
        exit;
    }
    $tokenResponse = performCurlRequest(
        'https://patient-hsms.somch.gov.bd/api/v1/authentication/patient/authenticate',
        '{"username":"01756144574","password":"sh341926"}',
        [
            'Content-Type: application/json',
            'Accept: application/json',
        ]
    );
    $accessToken = $tokenResponse['access_token'] ?? '';
    $postData = $nid ? ['nidOrBrn' => $nid, 'type' => 'nid', 'name' => 'name', 'dob' => $dob] : ['nidOrBrn' => $brn, 'type' => 'brn', 'name' => 'name', 'dob' => $dob];
    $patientResponse = performCurlRequest(
        'https://patient-hsms.somch.gov.bd/api/v1/registration/patient-reg-info-for-nid-verify',
        json_encode($postData),
        [
            'Content-Type: application/json',
            'Accept: application/json',
            "authorization: Bearer $accessToken",
        ]
    );
    $data = $patientResponse['data'] ?? [];
    $gender = $data['genderCode'] == 1 ? 'Male' : ($data['genderCode'] == 2 ? 'Female' : '');
    $dobFormatted = (new DateTime($data['dob'] ?? ''))->format('d M Y');
    $mappedResponse = [
        'nameEnglish' => $data['fullNameEnglishFromNidBrn'] ?? '',
        'nameBangla' => $data['fullNameBanglaFromNidBrn'] ?? '',
        'nationalId' => $data['citizenNidFromNidBrn'] ?? '',
        'brn' => $data['binBrnFromNidBrn'] ?? '',
        'dateOfBirth' => $dobFormatted,
        'gender' => $gender,
        'fatherName' => $data['fatherNameBanglaFromNidBrn'] ?? '',
        'fatherNameEn' => $data['fatherNameEnglishFromNidBrn'] ?? '',
        'motherName' => $data['motherNameBanglaFromNidBrn'] ?? '',
        'motherNameEn' => $data['motherNameEnglishFromNidBrn'] ?? '',
    ];
    if ($nid) {
        $ecsResponse = performCurlRequest(
            'http://apps.ecs.gov.bd/ec-user-app/api/v2/private/user-voter-area?election_schedule_id=110',
            json_encode(['dob' => $dob, 'search_value' => $nid]),
            [
                'Content-Type: application/json; charset=UTF-8',
                'secret-key: 6iM9eN0170i7yB972sH73qu73La97M4375T1R75zT'
            ]
        );
        if (isset($ecsResponse['nid_info'])) {
            $nidInfo = $ecsResponse['nid_info'];
            $mappedResponse = array_merge($mappedResponse, [
                'sl_no' => $nidInfo['sl_no'] ?? '',
                'voter_no' => $nidInfo['voter_no'] ?? '',
                'voterAreaCode' => isset($nidInfo['voter_no']) ? substr($nidInfo['voter_no'], 0, 6) : ''
            ]);
        } else {
            http_response_code(404);
            exit;
        }
    }
    $orderedResponse = [
        'nameEnglish' => $mappedResponse['nameEnglish'],
        'nameBangla' => $mappedResponse['nameBangla'],
        'brn' => $mappedResponse['brn'],
        'nationalId' => $mappedResponse['nationalId'],
        'voter_no' => $mappedResponse['voter_no'],
        'sl_no' => $mappedResponse['sl_no'],
        'voterAreaCode' => $mappedResponse['voterAreaCode'],
        'dateOfBirth' => $mappedResponse['dateOfBirth'],
        'gender' => $mappedResponse['gender'],
        'fatherName' => $mappedResponse['fatherName'],
        'fatherNameEn' => $mappedResponse['fatherNameEn'],
        'motherName' => $mappedResponse['motherName'],
        'motherNameEn' => $mappedResponse['motherNameEn']
    ];
    echo json_encode($orderedResponse, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    http_response_code(405);
    exit;
}
?>