<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NID Search</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .result {
            margin-top: 20px;
        }
        .result img {
            max-width: 150px;
            border-radius: 5px;
        }
        .result p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>NID Search</h1>
        <input type="text" id="nid" placeholder="Enter NID" required>
        <input type="date" id="dob" placeholder="Enter Date of Birth" required>
        <button id="searchBtn">Search</button>

        <div class="result" id="result"></div>
    </div>

    <script>
        document.getElementById('searchBtn').addEventListener('click', function() {
            const nid = document.getElementById('nid').value;
            const dob = document.getElementById('dob').value;

            if (nid && dob) {
                fetch('search.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ nid: nid, dob: dob })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        document.getElementById('result').innerHTML = `<p>${data.error}</p>`;
                    } else {
                        document.getElementById('result').innerHTML = `
                            <p><strong>Name (Bangla):</strong> ${data.nameBangla}</p>
                            <p><strong>Name (English):</strong> ${data.nameEnglish}</p>
                            <p><strong>Father's Name:</strong> ${data.fatherName}</p>
                            <p><strong>Mother's Name:</strong> ${data.motherName}</p>
                            <p><strong>Gender:</strong> ${data.gender}</p>
                            <p><strong>Present Address:</strong> ${data.presentVillageOrRoad}, ${data.presentPostOffice}, ${data.presentDistrict}, ${data.presentDivision}</p>
                            <p><strong>Permanent Address:</strong> ${data.permanentVillageOrRoad}, ${data.permanentPostOffice}, ${data.permanentDistrict}, ${data.permanentDivision}</p>
                            <img src="${data.photo}" alt="NID Photo">
                        `;
                    }
                })
                .catch(error => console.error('Error:', error));
            } else {
                alert('Please enter both NID and Date of Birth.');
            }
        });
    </script>
</body>
</html>
