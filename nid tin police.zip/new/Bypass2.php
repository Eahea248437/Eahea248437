<?php

// Fetch the API response
$apiUrl = 'https://govbd.top/new/Bypass1.php';
$apiResponse = file_get_contents($apiUrl);
$apiData = json_decode($apiResponse, true);

if (!$apiData || !isset($apiData['url']) || !isset($apiData['cookie'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Failed to retrieve API data']);
    exit;
}

$url = $apiData['url'];
$cookie = $apiData['cookie'];

// Perform the request using the URL and cookie from the API response
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_COOKIE => $cookie,
    CURLOPT_HTTPHEADER => [
        'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Encoding: gzip, deflate, br, zstd',
        'Cache-Control: max-age=0',
        'DNT: 1',
        'Upgrade-Insecure-Requests: 1',
        'Sec-Fetch-Site: same-origin',
        'Sec-Fetch-Mode: navigate',
        'Sec-Fetch-User: ?1',
        'Sec-Fetch-Dest: document',
        'sec-ch-ua: "Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"',
        'sec-ch-ua-mobile: ?0',
        'sec-ch-ua-platform: "Linux"',
        'Referer: ' . $url,
        'Accept-Language: en-US,en;q=0.9,yue-CN;q=0.8,yue;q=0.7,bn;q=0.6,ar;q=0.5,co;q=0.4',
    ],
]);

$htmlResponse = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    $errorData = ['error' => 'cURL Error: ' . $err];
    file_put_contents('Auth.json', json_encode($errorData));
    header('Content-Type: application/json');
    echo json_encode($errorData);
    exit;
}

// Parse the HTML and extract input fields
libxml_use_internal_errors(true);
$doc = new DOMDocument();
$doc->loadHTML($htmlResponse);
$xpath = new DOMXPath($doc);
$inputs = $xpath->query('//input');

$data = [];
foreach ($inputs as $input) {
    $name = $input->getAttribute('name');
    $id = $input->getAttribute('id');
    $value = $input->getAttribute('value');

    // Prioritize value with data-for attribute if exists
    if ($input->hasAttribute('data-for')) {
        $dataFor = $input->getAttribute('data-for');
        if (!empty($value)) {
            $data[$dataFor] = $value;
        }
    } elseif ($name) {
        if (empty($data[$name])) {
            $data[$name] = $value;
        }
    } elseif ($id) {
        if (empty($data[$id])) {
            $data[$id] = $value;
        }
    }
}

// Include the used cookie in the output
$data['cookie'] = $cookie;

// Save the response to Auth.json
file_put_contents('Auth.json', json_encode($data));

header('Content-Type: application/json');
echo json_encode($data);