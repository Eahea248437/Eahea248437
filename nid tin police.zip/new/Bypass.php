<?php

function perform_request($url, $follow_redirects = false) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $follow_redirects);
    $response = curl_exec($ch);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $header = substr($response, 0, $header_size);
    $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cookies = [];
    foreach (explode("\n", $header) as $line) {
        if (strpos($line, 'Set-Cookie:') === 0) {
            $cookie = substr($line, 11);
            $cookie = explode(';', $cookie)[0]; 
            $cookies[] = $cookie;
        }
    }
    curl_close($ch);
    return [$status_code, $header, $cookies];
}

function extract_hidden_inputs($html) {
    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    $inputs = $doc->getElementsByTagName('input');
    $result = [];
    foreach ($inputs as $input) {
        if ($input->getAttribute('type') === 'hidden') {
            $result[$input->getAttribute('id')] = $input->getAttribute('value');
        }
    }
    return $result;
}

list($status_code, $header, $cookies) = perform_request('https://cdms.police.gov.bd/cdms/f?p=105');

if ($status_code == 302) {
    preg_match_all('/^Location:\s*(.*)$/mi', $header, $matches);
    if (isset($matches[1][0])) {
        $location = trim($matches[1][0]);
        $url = 'https://cdms.police.gov.bd/cdms/' . $location;
        list($status_code, $header, $cookies) = perform_request($url);

        if ($status_code == 302) {
            preg_match_all('/^Location:\s*(.*)$/mi', $header, $matches);
            if (isset($matches[1][0])) {
                $second_location = trim($matches[1][0]);
                $final_url = 'https://cdms.police.gov.bd/cdms/' . $second_location;
                $ch = curl_init($final_url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_COOKIE => implode('; ', $cookies),
                ]);
                $response = curl_exec($ch);
                curl_close($ch);

                $hidden_inputs = extract_hidden_inputs($response);
                $cookies_string = implode('; ', $cookies);

                $result = array_merge($hidden_inputs, ['cookies' => $cookies_string]);

                header('Content-Type: application/json');
                echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
            }
        }
    }
}
?>