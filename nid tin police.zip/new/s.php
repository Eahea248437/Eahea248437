<?php
// Fetch the required dynamic parameters from Auth.json
$authUrl = 'http://govbd.top/new/Auth.json';
$authResponse = file_get_contents($authUrl);
if ($authResponse === false) {
    echo json_encode(['error' => 'Unable to fetch Auth data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$authData = json_decode($authResponse, true);
if ($authData === null) {
    echo json_encode(['error' => 'Invalid Auth data format'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Extract dynamic values from Auth.json
$p_instance = $authData['p_instance'] ?? '';
$p_page_submission_id = $authData['p_page_submission_id'] ?? '';
$pSalt = $authData['pSalt'] ?? '';
$P600_NEW_3 = $authData['P600_NEW_3'] ?? '';
$P600_NEW_2 = $authData['P600_NEW_2'] ?? '';
$P600_ERROR_MESSAGE = $authData['P600_ERROR_MESSAGE'] ?? '';
$cookie = $authData['cookie'] ?? '';

if (empty($p_instance) || empty($p_page_submission_id) || empty($pSalt) || empty($P600_NEW_3) || empty($P600_NEW_2) || empty($P600_ERROR_MESSAGE) || empty($cookie)) {
    echo json_encode(['error' => 'Missing dynamic parameters from Auth data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// NID and DOB input
$nid = isset($_GET['nid']) ? trim($_GET['nid']) : '';
$dob = isset($_GET['dob']) ? trim($_GET['dob']) : '';
if (empty($nid) || empty($dob)) {
    echo json_encode(['error' => 'Enter NID and DOB'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$url_1 = 'https://cdms.police.gov.bd/cdms/wwv_flow.accept';
$postFields = http_build_query([
    'p_flow_id' => 105,
    'p_flow_step_id' => 600,
    'p_instance' => $p_instance, // Fetched dynamically
    'p_debug' => '',
    'p_request' => 'Search_In_NID',
    'p_reload_on_submit' => 'S',
    'p_page_submission_id' => $p_page_submission_id, // Fetched dynamically
    'p_json' => json_encode([
        'pageItems' => [
            'itemsToSubmit' => [
                ['n' => 'P0_IP', 'v' => '103.98.77.12'],
                ['n' => 'P0_G_IP', 'v' => '103.98.77.12'],
                ['n' => 'P0_CURR_URL', 'v' => 'CDMS'],
                ['n' => 'P600_NATIONALID', 'v' => $nid],
                ['n' => 'P600_ERROR_MESSAGE', 'v' => '', 'ck' => $P600_ERROR_MESSAGE], // Fetched dynamically
                ['n' => 'P600_DOB', 'v' => $dob],
                ['n' => 'P600_PATH', 'v' => ''],
                ['n' => 'P600_FIRSTLINEADDRESS', 'v' => ''],
                ['n' => 'P600_NEW_3', 'v' => '', 'ck' => $P600_NEW_3], // Fetched dynamically
                ['n' => 'P600_NEW_2', 'v' => '', 'ck' => $P600_NEW_2]  // Fetched dynamically
            ],
            'protected' => $authData['pPageItemsProtected'],
            'rowVersion' => $authData['pPageItemsRowVersion']
        ],
        'salt' => $pSalt // Fetched dynamically
    ])
]);

$headers_1 = [
    'User-Agent: Mozilla/5.0 (Linux; Android 13; Infinix X6528 Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.103 Mobile Safari/537.36',
    'Accept: application/json, text/javascript, */*; q=0.01',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'sec-ch-ua: "Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
    'sec-ch-ua-platform: "Android"',
    'X-Requested-With: XMLHttpRequest',
    'sec-ch-ua-mobile: ?1',
    'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
    'Origin: https://cdms.police.gov.bd',
    'Sec-Fetch-Site: same-origin',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://cdms.police.gov.bd/cdms/f?p=105:600:14816587623995:::600::',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: ' . $cookie // Fetched dynamically
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_1);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response_1 = curl_exec($ch);
if (curl_errno($ch)) {
    echo json_encode(['error' => 'Curl error: ' . curl_error($ch)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    curl_close($ch);
    exit;
}

curl_close($ch);
$response_data = json_decode($response_1, true);
$redirectURL = $response_data['redirectURL'] ?? '';

if (empty($redirectURL)) {
    echo json_encode(['success' => false, 'message' => 'No redirect URL found'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

$url_2 = 'https://cdms.police.gov.bd/cdms/' . $redirectURL . '::NO:::';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$headers_2 = [
    'User-Agent: Mozilla/5.0 (Linux; Android 13; Infinix X6528 Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.6533.103 Mobile Safari/537.36',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'Accept-Encoding: gzip, deflate, br, zstd',
    'sec-ch-ua: "Not)A;Brand";v="99", "Android WebView";v="127", "Chromium";v="127"',
    'sec-ch-ua-mobile: ?1',
    'sec-ch-ua-platform: "Android"',
    'Upgrade-Insecure-Requests: 1',
    'dnt: 1',
    'X-Requested-With: mark.via.gp',
    'Sec-Fetch-Site: none',
    'Sec-Fetch-Mode: navigate',
    'Sec-Fetch-User: ?1',
    'Sec-Fetch-Dest: document',
    'Referer: https://cdms.police.gov.bd/cdms/f?p=105:600:14816587623995:::600::',
    'Accept-Language: en-US,en;q=0.9',
    'Cookie: ' . $cookie // Fetched dynamically
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_2);
$response_2 = curl_exec($ch);
if (curl_errno($ch)) {
    echo json_encode(['error' => 'Curl error: ' . curl_error($ch)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
} else {
    echo $response_2;
}
curl_close($ch);
?>
