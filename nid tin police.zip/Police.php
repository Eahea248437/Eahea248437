<?php
  header('Content-Type: application/json; charset=utf-8');
  if (isset($_GET['nid']) && isset($_GET['dob'])) {
      $response = file_get_contents("http://govbd.top/Final.php?nid=" . urlencode($_GET['nid']) . "&dob=" . urlencode($_GET['dob']));
      $data = [];
      $personalFields = [
"P600_NID" => "nid",
"P600_PERSON_NAME" => "person_name_bangla",
"P600_PERSON_NAME_ENG" => "person_name_eng",
"P600_FATH_NM" => "father_name",
"P600_MOTH_NM" => "mother_name",
"P600_BLOOD_GR" => "blood_group",
"P600_GEND" => "gender"
      ];
      foreach ($personalFields as $id => $key) {
          if (preg_match('/<span[^>]+id="' . $id . '"[^>]*>([^<]+)<\/span>/', $response, $matches)) {
              $data[$key] = trim($matches[1]);
          }
      }
      $presentFields = [
"P600_DIVISION" => "division",
"P600_DISTRICT" => "district",
"P600_UPOZILA" => "upozila",
"P600_ADDITIONALMOUZAORMOHOLLA" => "mouza_or_moholla",
"P600_ADDI_VILL_OR_ROAD" => "village_or_road",
"P600_HOMEORHOLDINGNO" => "home_or_holding_no",
"P600_REGION" => "region",
"P600_POSTOFFICE" => "post_office",
"P600_POSTALCODE" => "postal_code"
      ];
      foreach ($presentFields as $id => $key) {
          if (preg_match('/<span[^>]+id="' . $id . '"[^>]*>([^<]+)<\/span>/', $response, $matches)) {
              $data["present_" . $key] = trim($matches[1]);
          }
      }
      $permanentFields = [
"P600_PDIVISION" => "division",
"P600_PDISTRICT" => "district",
"P600_PUPOZILA" => "upozila",
"P600_PADDITIONALMOUZAORMOHOLLA" => "mouza_or_moholla",
"P600_PADDI_VILL_OR_ROAD" => "village_or_road",
"P600_PHOMEORHOLDINGNO" => "home_or_holding_no",
"P600_PREGION" => "region",
"P600_PPOSTOFFICE" => "post_office",
"P600_PPOSTALCODE" => "postal_code"
      ];
      foreach ($permanentFields as $id => $key) {
          if (preg_match('/<span[^>]+id="' . $id . '"[^>]*>([^<]+)<\/span>/', $response, $matches)) {
              $data["permanent_" . $key] = trim($matches[1]);
          }
      }
      if (preg_match('/<img[^>]+src="([^"]+)"/', $response, $matches)) {
          $data["photo"] = html_entity_decode($matches[1]);
      }
      $mappedData = [
"nameBangla" => $data["person_name_bangla"] ?? "",
"nameEnglish" => $data["person_name_eng"] ?? "",
"nationalId" => $data["nid"] ?? "",
"fatherName" => $data["father_name"] ?? "",
"motherName" => $data["mother_name"] ?? "",
"bloodGroup" => $data["blood_group"] ?? "",
"gender" => $data["gender"] ?? "",
"presentHomeOrHoldingNo" => $data["present_home_or_holding_no"] ?? "",
"presentVillageOrRoad" => $data["present_village_or_road"] ?? "",
"presentMouzaOrMoholla" => $data["present_mouza_or_moholla"] ?? "",
"presentPostOffice" => $data["present_post_office"] ?? "",
"presentPostalCode" => $data["present_postal_code"] ?? "",
"presentUpozila" => $data["present_upozila"] ?? "",
"presentDistrict" => $data["present_district"] ?? "",
"presentDivision" => $data["present_division"] ?? "",
"presentRegion" => $data["present_region"] ?? "",
"permanentHomeOrHoldingNo" => $data["permanent_home_or_holding_no"] ?? "",
"permanentVillageOrRoad" => $data["permanent_village_or_road"] ?? "",
"permanentMouzaOrMoholla" => $data["permanent_mouza_or_moholla"] ?? "",
"permanentPostOffice" => $data["permanent_post_office"] ?? "",
"permanentPostalCode" => $data["permanent_postal_code"] ?? "",
"permanentUpozila" => $data["permanent_upozila"] ?? "",
"permanentDistrict" => $data["permanent_district"] ?? "",
"permanentDivision" => $data["permanent_division"] ?? "",
"permanentRegion" => $data["permanent_region"] ?? "",
"photo" => $data["photo"] ?? ""
      ];
      echo json_encode($mappedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
  } else {
      echo json_encode(['error' => 'peramitar lagbo'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
  }
  ?>