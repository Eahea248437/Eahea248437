from django.http import JsonResponse
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.files.storage import FileSystemStorage
import fitz
import re
import re
import unicodedata
from PIL import Image
import io
import os
from django.contrib.sites.shortcuts import get_current_site


def Home(request):
    data = {
        "status": True,
        "message": "Hello Api"
    }
    return JsonResponse(data)

def extract_key_value_pairs(text):
    patterns = {
        "nid_number": r"National ID\n(.+?)\n",
        "nid_pin": r"Pin\n(.+?)\n",
        "name_bn": r"Name\(Bangla\)\n(.+?)\n",
        "name_en": r"Name\(English\)\n(.+?)\n",
        "date_of_birth": r"Date of Birth\n(.+?)\n",
        "date_of_place": r"Birth Place\n(.+?)\n",
        "father_n": r"Father Name\n(.+?)\n",
        "mother_n": r"Mother Name\n(.+?)\n",
        "Present Address": r"Present Address\n(.+?)\n",
        "Permanent Address": r"Permanent Address\n(.+?)\n",
        # "blood_group": r"Blood Group\n(.+?)\n",
        "blood_group": r"Blood Group\n(.+?)\n(?:TIN|$)",
        "Phone": r"Phone\n(.+?)\n",
        "Education": r"Education\n(.+?)\n",
        "Division": r"Division\n(.+?)\n",
        "District": r"District\n(.+?)\n",
        "RMO": r"RMO\n(.+?)(?=City|$)",  # Match until "City" or end of text
        "Municipality": r"Municipality\n(.+?)(?=Upozila|$)",  # Match until "City" or end of text
        "Upozila": r"Upozila\n(.+?)(?=Union|$)",  # Match until "City" or end of text
        "Union/Ward": r"Union/Ward\n(.+?)(?=Mouza/Moholla|$)",  # Match until "City" or end of text
        "Mouza/Moholla": r"Mouza/Moholla\n(.+?)\n(?:Additional|$)",
        "Additional": r"Additional\n(.+?)\n(?:Ward|$)",
        "Ward For": r"Ward For\n(.+?)\n(?:Village/Road|$)",
        "Village/Road": r"Village/Road\n(.+?)\n(?:Additional|$)",
        "homeOrHoldingNo": r"Home/Holding\n(.+?)\n(?:Post Office|$)",
        "Post Office": r"Post Office\n(.+?)\n(?:Postal Code|$)",
        "Postal Code": r"Postal Code\n(.+?)\n(?:Region|$)",
        "Region": r"Region\n(.+?)\n(?:Permanent Address|$)",
    }

    extracted_data = {}

    for pattern_key, key in patterns.items():
        match = re.search(key, text, re.DOTALL)
        if match:
            normalized_text = unicodedata.normalize("NFKD", match.group(1))
            if pattern_key in ["RMO","Municipality","homeOrHoldingNo"]:
                normalized_text = unicodedata.normalize("NFKD", match.group(1))
                extracted_data[pattern_key] = normalized_text.replace("\n", " ").strip()
            elif pattern_key == "Mouza/Moholla":
                normalized_text = re.sub(r"Additional.*$", "", normalized_text)
                newtext= normalized_text.replace("\n"," ").strip()
                index = newtext.find("Additional")
                if index != -1:  # Check if "Additional" is found
                    newtext = newtext[:index]
                extracted_data[pattern_key] = newtext
            elif pattern_key == "Additional":
                normalized_text = re.sub(r"Additional.*$", "", normalized_text)
                newtext= normalized_text.replace("\n","").strip()
                extracted_data[pattern_key] = newtext.replace("Mouza/Moholla","")
            elif pattern_key == "Ward For":
                normalized_text = re.sub(r"Ward For.*$", "", normalized_text)
                newtext= normalized_text.replace("\n","").strip()
                extracted_data[pattern_key] = newtext.replace("UnionPorishod","")

            elif pattern_key == "Village/Road":
                normalized_text = re.sub(r"Additional.*$", "", normalized_text)
                newtext= normalized_text.replace("\n","").strip()
                index=newtext.find("Additional")
                if index !=-1:
                    newtext=newtext[:index]
                extracted_data[pattern_key] = newtext

            elif pattern_key == "Home/Holding":
                normalized_text = re.sub(r"Home/Holding*$", "", normalized_text)
                newtext= normalized_text.replace("\n","").strip()
                extracted_data[pattern_key] = newtext.replace("No","")
            elif pattern_key == "blood_group":
                normalized_text = re.sub(r"TIN.*$", "", normalized_text)
                newtext= normalized_text.replace("\n"," ").strip()
                index = newtext.find("TIN")
                if index != -1:
                    newtext = newtext[:index]
                extracted_data[pattern_key] = newtext

            else:
                extracted_data[pattern_key] = match.group(1).strip()
        else:
            extracted_data[pattern_key] = None

    return extracted_data

@csrf_exempt
def upload_pdf_view(request):
    if request.method == 'POST' and request.FILES['pdf']:
        pdf_file = request.FILES['pdf']
        pdf_data = pdf_file.read()
        pdf_document = fitz.open(stream=pdf_data, filetype="pdf")
        all_extracted_data = []
        current_site=get_current_site(request)
        for page_num in range(len(pdf_document)):
            page = pdf_document[page_num]
            page_text = page.get_text()
            extracted_data = extract_key_value_pairs(page_text)
            national_id = extracted_data.get("nid_number", "")
            if page_num==0:
                delete_images(f"photo_{national_id}")
            all_extracted_data.append(extracted_data)
             # Process images
            image_list = page.get_images(full=True)
            photo_counter = 0
            signature_counter = 0
            for image_index, img in enumerate(image_list, start=1):

                xref = img[0]
                base_image = pdf_document.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]

                image_name = f"images/photo_{national_id}_{photo_counter}.{image_ext}"
                while os.path.exists(image_name):
                    photo_counter += 1
                    image_name = f"images/photo_{national_id}_{photo_counter}.{image_ext}"

                # Save the image to a file in the "images" folder
                image = Image.open(io.BytesIO(image_bytes))
                image.save(image_name)

                if image_index == 1:
                    extracted_data["photo"] = 'https://digitalsonod.in/'+image_name
                elif image_index == 2:
                    extracted_data["sign"] = 'https://digitalsonod.in/'+image_name
                extracted_data['address']=format_address(extracted_data)

            all_extracted_data.append(extracted_data)

        pdf_document.close()

        return JsonResponse({"status": True, "message": "PDF file uploaded and processed successfully", "data": all_extracted_data[:3]})
    else:
        return JsonResponse({"status": False, "message": "No PDF file found in request"}, status=400)

def delete_images(prefix):
    image_folder = "images"
    for filename in os.listdir(image_folder):
        if filename.startswith(prefix):
            file_path = os.path.join(image_folder, filename)
            os.remove(file_path)
            print(f"Deleted: {file_path}")



def format_address(address):
    formatted_address = ''

    if address:
        formatted_address += f"বাসা/হোল্ডিং: {address.get('homeOrHoldingNo', '')}, "
        formatted_address += f"গ্রাম/রাস্তা: {address.get('Additional', '')}, "
        ##formatted_address += f"মৌজা/মহল্লা: {address.get('Mouza/Moholla', '')}, "
        ##formatted_address += f"ইউনিয়ন: {address.get('Union/Ward', '')}, "
        ##formatted_address += f"ওয়ার্ড নং: {address.get('Union/Ward', '')}, "
        formatted_address += f"ডাকঘর: {address.get('Post Office', '')} "
        formatted_address += f"পোষ্ট কোড: {address.get('Postal Code', '')}, "
        formatted_address += f"উপজেলা: {address.get('Upozila', '')}, "
        formatted_address += f"জেলা: {address.get('District', '')}, "
        ##formatted_address += f"বিভাগ: {address.get('Division', '')}"

    return formatted_address

