from flask import Flask, request, jsonify
import requests
import random
import time

app = Flask(__name__)

def get_random_phone_number():
    prefixes = ['8', '7', '9', '5', '6', '3']
    random_prefix = random.choice(prefixes)
    random_digits = ''.join(str(random.randint(0, 9)) for _ in range(8))
    return '01' + random_prefix + random_digits

def svr(nid, dob):
    token_headers = {
        "Authorization": "Basic YWdyYW5pYmFuazpBZ3JhbmlCQG4xSw==",
        "Content-Type": "application/json; charset=UTF-8",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD MIUI/V12.0.1.0.PEKMIXM)",
        "Host": "mfs.agranibank.org:9293",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "Content-Length": "0"
    }

    max_retries = 3
    retry_count = 0
    connected = False

    while retry_count < max_retries and not connected:
        try:
            response = requests.post(
                "https://mfs.agranibank.org:9293/appapi/index.php/api/token",
                headers=token_headers,
                timeout=30
            )
            if response.status_code == 200:
                connected = True
                token_data = response.json()
                access_token = token_data.get('access_token')
                if access_token:
                    headers = {
                        "Authorization": f"Bearer {access_token}",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD MIUI/V12.0.1.0.PEKMIXM)",
                        "Host": "mfs.agranibank.org:9293",
                        "Connection": "Keep-Alive",
                        "Accept-Encoding": "gzip"
                    }

                    mobile_number = get_random_phone_number()
                    data = {
                        "nidNumber": nid,
                        "smartNidStatus": "false",
                        "lang_code": "1",
                        "mobile_no": mobile_number,
                        "customerDob": dob,
                        "product_code": "1"
                    }

                    response = requests.post(
                        "https://mfs.agranibank.org:9293/appapi/index.php/api/home/getNidData",
                        headers=headers,
                        data=data,
                        timeout=30
                    )

                    if response.status_code == 200:
                        return response.text
                    else:
                        return f"Server Copy API ERROR \n\n Contact Admin @STDNX\n\nStatus Code: {response.status_code}\nResponse: {response.text}\nError: {response.reason}"
                else:
                    return "Error: Access token not found in response."
            else:
                retry_count += 1
                time.sleep(5)  # Wait 5 seconds before retrying
        except requests.RequestException as e:
            retry_count += 1
            time.sleep(5)  # Wait 5 seconds before retrying
            error_message = str(e)

    return f"Authentication Failed.\n\nContact Admin @STDNX\n\nLast Status Code: {response.status_code if 'response' in locals() else 'N/A'}\nResponse: {response.text if 'response' in locals() else 'N/A'}\nError: {error_message if 'error_message' in locals() else 'N/A'}"

@app.route('/search')
def search():
    nid = request.args.get('nid')
    dob = request.args.get('dob')
    if nid and dob:
        result = svr(nid, dob)
        return jsonify({"result": result})
    else:
        return jsonify({"error": "NID and DOB parameters are required."}), 400

if __name__ == '__main__':
    app.run(debug=True)
