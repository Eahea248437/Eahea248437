<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

require 'vendor/autoload.php';

// Function to send emails
function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host       = 'mail.sebacenter.xyz';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@sebacenter.xyz';
        $mail->Password   = 'solemanit79753';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom('info@sebacenter.xyz', 'DigiYotta | Digital Marketing Agency');
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;

        // Use Twig to render the email template
        $loader = new FilesystemLoader('templates');
        $twig = new Environment($loader);
        $template = $twig->load('email_template.twig');

        $mail->Body = $template->render([
            'message' => $message,
        ]);

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// Main script
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Check if xlsx file is provided
    if (isset($_FILES["xlsxFile"]) && $_FILES["xlsxFile"]["error"] == 0) {
        $xlsxFile = $_FILES["xlsxFile"]["tmp_name"];
        $spreadsheet = IOFactory::load($xlsxFile);
        $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

        foreach ($sheetData as $row) {
            $email = $row['A']; // Assuming the email is in the first column (adjust as needed)
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                sendEmail($email, $subject, $message);
            }
        }
    } elseif (!empty($_POST["to"])) {
        // If xlsx file is not provided, use the single email address input
        $to = $_POST["to"];
        sendEmail($to, $subject, $message);
    }
}
?>
