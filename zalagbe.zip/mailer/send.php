<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

require 'vendor/autoload.php';

// Function to send emails
function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);

    try {
        // Validate email address
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email address: $to");
        }

        // Server settings
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host       = 'mail.sebacenter.xyz';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'info@sebacenter.xyz';
        $mail->Password   = 'solemanit79753';
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom('info@sebacenter.xyz', 'DigiYotta | Digital Marketing Agency');
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;

        // Use Twig to render the email template
        $loader = new FilesystemLoader('templates');
        $twig = new Environment($loader);
        $template = $twig->load('email_template.twig');

        $mail->Body = $template->render([
            'message' => $message,
        ]);

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// Main script
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Check if xlsx file is provided
    if (isset($_FILES["xlsxFile"]) && $_FILES["xlsxFile"]["error"] == 0) {
        $xlsxFile = $_FILES["xlsxFile"]["tmp_name"];

        // Validate the file type
        $allowedTypes = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
        $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
        $fileType = finfo_file($fileInfo, $xlsxFile);
        finfo_close($fileInfo);

        if (!in_array($fileType, $allowedTypes)) {
            echo 'Invalid file type. Please upload an Excel (.xlsx) file.';
        }

        // Validate the file content
        try {
            $spreadsheet = IOFactory::load($xlsxFile);
        } catch (\PhpOffice\PhpSpreadsheet\Reader\Exception $e) {
            echo 'Error loading the Excel file.';
        }

        $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

        foreach ($sheetData as $row) {
            if (isset($row['A'])) {
                $email = trim($row['A']); // Assuming the email is in the first column (adjust as needed)

                // Validate email address
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    sendEmail($email, $subject, $message);
                }
            }
        }
    } elseif (!empty($_POST["to"])) {
        // If xlsx file is not provided, use the single email address input
        $to = trim($_POST["to"]);

        // Validate email address
        if (filter_var($to, FILTER_VALIDATE_EMAIL)) {
            sendEmail($to, $subject, $message);
        }
    }
}
?>
