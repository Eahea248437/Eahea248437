<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHPMailer Email System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Email Sending System</h2>
    
    <form action="send.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="to">To Email Addresses:</label>
            <input type="text" class="form-control" id="to" name="to" placeholder="Enter a single email address">
        </div>

        <div class="form-group">
            <label for="xlsxFile">Excel (.xlsx) File (Optional):</label>
            <input type="file" class="form-control-file" id="xlsxFile" name="xlsxFile" accept=".xlsx">
        </div>

        <div class="form-group">
            <label for="subject">Subject:</label>
            <input type="text" class="form-control" id="subject" name="subject" required>
        </div>
        
        <div class="form-group">
            <label for="message">Message:</label>
            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Send Emails</button>
    </form>
</div>

</body>
</html>
