<?php
session_start();

// Ensure no content or output is sent before the image is generated
ob_start(); // Start output buffering

// You can customize your CAPTCHA settings here
$captcha_code = '';
$captcha_image_height = 50;
$captcha_image_width = 400;
$total_characters_on_image = 5;

$possible_captcha_letters = 'bcdfhjkmnpqrstvwxyz23456789'; // Avoid confusing characters
$filepath = realpath(__DIR__); // Path to fonts
$captcha_fonts = [$filepath . '/typewriter.ttf']; // Array of fonts to randomize
$captcha_text_color = "0x142864";
$captcha_noise_color = "0x142864";

$random_captcha_dots = 80;
$random_captcha_lines = 30;
$letter_spacing = 20; // Define extra space between letters

// Generate random CAPTCHA code
for ($count = 0; $count < $total_characters_on_image; $count++) {
    $captcha_code .= substr(
        $possible_captcha_letters,
        random_int(0, strlen($possible_captcha_letters) - 1),
        1
    );
}

// Store the CAPTCHA code in the session (hashed for security)
$_SESSION['captcha'] = password_hash($captcha_code, PASSWORD_DEFAULT);

$captcha_font_size = $captcha_image_height * 0.7; // Font size based on image height
$captcha_image = imagecreate($captcha_image_width, $captcha_image_height); // Create image

// Set the background color to white
$background_color = imagecolorallocate($captcha_image, 255, 255, 255); // White background

// Convert HEX colors to RGB
$array_text_color = hextorgb($captcha_text_color);
$captcha_text_color = imagecolorallocate($captcha_image, $array_text_color['red'], $array_text_color['green'], $array_text_color['blue']);

$array_noise_color = hextorgb($captcha_noise_color);
$image_noise_color = imagecolorallocate($captcha_image, $array_noise_color['red'], $array_noise_color['green'], $array_noise_color['blue']);

// Generate random noise dots
for ($count = 0; $count < $random_captcha_dots; $count++) {
    imagefilledellipse(
        $captcha_image,
        random_int(0, $captcha_image_width),
        random_int(0, $captcha_image_height),
        random_int(1, 5),
        random_int(1, 5),
        $image_noise_color
    );
}

// Generate random noise lines
for ($count = 0; $count < $random_captcha_lines; $count++) {
    imageline(
        $captcha_image,
        random_int(0, $captcha_image_width),
        random_int(0, $captcha_image_height),
        random_int(0, $captcha_image_width),
        random_int(0, $captcha_image_height),
        $image_noise_color
    );
}

// Calculate total text width for the entire string
$total_text_width = 0;
$font = $captcha_fonts[0]; // Use the font

for ($i = 0; $i < $total_characters_on_image; $i++) {
    $char = substr($captcha_code, $i, 1);
    $bbox = imagettfbbox($captcha_font_size, 0, $font, $char);
    $total_text_width += $bbox[2] - $bbox[0] + $letter_spacing; // Include letter spacing
}

// Calculate starting x to center the text
$x_start = ($captcha_image_width - $total_text_width + $letter_spacing) / 2;

// Add the text to the image with random distortion
$x = $x_start; // Initial x-position to center the text
for ($i = 0; $i < $total_characters_on_image; $i++) {
    $angle = random_int(-15, 15); // Random angle
    $char = substr($captcha_code, $i, 1); // Get the character
    $y = random_int($captcha_image_height * 0.7, $captcha_image_height * 0.9); // Random y-coordinate
    $bbox = imagettfbbox($captcha_font_size, $angle, $font, $char); // Calculate character bounding box
    $char_width = $bbox[2] - $bbox[0]; // Character width

    imagettftext(
        $captcha_image,
        $captcha_font_size,
        $angle,
        $x,
        $y,
        $captcha_text_color,
        $font,
        $char
    );

    // Update x-position for the next character with added spacing
    $x += $char_width + $letter_spacing;
}

// Clear any previous output to avoid interference with image rendering
ob_clean();

// Output headers to prevent caching and ensure image reloads every time
header('Content-Type: image/jpeg');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output CAPTCHA image and destroy instance
imagejpeg($captcha_image);
imagedestroy($captcha_image);

// End output buffering and flush content
ob_end_flush();

function hextorgb($hexstring) {
    $integar = hexdec($hexstring);
    return array(
        "red" => 0xFF & ($integar >> 0x10),
        "green" => 0xFF & ($integar >> 0x8),
        "blue" => 0xFF & $integar
    );
}
