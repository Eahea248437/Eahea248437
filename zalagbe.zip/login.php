<?php
if (!isset($_GET['auth']) || $_GET['auth'] !== '1') {
  // If the auth parameter is not equal to '1', send a 500 Internal Server Error
  header($_SERVER['SERVER_PROTOCOL'] . ' 500 Internal Server Error', true, 500);
  exit();
}


$page = 'login';

// 1. Include composer's autoloader
require __DIR__ . '/vendor/autoload.php';
use Detection\MobileDetect;
$detect = new MobileDetect();

// if ($detect->isMobile() == FALSE) {
//     header('Location: https://www.google.com/v1/');
//     exit();
// }


////////
$filepath = realpath(__DIR__);

include($filepath.'/protect/config.php');
include($filepath.'/protect/project-security.php');

require_once $filepath.'/inc/loader.php';
session_set_cookie_params(0, '/', '.zalagbe.store');
Session::checkLogin();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
      $submit = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Access not allow!</div>';
  }else{
    $username = $_POST['login_username'];
    $password = $_POST['login_password'];
    $captcha = $_POST['captcha'];
    $captcha_session = $_SESSION['captcha'];
    $submit = $admin->login($username, $password, $captcha, $captcha_session);
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

  <title>লগইন - Login</title>
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/fonts/stylesheet.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

  <main>
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6">

              <div class="d-flex justify-content-center py-4">
                <a href="<?php SITEURL ?>" class="logo d-flex align-items-center w-auto">
                  <img src="assets/img/zalgbe-web.png">

                </a>
              </div><!-- End Logo -->

              <div class="card-body">

                  <!-- <div class="pt-4 pb-2">
                  </div> -->

                  <form method="post" class="row g-3 needs-validation" novalidate>
                    <?php if(isset($submit)){ echo $submit; } ?>
                    <div class="col-12">
                      <input type="text" name="login_username" class="form-control" placeholder="ইউজার আইডি" required>
                      <div class="invalid-feedback">আপনার ইউজার আইডি দিন!</div>
                    </div>

                    <div class="col-12">
                      <input type="password" name="login_password" class="form-control" placeholder="*******" required>
                      <div class="invalid-feedback">আপনার পাসওয়ার্ড দিন!</div>
                    </div>
                    <div class="col-12">
                      <input type="text" name="captcha" class="form-control" placeholder="ক্যাপচা কোড" required>
                      <div class="invalid-feedback">ক্যাপচা কোড লিখুন</div>
                      <img style="width:100%; display: block;margin: 0 auto;margin-top: 12px;" src="<?php echo SITEURL; ?>captcha/verify.php?rand=<?php echo rand(); ?>" id='captcha_image'>
                      <p class="mt-1">নতুন ক্যাপচা পেতে <a href='javascript: refreshCaptcha();'><i class="bi bi-arrow-clockwise"></i> ক্লিক করুন</a></p>
                      <button class="btn btn-primary w-100" type="submit">লগইন করুন</button>
                      <p class="mb-0 mt-1">একাউন্ট নেই? <a href="signup">রেজিষ্টেশন করুন</a></p>
                      <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    </div>
                  </form>

                </div>
            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <?php
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')) ? "https://" : "http://";
$home = $protocol . $_SERVER['HTTP_HOST'];
$script = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/';
?>
<script type="module">import devtools from '<?php echo $home.$script; ?>node_modules/devtools-detect/index.js';</script>
<script src="assets/js/protect.js"></script>
  <script>
  //Refresh Captcha
  function refreshCaptcha(){
      var img = document.images['captcha_image'];
      img.src = img.src.substring(
      0,img.src.lastIndexOf("?")
      )+"?rand="+Math.random()*1000;
  }
  </script>
<?php ?>
</body>

</html>