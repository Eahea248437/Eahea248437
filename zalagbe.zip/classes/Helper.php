<?php



/**

* Helper

*/

class Helper{

	public function formatDate($data) {

		$format = strtotime($data);

		$date = date("d-m-Y ", $format);

		return $date;

	}



	public function formatDate2($data) {

		date_default_timezone_set("Asia/Dhaka");

		$format = strtotime($data);

		$date = date("d-m-Y H:i:s a", $format);

		return $date;

	}



	public function formatDateYear() {

		date_default_timezone_set('Asia/Dhaka');

		return date( 'F Y');

		

		/*

		$today = date("F j, Y, g:i a");                 // March 10, 2001, 5:16 pm

		$today = date("m.d.y");                         // 03.10.01

		$today = date("j, n, Y");                       // 10, 3, 2001

		$today = date("Ymd");                           // 20010310

		$today = date('h-i-s, j-m-y, it is w Day');     // 05-16-18, 10-03-01, 1631 1618 6 Satpm01

		$today = date('\i\t \i\s \t\h\e jS \d\a\y.');   // it is the 10th day.

		$today = date("D M j G:i:s T Y");               // Sat Mar 10 17:16:18 MST 2001

		$today = date('H:m:s \m \i\s\ \m\o\n\t\h');     // 17:03:18 m is month

		$today = date("H:i:s");                         // 17:16:18

		$today = date("Y-m-d H:i:s");                   // 2001-03-10 17:16:18 (the MySQL DATETIME format)

		*/

	}



	public function getCurrentDateTime(){

		date_default_timezone_set("Asia/Dhaka");

		return date("Y-m-d H:i:s");

	}



	public function time_elapsed_string($datetime, $full = false) {

		$now = new DateTime;

		$ago = new DateTime($datetime);

		$diff = $now->diff($ago);

	

		$diff->w = floor($diff->d / 7);

		$diff->d -= $diff->w * 7;

	

		$string = array(

			'y' => 'year',

			'm' => 'month',

			'w' => 'week',

			'd' => 'day',

			'h' => 'hour',

			'i' => 'minute',

			's' => 'second',

		);

		foreach ($string as $k => &$v) {

			if ($diff->$k) {

				$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');

			} else {

				unset($string[$k]);

			}

		}

	

		if (!$full) $string = array_slice($string, 0, 1);

		return $string ? implode(', ', $string) . ' ago' : 'just now';

	}



	public function get_time_ago( $time ) {

   		$time_difference = time() - $time;

		if( $time_difference < 1 ) { return 'less than 1 second ago'; }

		$condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',

					30 * 24 * 60 * 60       =>  'month',

					24 * 60 * 60            =>  'day',

					60 * 60                 =>  'hour',

					60                      =>  'minute',

					1                       =>  'second'

		);



		foreach( $condition as $secs => $str ) {

			$d = $time_difference / $secs;



			if( $d >= 1 )

			{

				$t = round( $d );

				return 'about ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';

			}

		}

	}



	public function formatDateTime() {

		date_default_timezone_set('Asia/Dhaka');

        return date( 'd-m-Y g:i A');

	}



	public function validatePass($password) {

		// Validate password strength

		$uppercase = preg_match('@[A-Z]@', $password);

		$lowercase = preg_match('@[a-z]@', $password);

		$number    = preg_match('@[0-9]@', $password);

		$specialChars = preg_match('@[^\w]@', $password);



		if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {

			$msg = 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';

			return $msg;

		}

	}



	public function taka_format($amount = 0) {

		$tmp = explode('.',$amount); // for float or double values

		$strMoney = '';

		$divide = 1000;

		$amount = $tmp[0];

		$strMoney .= str_pad($amount%$divide,3,'0',STR_PAD_LEFT);

		$amount = (int)($amount/$divide);

		while($amount>0) {

			$divide = 100;

			$strMoney = str_pad($amount%$divide, 2,'0',STR_PAD_LEFT).','.$strMoney;

			$amount = (int)($amount/$divide);

		}

		if(substr($strMoney, 0, 1) == '0')

			$strMoney = substr($strMoney,1);



			if(isset($tmp[1])) // if float and double add the decimal digits here.

			{

				return $strMoney.'.'.$tmp[1];

			}

			return $strMoney;

	}



	public function textShorten($text, $limit = 100) {

		$text = $text. " ";

		$text = substr($text, 0, $limit);

		//$text = $text."...";

		return $text;

	}



	public function validation($data) {

	   $data = trim($data);

	   $data = stripslashes($data);

	   $data = htmlspecialchars($data);

	   //$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING, true);

	   return $data;

	}



	public function title() {

		$path = $_SERVER['SCRIPT_FILENAME'];

		$title = basename($path, '.php');

		//$title = str_replace('_', ' ', $title);

		if ($title == 'index.php') {

			$title = 'home';

		}elseif ($title == 'contact') {

			$title = 'contact';

		}

		return $title = ucfirst($title);

	}



	public function slug($string) {  

	    $slug = preg_replace('/[^a-z0-9-]+/', '-', trim(strtolower($string)));

	    return $slug;  

	}

	/* 

	* Custom function to compress image size and 

	* upload to the server using PHP 

	*/ 

	public function compressImage($source, $destination, $quality) { 

		// Get image info 

		$imgInfo = getimagesize($source); 

		$mime = $imgInfo['mime']; 

		

		// Create a new image from file 

		switch($mime){ 

			case 'image/jpeg': 

				$image = imagecreatefromjpeg($source); 

				break; 

			case 'image/png': 

				$image = imagecreatefrompng($source); 

				break; 

			case 'image/gif': 

				$image = imagecreatefromgif($source); 

				break; 

			default: 

				$image = imagecreatefromjpeg($source); 

		} 

		

		// Save image 

		imagejpeg($image, $destination, $quality);

		

		// Return compressed image 

		return $destination; 

	}



	public function cleanStr($string) {

		// Replaces all spaces with hyphens.

		$string = str_replace(' ', '-', $string);

		// Removes special chars.

		$string = preg_replace('/[^A-Za-z0-9\-]/', '', $string);

		// Replaces multiple hyphens with single one.

		$string = preg_replace('/-+/', '-', $string);

		

		return $string;

	}



	public function en_to_bn($en_text) {

		$engNumber = array(1,2,3,4,5,6,7,8,9,0);

		$bangNumber = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');

		return str_replace($engNumber, $bangNumber, $en_text);

	}



	public function getUserIP(){

		if(!empty($_SERVER['HTTP_CLIENT_IP'])){

			//ip from share internet

			$ip = $_SERVER['HTTP_CLIENT_IP'];

		}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){

			//ip pass from proxy

			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

		}else{

			$ip = $_SERVER['REMOTE_ADDR'];

		}

		return $ip;

	}



	// Function to get the client IP address

	/*public function get_client_ip() {

		$ipaddress = '';

		if (isset($_SERVER['HTTP_CLIENT_IP']))

			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];

		else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))

			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];

		else if(isset($_SERVER['HTTP_X_FORWARDED']))

			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];

		else if(isset($_SERVER['HTTP_FORWARDED_FOR']))

			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];

		else if(isset($_SERVER['HTTP_FORWARDED']))

			$ipaddress = $_SERVER['HTTP_FORWARDED'];

		else if(isset($_SERVER['REMOTE_ADDR']))

			$ipaddress = $_SERVER['REMOTE_ADDR'];

		else

			$ipaddress = 'UNKNOWN';

		return $ipaddress;

	}*/



	public function get_client_ip() {

		// Get real visitor IP behind CloudFlare network

    	if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {

            $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];

            $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];

    	}

    	$client  = @$_SERVER['HTTP_CLIENT_IP'];

    	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];

    	$remote  = $_SERVER['REMOTE_ADDR'];



    	if(filter_var($client, FILTER_VALIDATE_IP)){

        	$ip = $client;

    	} elseif(filter_var($forward, FILTER_VALIDATE_IP)){

        	$ip = $forward;

    	} else{

        	$ip = $remote;

    	}

    return $ip;

	}



	/**

	*

	* Author: Soleman IT

	* Function Name: resizeImage()

	* $field_name => Input file field name.

	* $target_folder => Folder path where the image will be uploaded.

	* $file_name => Custom thumbnail image name. Leave blank for default image name.

	* $thumb => TRUE for create thumbnail. FALSE for only upload image.

	* $thumb_folder => Folder path where the thumbnail will be stored.

	* $thumb_width => Thumbnail width.

	* $thumb_height => Thumbnail height.

	*

	**/

	public function resizeImage($field_name = '', $target_folder = '', $file_name = '', $thumb = FALSE, $thumb_folder = '', $thumb_width = '', $thumb_height = ''){



		//folder path setup

		$target_path = $target_folder;

		$thumb_path = $thumb_folder;

		

		//file name setup

		$filename_err = explode(".",$_FILES[$field_name]['name']);

		$filename_err_count = count($filename_err);

		$file_ext = $filename_err[$filename_err_count-1];

		if($file_name != ''){

			//$fileName = $file_name.'.'.$file_ext;

			$fileName   = substr(md5(time()), 0, 10).'.'.$file_ext;

		} else{

			///$fileName = $_FILES[$field_name]['name'];

			$fileName   = substr(md5(time()), 0, 10).'.'.$file_ext;

		}

		

		//upload image path

		$upload_image = $thumb_path.basename($fileName);

		

		//upload image

		if(move_uploaded_file($_FILES[$field_name]['tmp_name'],$upload_image)){

			//thumbnail creation

			if($thumb == TRUE){

				$thumbnail = $thumb_path.$fileName;

				list($width,$height) = getimagesize($upload_image);

				$thumb_create = imagecreatetruecolor($thumb_width,$thumb_height);

				switch($file_ext){

					case 'jpg':

						$source = imagecreatefromjpeg($upload_image);

						break;

					case 'jpeg':

						$source = imagecreatefromjpeg($upload_image);

						break;



					case 'png':

						$source = imagecreatefrompng($upload_image);

						break;

					case 'gif':

						$source = imagecreatefromgif($upload_image);

						break;

					default:

						$source = imagecreatefromjpeg($upload_image);

				}



				imagecopyresized($thumb_create,$source,0,0,0,0,$thumb_width,$thumb_height,$width,$height);

				switch($file_ext){

					case 'jpg' || 'jpeg':

						imagejpeg($thumb_create,$thumbnail,100);

						break;

					case 'png':

						imagepng($thumb_create,$thumbnail,100);

						break;



					case 'gif':

						imagegif($thumb_create,$thumbnail,100);

						break;

					default:

						imagejpeg($thumb_create,$thumbnail,100);

				}

			}

			return $fileName;

		} else{

			return false;

		}

	}



	function getBreakText($t) {

    	return nl2br(htmlentities($t, ENT_QUOTES, 'UTF-8'));

	}

	

}
?>