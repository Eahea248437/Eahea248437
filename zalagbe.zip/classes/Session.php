<?php

/**
 * Session Class
 **/
class Session {
    public static function init()
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public static function set($key, $val)
    {
        $_SESSION[$key] = $val;
    }

    public static function get($key)
    {
        if (isset($_SESSION[$key])) {
            return $_SESSION[$key];
        }
        return false;
    }
    
    private static function isSessionExpired()
    {
        $inactive_time = 600; //5min
        $current_time = time();

        if(isset($_SESSION['last_activity']) && ($current_time - $_SESSION['last_activity'] > $inactive_time)) {
            self::destroy();
            header("Location:" . SITEURL . 'login');
            exit();
        }

        $_SESSION['last_activity'] = $current_time;
    }

    public static function checkSession()
    {
        self::init();
        if (self::get("login") === false) {
            self::destroy();
            header("Location:" . SITEURL . 'login');
            exit();
        }else{
            self::isSessionExpired();
        }
    }

    public static function checkLogin()
    {
        self::init();
        if (self::get("login") === true) {
            session_regenerate_id(true);
            header("Location: " . SITEURL);
            exit();
        }
    }

    public static function logout()
    {
        self::init();
        self::destroy();
        header("Location:" . SITEURL . 'login');
        exit();
    }

    private static function destroy()
    {
        unset($_SESSION['login']);
        unset($_SESSION['last_activity']);
        //session_destroy();
    }

    public static function sessionId()
    {
        self::init();
        return session_id();
    }
}
