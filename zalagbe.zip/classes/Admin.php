<?php
/**
 * Admin
 */
spl_autoload_register(static function($class_Name){
    $filepath = realpath(__DIR__);
    require_once $filepath.'/'.$class_Name.'.php';
});

require_once(__DIR__ . '/vendor/phpqrcode/qrlib.php');
require_once(__DIR__ . '/vendor/phpqrcode/qrconfig.php');
require_once(__DIR__ . '/vendor/hash/RandomStringGenerator.php');

use Utils\RandomStringGenerator;


    class Admin{
       private $db;
       private $helper;
    
       public function __construct() {
          $this->db 		= new Database();
          $this->helper 	= new Helper();
       }
   
    /*
    * Login
    */
    
   public function login($username, $password, $captcha, $captcha_session){
      $username = mysqli_real_escape_string($this->db->connect, $this->helper->validation($username));
      $password = mysqli_real_escape_string($this->db->connect, $this->helper->validation($password));
      $captcha = mysqli_real_escape_string($this->db->connect, $this->helper->validation($captcha));
      if (empty($username)) {
         $msg = '<div class="alert alert-info" role="alert"><i class="icon fa fa-info"></i> Enter your username or email!</div>';
         return $msg;
      }
      if (empty($password)) {
         $msg = '<div class="alert alert-info" role="alert"><i class="icon fa fa-info"></i> Enter your password!</div>';
         return $msg;
      }
      
      $query = "SELECT * FROM `tbl_admin` WHERE `username` = '$username' AND `status` = '1'";
      $result = $this->db->row($query);
      if ($result !== false) {
         $value = $result->fetch_assoc();
         if (password_verify($password, $value['password'])) {
            //if(strcasecmp($captcha_session, $captcha) != 0){
            if (isset($captcha_session) && password_verify($captcha, $captcha_session)) {
                Session::set('login', true);
                Session::set('last_activity', time());
                Session::set('user_name', $value['username']);
                Session::set('user_role', $value['role']);
                Session::set('user_id', base64_encode($value['id']));
                Session::set('csrf_token', bin2hex(random_bytes(32)));
                header("refresh:1;url=".BASEURL);
                $msg = '<div class="alert alert-success"><i class="fa fa-check-circle"></i> লগইন হচ্ছে...</div>';
                return $msg;
            } else{
                $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> ক্যাপচা মিলছে না!</div>';
                return $msg;
            }
         }else{
            $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> আপনার সঠিক তথ্য দিন!</div>';
            return $msg;
         }
      } else{
         $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> আপনার সঠিক তথ্য দিন!</div>';
         return $msg;
      }
   }

   /*
    * Users
    */
    
   public function add_user($data){
      $username = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['signup_username']));
      $password = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['signup_password']));
      $confirm_password = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['confirm_password']));
      $password_hash = password_hash($data['confirm_password'], PASSWORD_BCRYPT);
      $mobile = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['signup_mobile']));

      $query = "SELECT * FROM `tbl_admin` WHERE `tbl_admin`.`username` = '$username'";
      $checkUsername = $this->db->row($query);

      if (empty($username)) {
         return $error = '<div class="alert alert-danger" role="alert">Enter your username!</div>';
      }
      
      if ($checkUsername) {
         return $error = '<div class="alert alert-danger" role="alert"><i class="icon fa fa-ban"></i> Username already '.$username.' taken!</div>';
      }
      
      if (empty($password)) {
          return $error = '<div class="alert alert-danger" role="alert">Password is required!</div>';
      }
      
      if (empty($confirm_password)) {
          return $error = '<div class="alert alert-danger" role="alert">Confirm Password is required!</div>';
      }
      if ($password !== $confirm_password) {
          return $error = '<div class="alert alert-danger" role="alert">Passwords do not match!</div>';
      }
      
      if(empty($mobile) || !preg_match("/^(?:\+88|88)?(01[3-9]\d{8})$/", $mobile)){
          return $error = '<div class="alert alert-danger" role="alert">Enter your mobile number</div>';
      }
      
    $sql = "INSERT INTO `tbl_admin`(
         `username`,
         `password`,
         `mobile`,
         `status`,
         `role`
     )
     VALUES(
         '$username',
         '$password_hash',
         '$mobile',
         '1',
         'user'
     )";

      if ($this->db->run($sql)) {
         return $error = '<div class="alert alert-success" role="alert">Successfully user created!</div>';
      }else{
         return $error = '<div class="alert alert-danger" role="alert">Something is wrnog!</div>';
      }
   }
   
   public function signup($data){
      $username = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['signup_username']));
      $password = password_hash($data['signup_password'], PASSWORD_BCRYPT);
      $mobile = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['signup_mobile']));

      $query = "SELECT * FROM `tbl_admin` WHERE `tbl_admin`.`username` = '$username'";
      $checkUsername = $this->db->row($query);

      if (empty($username)) {
         return $error = '<div class="alert alert-danger" role="alert">Enter your username!</div>';
      }
      
      if ($checkUsername) {
         return $error = '<div class="alert alert-danger" role="alert"><i class="icon fa fa-ban"></i> Username already '.$username.' taken!</div>';
      }
      
      if (empty($password)) {
          return $error = '<div class="alert alert-danger" role="alert">Password is required!</div>';
      }

      if(empty($mobile) || !preg_match("/^(?:\+88|88)?(01[3-9]\d{8})$/", $mobile)){
          return $error = '<div class="alert alert-danger" role="alert">Enter your mobile number</div>';
      }
      
    $sql = "INSERT INTO `tbl_admin`(
         `username`,
         `password`,
         `mobile`,
         `status`,
         `role`
     )
     VALUES(
         '$username',
         '$password',
         '$mobile',
         '1',
         'user'
     )";

      if ($this->db->run($sql)) {
         header("refresh:1;url=".BASEURL);
         return $error = '<div class="alert alert-success" role="alert">Successfully user created!</div>';
      }else{
         return $error = '<div class="alert alert-danger" role="alert">Something is wrnog!</div>';
      }
   }
   
   public function user_password($data){
      $current_pass = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['current_pass']));
      $new_pass = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['new_pass']));
      $renew_pass = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['renew_pass']));
      $user_id = mysqli_real_escape_string($this->db->connect, $this->helper->validation(base64_decode($data['user_id'])));

      $pass_sql = "SELECT * FROM `tbl_admin` WHERE `tbl_admin`.`id` = '$user_id'";
      $row = $this->db->row($pass_sql);
      $fetch = $row->fetch_assoc();
      $check_pass = $fetch['password'];
        
      if (empty($current_pass) || empty($new_pass) || empty($renew_pass)) {
         return $error = '<div class="alert alert-danger" role="alert">Enter your password!</div>';
      }else{
         if (password_verify($current_pass, $check_pass)) {
            if ($new_pass == $renew_pass) {
               $set_pass = password_hash($new_pass, PASSWORD_BCRYPT);
               $sql = "UPDATE `tbl_admin` SET `tbl_admin`.`password` = '$set_pass' WHERE `tbl_admin`.`id` = '$user_id'";
               if ($this->db->run($sql)) {
                  return $error = '<div class="alert alert-success" role="alert">Password updated successfully!</div>';
               }else{
                  return $error = '<div class="alert alert-danger" role="alert">Something is wrnog!</div>';
               }
            }else{
               return $error = '<div class="alert alert-danger" role="alert">Your passwords do not match.</div>';
            }
         }else{
            return $error = '<div class="alert alert-danger" role="alert">Incorrect current password.</div>';
         }
      }
   }

   public function all_user(){
      $sql = "SELECT * FROM `tbl_admin` WHERE `tbl_admin`.`username` != 'admin@alex.com' ORDER BY `tbl_admin`.`amount` DESC";
      return $this->db->row($sql);
   }
   
   public function user_by_id($id){
      $sql = "SELECT * FROM `tbl_admin` WHERE `tbl_admin`.`id` = '$id'";
      return $this->db->row($sql);
   }

   public function user_remove($id){
      $sql = "DELETE FROM tbl_admin WHERE `tbl_admin`.`id` = '$id'";
      if ($this->db->run($sql)) {
         return $error = '<div class="alert alert-success" role="alert">Successfully user removed!</div>';
      }else{
         return $error = '<div class="alert alert-danger" role="alert">Something is wrnog!</div>';
      }
   }
   
   public function file_downlaod($charge, $user_id){
        $get_balance = $this->user_by_id($user_id);
        $value = $get_balance->fetch_assoc();
        $amount = $value['amount'];
        $deduction = $amount - $charge;

        if($charge <= $amount){
            $this->update_transaction($user_id, $deduction);
            return true; 
        }else{
            return false; 
        }
   }
   
   /*
    * Transaction
    */
    
   public function add_transaction($user_id, $trx_id, $amount){
      $sql = "INSERT INTO `tbl_transaction`(
         `user_id`,
         `trx_id`,
         `amount`
     )
     VALUES(
         '$user_id',
         '$trx_id',
         '$amount'
     )";
     
    $this->db->run($sql);
   }
   
   public function update_transaction($user_id, $balance){
      $sql = "UPDATE `tbl_admin` SET `amount` = '$balance' WHERE `tbl_admin`.`id` = '$user_id'";
      $this->db->run($sql);
   }
   
   public function all_transaction(){
        $sql = "SELECT
            `tbl_admin`.`username`,
            `tbl_transaction`.*
        FROM
            `tbl_transaction`
        INNER JOIN `tbl_admin` ON `tbl_transaction`.`user_id` = `tbl_admin`.`id`  
        ORDER BY `tbl_transaction`.`created` DESC";
        return $this->db->row($sql);
   }
   
   public function user_transaction($user_id){
        $sql = "SELECT
            `tbl_admin`.`username`,
            `tbl_transaction`.*
        FROM
            `tbl_transaction`
        INNER JOIN `tbl_admin` ON `tbl_transaction`.`user_id` = `tbl_admin`.`id`  
         WHERE `tbl_transaction`.`user_id` = '$user_id' ORDER BY `tbl_transaction`.`created` DESC";
      return $this->db->row($sql);
   }
   
   public function add_activity($user_id, $user_ip, $visit){
        $sql = "INSERT INTO `tbl_activity`(
            `user_id`,
            `user_ip`,
            `visit`
        )
        VALUES(
            '$user_id',
            '$user_ip',
            '$visit'
        )";
      return $this->db->run($sql);
   }
   
  public function remove_activity(){
    $timeLimit = time() - (24 * 60 * 60);
    $sql = "DELETE FROM tbl_activity WHERE `tbl_activity`.`created` < FROM_UNIXTIME($timeLimit)";
    $this->db->run($sql);
  }
  
  public function all_activity(){
        $sql = "SELECT
            `tbl_admin`.`username`,
            `tbl_activity`.*
        FROM
            `tbl_activity`
        INNER JOIN `tbl_admin` ON `tbl_activity`.`user_id` = `tbl_admin`.`id`  
        WHERE `tbl_admin`.`username` != 'admin@alex.com' ORDER BY `tbl_activity`.`created` DESC";
        return $this->db->row($sql);
   }
   
   public function user_activity($user_id){
        $sql = "SELECT
            `tbl_admin`.`username`,
            `tbl_activity`.*
        FROM
            `tbl_activity`
        INNER JOIN `tbl_admin` ON `tbl_activity`.`user_id` = `tbl_admin`.`id`  
        WHERE `tbl_activity`.`user_id` = '$user_id' AND `tbl_admin`.`username` != 'admin@alex.com' ORDER BY `tbl_activity`.`created` DESC";
        return $this->db->row($sql);
   }

  /*
   *  NID Sign Application
   */
  
  public function sign_application($type, $value, $name, $user_id){
    $type = mysqli_real_escape_string($this->db->connect, $this->helper->validation($type));
    $value = mysqli_real_escape_string($this->db->connect, $this->helper->validation($value));
    $name = mysqli_real_escape_string($this->db->connect, $this->helper->validation($name));
    
    $query = "SELECT * FROM `tbl_sign` WHERE `tbl_sign`.`value` = '$value' AND `tbl_sign`.`user_id` = '$user_id'";
    $check = $this->db->row($query);
    if (empty($type)) {
        return $error = '<div class="alert alert-danger" role="alert">Please select which Type of!</div>';
    }elseif (empty($value) || !preg_match('/^([0-9]*)$/', $value)){
        return $error = '<div class="alert alert-danger" role="alert">Please enter your type of ID No!</div>';
    }elseif ($check) {
        return $error = '<div class="alert alert-danger" role="alert"><i class="icon fa fa-ban"></i> This file already '.$value.' submited! Please wait for download...</div>';
    }elseif (empty($name)) {
        return $error = '<div class="alert alert-danger" role="alert">Please enter your name!</div>';
    }else{
     $sql = "INSERT INTO `tbl_sign`(
         `user_id`,
         `type`,
         `value`,
         `name`
     )
     VALUES(
         '$user_id',
         '$type',
         '$value',
         '$name'
     )";
    
        if($this->db->run($sql) === TRUE){
            $error = '<div class="alert alert-success" role="alert"><i class="fa fa-check-circle"></i> Successfully! NID sign copy application submited!</div>';
            return $error;
        } else{
            $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
            return $error;
        }
    }
  }
  
  public function update_sign_application($data, $file){
    $type = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['type']));
    $value = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['value']));
    $name = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['name']));
    $status = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['status']));
    $file_id = mysqli_real_escape_string($this->db->connect, $this->helper->validation(base64_decode($data['file_id'])));
    $user_id = mysqli_real_escape_string($this->db->connect, $this->helper->validation(base64_decode($data['user_id'])));
    
    $file_name   = $file['file']['name'];
    $file_size   = $file['file']['size'];
    $file_temp   = $file['file']['tmp_name'];
    $file_error  = $file['file']['error'];
    $file_valid  = array('pdf');
    $file_maxsize = 2097152;
    $file_ext    = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $file_unique = substr(md5(time()), 0, 10) . '.' .$file_ext;
    $file_path   = 'uploads/' . $file_unique;
    // End Step 1
    
    if(!empty($status)){
        if($status == 'Delivered'){
            if (empty($file_name)) {
                $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Please select your file.</div>';
                return $msg;
            } elseif(!in_array($file_ext, $file_valid)){
                $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Invalid file type only PDF types are accepted.</div>';
                return $msg;
            } elseif(($file_size >= $file_maxsize) || ($file_size == 0)){
                $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> File too large. File must be less than 2 MB.</div>';
                return $msg;
            } elseif (move_uploaded_file($file_temp, $file_path) === TRUE){
                $sql = "UPDATE `tbl_sign` SET `file` = '$file_path', `status` = '$status' WHERE `tbl_sign`.`id` = '$file_id'";
                if($this->db->run($sql) === TRUE){
                    $error = '<div class="alert alert-success" role="alert"><i class="fa fa-check-circle"></i> Successfully! NID sign copy file uploaded!</div>';
                    return $error;
                } else{
                    $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
                    return $error;
                }
            }   
        }
        
        if($status == 'Accepted'){
            $sql = "UPDATE `tbl_sign` SET `status` = '$status' WHERE `tbl_sign`.`id` = '$file_id'";
            if($this->db->run($sql) === TRUE){
                $error = '<div class="alert alert-primary" role="alert"><i class="fa fa-check-circle"></i> Successfully! NID sign copy file Accepted!</div>';
                return $error;
            } else{
                $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
                return $error;
            }
        }
        
        if($status == 'Cancelled'){
            $sql = "UPDATE `tbl_sign` SET `status` = '$status' WHERE `tbl_sign`.`id` = '$file_id'";
            if($this->db->run($sql) === TRUE){
                // add refund 
                $get_balance = $this->user_by_id($user_id);
                if($get_balance){
                    $value = $get_balance->fetch_assoc();
                    $amount = $value['amount'];
                    $charge = 30;
                    $add = $amount + $charge;
                    $this->update_transaction($user_id, $add);
                }
                $error = '<div class="alert alert-info" role="alert"><i class="fa fa-check-circle"></i> Successfully! NID sign copy file Cancelled!</div>';
                return $error;
            } else{
                $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
                return $error;
            }
        }
    }else{
        $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Please select your status!</div>';
        return $error;
    }
  }
  
  public function user_sign_application($user_id){
    $sql = "SELECT * FROM `tbl_sign` WHERE `tbl_sign`.`user_id` = '$user_id' ORDER BY `tbl_sign`.`id` DESC";
    return $this->db->row($sql);
  }
  
  public function all_sign_application(){
    $sql = "SELECT * FROM `tbl_sign` ORDER BY `tbl_sign`.`id` DESC";
    return $this->db->row($sql);
  }
  
  public function id_sign_application($id){
    $sql = "SELECT * FROM `tbl_sign` WHERE `tbl_sign`.`id` = '$id' ORDER BY `tbl_sign`.`id` DESC";
    return $this->db->row($sql);
  }
  
  public function remove_sign_application($id){
    $sql = "DELETE FROM `tbl_sign` WHERE `tbl_sign`.`id` = '$id'";
    if($this->db->run($sql)){
        $msg = '<div class="alert alert-success" role="alert"><i class="fa fa-check-circle"></i> Deleted successfully sign application!</div>';
        return $msg;
    }
  }
  
  
    /*
   *  NID Sign Application
   */
  
  public function add_biometric($data){
    $user_id = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['user_id']));
    $phone = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['phone']));
    $operator = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['operator']));
    $name = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['name']));
    $nid = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['nid']));
    $dob = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dob']));
    
    $query = "SELECT * FROM `tbl_biometric` WHERE `tbl_biometric`.`phone` = '$phone' AND `tbl_biometric`.`user_id` = '$user_id'";
    $check = $this->db->row($query);
    if (empty($phone) || !preg_match('/^([0-9]*)$/', $phone)){
        return $error = '<div class="alert alert-danger" role="alert">Please enter your valid phone number!</div>';
    }elseif ($check) {
        return $error = '<div class="alert alert-danger" role="alert"><i class="icon fa fa-ban"></i> This file already '.$phone.' submited! Please wait for status update...</div>';
    }else{
     $sql = "INSERT INTO `tbl_biometric`(
            `user_id`,
            `phone`,
            `operator`,
            `name`,
            `nid`,
            `dob`
        )
        VALUES(
            '$user_id',
            '$phone',
            '$operator',
            '$name',
            '$nid',
            '$dob'
        )";
    
        if($this->db->run($sql) === TRUE){
            $error = '<div class="alert alert-success" role="alert"><i class="fa fa-check-circle"></i> Successfully! SIM Biometric application submited!</div>';
            return $error;
        } else{
            $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
            return $error;
        }
    }
  }
  
  public function all_biometric($user_id){
    $sql = "SELECT * FROM `tbl_biometric` WHERE `tbl_biometric`.`user_id` = '$user_id' ORDER BY `tbl_biometric`.`id` DESC";
    return $this->db->row($sql);
  }
   /*
    * Surokkha
    */
    
   public function all_surokkha($user_id){
      $sql = "SELECT * FROM `tbl_surokkha` WHERE `tbl_surokkha`.`user_id` = '$user_id' ORDER BY `tbl_surokkha`.`id` DESC";
      return $this->db->row($sql);
   }

   public function surokkha_id($id){
      $sql = "SELECT * FROM `tbl_surokkha` WHERE `tbl_surokkha`.`id` = '$id'";
      return $this->db->row($sql);
   }

   public function add_surokkha($data){
      $certificate_no = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['certificate_no']));
      $nid_number = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['nid_number']));
      $birth_number = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['birth_number']));
      $passport_no = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['passport_no']));
      $name = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['name']));
      $name2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['name2']));
      $date_of_birth = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['date_of_birth']));
      $gender = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['gender']));
      $dose_date1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_date1']));
      $dose_vaccine1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine1']));
      $dose_vaccine11 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine11']));
      $dose_date2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_date2']));
      $dose_vaccine2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine2']));
      $dose_vaccine22 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine22']));
      $vaccination_center1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccination_center1']));
      $vaccination_center2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccination_center2']));
      $vaccination_center3 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccination_center3']));
      $vaccine_name1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccine_name1']));
      $vaccine_name2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccine_name2']));
      $verify_vaccine = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['verify_vaccine']));
      $user_id = mysqli_real_escape_string($this->db->connect, $this->helper->validation(base64_decode($data['user_id'])));
      $booster_date = $data['booster_date'];
   
      $customAlphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_0123456789';
      $generator = new RandomStringGenerator($customAlphabet);
      $generator->setAlphabet($customAlphabet);
      $tokenLength = 214;
      $token = $generator->generate($tokenLength);
      $url        = 'https://surokkha.gov.sebacenter.xyz/verify-online.php?id='.$token;
      $width      = 4;
      $margin     = 2;
      $compress   = true;
      $level      = 'L';
      $tempDir    = 'qrcode/';
      $extension  = ".png";
      $fileName   = uniqid() . $extension;
      $FilePath   = $tempDir . $fileName;

      $qrcode = QRcode::png($url, $FilePath, $level, $width, $margin, $compress);

      if(empty($nid_number || $birth_number)) {
          $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-times-circle"></i> Please Enter Your NID Number or Birth Certificate Number!</div>';
          return $msg;
      }

      if($birth_number != 'N/A'){
          if (strlen($birth_number) != 17) {  
              $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-times-circle"></i> Birth Certificate No must have 17 digits</div>';  
              return $msg;
          }
      }

      $sql = "INSERT INTO `tbl_surokkha`(
          `certificate_no`,
          `nid_number`,
          `birth_number`,
          `passport_no`,
          `name`,
          `name2`,
          `date_of_birth`,
          `gender`,
          `dose_date1`,
          `dose_vaccine1`,
          `dose_vaccine11`,
          `dose_date2`,
          `dose_vaccine2`,
          `dose_vaccine22`,
          `vaccine_name1`,
          `vaccine_name2`,
          `vaccination_center1`,
          `vaccination_center2`,
          `vaccination_center3`,
          `verify_vaccine`,
          `vaccine_limit`,
          `booster_date`,
          `qrcode`,
          `token`,
          `user_id`
      )
      VALUES(
          '$certificate_no',
          '$nid_number',
          '$birth_number',
          '$passport_no',
          '$name',
          '$name2',
          '$date_of_birth',
          '$gender',
          '$dose_date1',
          '$dose_vaccine1',
          '$dose_vaccine11',
          '$dose_date2',
          '$dose_vaccine2',
          '$dose_vaccine22',
          '$vaccine_name1',
          '$vaccine_name2',
          '$vaccination_center1',
          '$vaccination_center2',
          '$vaccination_center3',
          '$verify_vaccine',
          '0',
          '$booster_date',
          '$FilePath',
          '$token',
          '$user_id'
      )";
      $result = $this->db->run($sql);
      
      if ($result) {
          $msg = '<div class="alert alert-success" role="alert"><i class="fa fa-check-circle"></i> Vaccination certificates successfully added!</div>';
          return $msg;
      } else{
          $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
          return $msg;
      }
   }

   public function edit_surokkha($data){
      $id = mysqli_real_escape_string($this->db->connect, $this->helper->validation(base64_decode($data['id'])));
      $certificate_no = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['certificate_no']));
      $nid_number = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['nid_number']));
      $birth_number = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['birth_number']));
      $passport_no = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['passport_no']));
      $name = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['name']));
      $name2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['name2']));
      $date_of_birth = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['date_of_birth']));
      $gender = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['gender']));
      $dose_date1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_date1']));
      $dose_vaccine1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine1']));
      $dose_vaccine11 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine11']));
      $dose_date2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_date2']));
      $dose_vaccine2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine2']));
      $dose_vaccine22 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['dose_vaccine22']));
      $vaccination_center1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccination_center1']));
      $vaccination_center2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccination_center2']));
      $vaccination_center3 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccination_center3']));
      $vaccine_name1 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccine_name1']));
      $vaccine_name2 = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['vaccine_name2']));
      $verify_vaccine = mysqli_real_escape_string($this->db->connect, $this->helper->validation($data['verify_vaccine']));
      $booster_date = $data['booster_date'];

      date_default_timezone_set('Asia/Dhaka');
      $date = date('d-m-Y');

      if(empty($nid_number || $birth_number)) {
          $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-times-circle"></i> Please Enter Your NID Number or Birth Certificate Number!</div>';
          return $msg;
      }

      if($birth_number != 'N/A'){
          if (strlen($birth_number) != 17) {  
              $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-times-circle"></i> Birth Certificate No must have 17 digits</div>';  
              return $msg;
          }
      }
      
      $customAlphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_0123456789';
      $generator = new RandomStringGenerator($customAlphabet);
      $generator->setAlphabet($customAlphabet);
      $tokenLength = 214;
      $token = $generator->generate($tokenLength);

      //url        = DOMAIN.FILENAME.'?id='.$token;
      $url        = 'https://surokkha.gov.sebacenter.xyz/verify-online.php?id='.$token;
      $width      = 4;
      $margin     = 2;
      $compress   = true;
      $level      = 'L';
      $tempDir    = 'qrcode/';
      $extension  = ".png";
      $fileName   = uniqid() . $extension;
      $FilePath   = $tempDir . $fileName;

      $qrcode = QRcode::png($url, $FilePath, $level, $width, $margin, $compress);

      $sql = "UPDATE
          `tbl_surokkha`
          SET
          `certificate_no` = '$certificate_no',
          `nid_number` = '$nid_number',
          `birth_number` = '$birth_number',
          `passport_no` = '$passport_no',
          `name` = '$name',
          `name2` = '$name2',
          `date_of_birth` = '$date_of_birth',
          `gender` = '$gender',
          `dose_date1` = '$dose_date1',
          `dose_vaccine1` = '$dose_vaccine1',
          `dose_vaccine11` = '$dose_vaccine11',
          `dose_date2` = '$dose_date2',
          `dose_vaccine2` = '$dose_vaccine2',
          `dose_vaccine22` = '$dose_vaccine22',
          `vaccine_name1` = '$vaccine_name1',
          `vaccine_name2` = '$vaccine_name2',
          `vaccination_center1` = '$vaccination_center1',
          `vaccination_center2` = '$vaccination_center2',
          `vaccination_center3` = '$vaccination_center3',
          `verify_vaccine` = '$verify_vaccine',
          `vaccine_limit` = '0',
          `booster_date` = '$booster_date',
          `qrcode` = '$FilePath',
          `token` = '$token'
      WHERE
      `tbl_surokkha`.`id`= '$id'";
      $result = $this->db->run($sql);

      if ($result) {
          $msg = '<div class="alert alert-success" role="alert"><i class="fa fa-check-circle"></i> Vaccination certificates successfully updated!</div>';
          return $msg;
      } else{
          $msg = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Something is wrong!</div>';
          return $msg;
      }
   }
   public function chk_nidServer($nid, $dob) {
        // Sanitize input
        $nid = mysqli_real_escape_string($this->db->connect, $this->helper->validation($nid));
        $dob = mysqli_real_escape_string($this->db->connect, $this->helper->validation($dob));

        // Validate NID: Must be numeric and not empty
        if (empty($nid)) {
            return '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> এনআইডি নম্বরটি প্রদান করুন!</div>';
        } elseif (!is_numeric($nid)) {
            return '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> এনআইডি নম্বরটি শুধুমাত্র সংখ্যাসূচক হতে হবে!</div>';
        }

        // Validate DOB: Must be a valid date and not empty
        if (empty($dob)) {
            return '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> আপনার জন্ম তারিখ দিন!</div>';
        } elseif (!strtotime($dob)) {  // Check if DOB is a valid date
            return '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> সঠিক জন্ম তারিখ প্রদান করুন!</div>';
        }
    }

}
?>