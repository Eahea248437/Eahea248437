<?php
/*
* Autoloader Class System
*/
spl_autoload_register(static function($class_Name){
  $filepath = realpath(__DIR__);
  require_once $filepath.'/'.$class_Name.'.php';
  //echo $class_Name.'<br>';
});

$db  = new Database();
$admin = new Admin();
$helper = new Helper();
$session = new Session();