<?php
/**

* Database

*/

require_once 'config.php';

class Database{
	public $host 	= DB_SERVER;
	public $user 	= DB_USERNAME;
	public $pass 	= DB_PASSWORD;
	public $dbname 	= DB_NAME;
	public $connect;
	public $error;

	public function __construct(){
		$this->connectDB();
	}

	private function connectDB(){

		$this->connect = new mysqli($this->host, $this->user, $this->pass, $this->dbname);

		// Check connection

		if(!$this->connect){

		    $this->error = "ERROR: Could not connect. " . $this->connect->connect_error;

		    return false;

		}

	}



	// Select or Read Database

	public function row($sql){

		$result = $this->connect->query($sql) or die($this->connect->error.__LINE__);

		if ($result->num_rows > 0) {

			return $result;

		} else{

			return false;

		}

	}



	public function run($sql){

        $result = $this->connect->query($sql) or die($this->connect->error.__LINE__);

		if ($result) {

			return $result;

		} else{

			return false;

		}

	}



	public function lastID(){

		$last_id = $this->mysqli->insert_id or die($this->mysqli->error.__LINE__);

		if ($last_id) {

			return $last_id;

		} else{

			return false;

		}

	}



	public function redirect($url) {

       header("Location: $url");

	   exit;

   }

}

?>