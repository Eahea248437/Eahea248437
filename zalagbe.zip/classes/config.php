<?php
//error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT & ~E_NOTICE & ~E_WARNING);

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')) ? "https://" : "http://";
$home = $protocol . $_SERVER['HTTP_HOST'];
$script = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/';
$root = "$home$script";
$canonical = $home . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Database Config
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'zalamhad_db');
define('DB_PASSWORD', 'zalamhad_db');
define('DB_NAME', 'zalamhad_db');

// App Root
define('APPROOT', dirname(__DIR__));
// URL Root
define('BASEURL', $root);
define('SITEURL', 'https://zalagbe.store/');
define('DOMAIN', 'https://zalagbe.store/');


?>