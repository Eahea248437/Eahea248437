<?php
$page = 'new-brith';
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>New Birth Certificate - ৳ 10</h1>
    </div>

    <section class="section">
      <div class="container">
          <?php
            if($default_amount >= $get_user['amount']){
                echo $fund = '<div class="alert alert-danger" role="alert">Insufficient balance in your account. Kindly recharge your account balance to proceed.</div>';
            }
            ?>
          <div class="row justify-content-center" style="padding:10px;border:2px solid blue;margin-bottom:10px;border-radius:5px;max-width:500px;margin:0 auto">
              <p id="nid-msg" class="text-center"></p>
              <h3 class="text-center"> Enter Birth Info </h3>
              <div class="col-xl-8">
                  <label class="form-label">Birt Reg No</label>
                  <input id="nid-n" type="text" class="form-control"><br>
                  <label class="form-label">Date of Birth</label>
                  <input id="nid-d" type="date" class="form-control"><br>
                  <center><button class="btn btn-success" id="nid-btn">Get Info</button></center>
              </div>
          </div><br>
          <h1 class="text-center">OR</h1>
      </div>

        <form action="view" method="post">
            <div id="app">
                <div class="main-wrapper main-wrapper-1">
                    <div class="main-content" style="min-height: 530px;">
                        <section class="bg-diffrent">
                            <div class="container">
                                <div id="formdata">
                                    <h3 style="text-align: center; border: 1px solid darkblue; padding: 18px 5px; font-size: 22px; min-width: 285px; margin: 5px; margin-bottom: 32px; border-radius: 10px; background: darkblue; color: #fff;">
                                        সঠিক তথ্য সাবমিট করুন পিডিএফ ডাউনলোড করার জন্য
                                    </h3>
                              
                                    <div class="row mt-5">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Address 1</label>
                                                <input type="text" name="address1" id="address1" class="form-control" placeholder="Address 1" value="" required>
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Address 2</label>
                                                <input type="text" name="address2" id="address2" class="form-control" placeholder="Address 2" value="" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Birth Registration Number</label>
                                                <input type="text" name="brn" id="brn" class="form-control" placeholder="Ex : 20005467654345678" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Date of Registration</label>
                                                <input type="text" name="dor" id="dor" class="form-control" placeholder="Ex : 05/11/2023" required>
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Date of Issuance</label>
                                                <input type="text" name="doi" id="doi" class="form-control" value="05/11/2023" required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Date of Birth</label>
                                                <input type="text" name="dob" id="dob" class="form-control" placeholder="05/11/2023" required>
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Sex</label>
                                                <select name="sex" id="sex" class="form-select">
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">নাম (বাংলা)</label>
                                                <input type="text" name="name_bangla" id="name_bangla" class="form-control" placeholder="নাম লেখুন... required">
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Name (English)</label>
                                                <input type="text" name="name_english" id="name_english" class="form-control" placeholder="Inter your name..." required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">পিতা নাম (বাংলা)</label>
                                                <input type="text" name="father_bangla" id="father_bangla" class="form-control" placeholder="পিতা নাম লেখুন... required">
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Father Name (English)</label>
                                                <input type="text" name="father_english" id="father_english" class="form-control" placeholder="Inter your father name..." required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">মাতার নাম (বাংলা)</label>
                                                <input type="text" name="mother_bangla" id="mother_bangla" required class="form-control" placeholder="মাতার নাম লেখুন...">
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Mother Name (English)</label>
                                                <input type="text" name="mother_english" id="mother_english" class="form-control" placeholder="Inter your mother name..." required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">জন্মস্থান (বাংলা)</label>
                                                <input type="text" name="pob_bangla" id="pob_bangla" class="form-control" required value="" placeholder="জন্মস্থান লেখুন...">
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Place of Birth (English)</label>
                                                <input type="text" name="pob_english" id="pob_english" class="form-control" required value="" placeholder="Inter your place of birth...">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">স্থায়ী ঠিকানা (বাংলা)</label>
                                                <textarea name="permanent_bangla" id="permanent_bangla" cols="30" rows="2" required class="form-control" placeholder="স্থায়ী ঠিকানা লেখুন..."></textarea>
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Permanent (English)</label>
                                                <textarea name="permanent_english" id="permanent_english" cols="30" rows="2" required class="form-control" placeholder="Inter your permanent..."></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">পিতার জাতীয়তা (বাংলা)</label>
                                                <input type="text" name="father_n_bangla" id="father_n_bangla" class="form-control" required value="বাংলাদেশ" placeholder="পিতার জাতীয়তা লেখুন...">
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Father Nationality (English)</label>
                                                <input type="text" name="father_n_english" id="father_n_english" class="form-control" required value="Bangladesh" placeholder="Inter your father nationality...">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">মাতার জাতীয়তা (বাংলা)</label>
                                                <input type="text" name="mother_n_bangla" id="mother_n_bangla" class="form-control" required value="বাংলাদেশ" placeholder="মাতার জাতীয়তা লেখুন...">
                                            </div>
                                        </div>

                                        <div class="col-md-6 mb-4">
                                            <div class="form-group">
                                                <label class="form-label" for="first">Mother Nationality (English)</label>
                                                <input type="text" name="mother_n_english" id="mother_n_english" class="form-control" required value="Bangladesh" placeholder="Inter your mother nationality...">
                                            </div>
                                        </div>
                                    </div>

                                    <div style="display: flex; justify-content: center; margin-bottom: 50px;">
                                        <button style="width: 40%;" class="btn btn-success d-block m-auto mt-5" type="submit">Submit</button>
                                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </form>
    </section>
</main>
<script src="js/jquery.min.js"></script>
<script src="js/birth.js"></script>
<?php
require_once($filepath.'/../inc/footer.php');
?>