<?php
$filepath = realpath(__DIR__);
require_once $filepath.'/../inc/loader.php';
Session::checkSession();
$csrf_token =  Session::get('csrf_token');
$user_id =  Session::get('user_id');
$default_amount = 10;
$get_user = $admin->user_by_id(base64_decode($user_id))->fetch_assoc();
if($default_amount > $get_user['amount']){
    header('Location: ../');
}else{
    if(empty($_POST['permanent_bangla'])){
        header('Location: ../');
    }else{
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
            header('Location: ../');
        }
    }
}

$ubrn = isset($_POST['brn']) ? $_POST['brn'] : '';
$dob = isset($_POST['dob']) ? $_POST['dob'] : '';
$url = 'https://maclinic.xyz/birth.php?ubrn='.$ubrn.'&dob='.$dob;
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
));
$content = curl_exec($curl);
curl_close($curl);
$content = json_decode($content);
if (isset($content->success) && $content->success == true ){
    $charge = 10;
    $admin->file_downlaod($charge, base64_decode($user_id));
    
    $personname = $content->personname;
    $personnameEn = $content->personnameEn;
    $mothername = $content->mothername;
    $mothernameEn = $content->mothernameEn;
    $motherNationality = $content->motherNationality;
    $motherNationalityEn = $content->motherNationalityEn;
    $fathername = $content->fathername;
    $fathernameEn = $content->fathernameEn;
    $fatherNationality = $content->fatherNationality;
    $fatherNationalityEn = $content->fatherNationalityEn;
    $sex = $content->sex;
    $placeofbirth = $content->placeofbirth;
    $placeofbirthEn = $content->placeofbirthEn;
}else{
    //header('Location: index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script>
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey) {
            e.preventDefault();
        }
    });
    </script>
    <title>Birth Certificate</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.0/css/bootstrap.min.css" integrity="sha512-NZ19NrT58XPK5sXqXnnvtf9T5kLXSzGQlVZL9taZWeTBtXoN3xIfTdxbkQh6QSoJfJgpojRqMfhyqBAAEeiXcA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="fonts/kalpurush.css" rel="stylesheet">
    <link rel="stylesheet" href="./css/new.css">
    <style type="text/css">
        .bn{
            font-family: 'Kalpurush' !important;;
        }
    </style>
    <style type="text/css" media="print">
    @page {
        margin: 0 !important;
        size: A4 !important;
        color-adjust: exact !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        background-color: #fff !important;
        
    }

    @media print {
        html,
        body {
            width: 210mm !important;
            height: 297mm !important;
            background-color: #fff !important;
        }
        .print {
            display: none !important;
        }
    }
    </style>
</head>

<body>
    <header id="header" class="print header d-flex align-items-center" style="background: #ddd; padding: 5px">
         <nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
            <ul class="d-flex align-items-center">
               <li class="nav-item dropdown" style="list-style: none;">
                  <a href="<?php echo SITEURL; ?>" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;">Home</a>
                  <button type="button" onclick="window.print();" class="btn btn-success mb-2 mt-2" style="margin-left: 8px;">Print</button>
               </li>
            </ul>
         </nav>
         <!-- End Icons Navigation -->
      </header>
    <div class="a4_page">
        <div class="main_wrapper" id="pdf-content">
            <img src="./img/ri_1.png" class="main_logo" alt="">
            <span style="z-index: 10;">
                <div class="mr_header">
                    <div class="left_part_hidden"></div>
                    <div class="left_part">
                        <img style="height:110px; width:110px;" src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://bdris.gov.bd/certificate/verify?key=qYd16yZ9rZh30FguHn4tpu5izeOIssqHhyEfjZmfFFzXuKTgo/2HxCS" alt="">
                        <h2>
                            <?php
                                $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                                $randomString = '';

                                for ($i = 0; $i < 5; $i++) {
                                    $randomString .= $characters[rand(0, strlen($characters) - 1)];
                                }

                                echo $randomString;
                            ?>
                        </h2>
                    </div>
                    <div class="middle_part">
                        <img src="./img/bd_logo.png" alt="" class="main_logo_r">
                        <img src="./img/bd_logo.png" alt="" style="opacity: 0;">
                        <h2>Government of the People’s Republic of Bangladesh</h2>
                        <p class="office">Office of the Registrar, Birth and Death Registration</p>
                        <p class="address1"><?php echo $_POST['address1']; ?></p>
                        <p class="address2"><?php echo $_POST['address2']; ?></p>
                        <p class="rule_y">(Rule 9, 10)</p>
                        <h1><span class="bn">জন্ম নিবন্ধন সনদ /</span> <span class="en">Birth Registration Certificate</span></h1>
                    </div>
                    <div class="right_part_hidden"></div>
                    <div class="right_part">
                        <canvas style="height: 26px; width:220px;" id="barcode"></canvas>
                    </div>
                </div>

                <div class="mr_body">
                    <div class="top_part1">
                        <div class="left">
                            <p>Date of Registration</p>
                            <p><?php echo $_POST['dor']; ?></p>
                        </div>
                        <div class="middle">
                            <h2>Birth Registration Number</h2>
                            <h1><?php echo $ubrn; ?></h1>
                        </div>
                        <div class="right">
                            <p>Date of Issuance</p>
                            <p><?php echo $_POST['doi']; ?></p>
                        </div>
                    </div>


                    <div class="middle">
                        <div style="margin-top: 2px;margin-bottom: 5px;" class="new_td_2">
                            <div class="left">
                                <div class="part1">
                                    <p>Date of Birth<span style="margin-left: 42px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span><?php echo $dob_date = date("d-m-Y", strtotime(strtr($dob, '/', '-'))); ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p><span style="margin-left: 95px;" class="clone">Sex :</span></p>
                                </div>
                                <div class="part2">
                                    <p><span><?php if($_POST['sex'] == 'Male'){ echo 'Male'; } if($_POST['sex'] == 'Female'){ echo 'Female'; } ?></span></p>
                                </div>
                            </div>
                        </div>


                        <div style="margin-top: 5px;margin-bottom: 24px !important;" class="td">
                            <div class="left">
                                <div style="width: 130px;" class="part1">
                                    <p>In Word<span>:</span></p>
                                </div>
                                <div class="part2" style="width: 400px;">

                                    <p><span style="margin-left:5px"> <?php
                                    
                                    function yearToWords($number) {
                                        $fmt = new NumberFormatter("en", NumberFormatter::SPELLOUT);
                                        $numberStr = (string) $number;
                                    	$length = strlen($numberStr);
                                    	$part1 = (int) substr($numberStr, 0, $length / 2);
                                    	$part2 = (int) substr($numberStr, $length / 2);
                                    	$one_year = str_replace(' ', ' ', ucwords(str_replace(' ', ' ', str_replace("-", " ", $fmt->format($part1)))));
                                    	$two_year = str_replace(' ', ' ', ucwords(str_replace(' ', ' ', str_replace("-", " ", $fmt->format($part2)))));
                                    
                                    	return $one_year.' '.$two_year;
                                    }
                                    
                                    $f = new NumberFormatter("en", NumberFormatter::SPELLOUT);
                                    $dob_in_d = date("d", strtotime(strtr($dob, '/', '-')));
                                    $dob_in_m = date("F", strtotime(strtr($dob, '/', '-')));
                                    $dob_in_y = date("Y", strtotime(strtr($dob, '/', '-')));
                                    $dob_word = $f->format($dob_in_d).' Of '.$dob_in_m.' '.yearToWords($dob_in_y);
                                    $dob_string = implode(" ", explode("-", $dob_word));
                                    echo mb_convert_case($dob_string, MB_CASE_TITLE, 'UTF-8');
                                    ?> </span></p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 7px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p class="bn">নাম<span style="margin-left: 103px;" class="clone">:</span></p>
                                </div>
                                <div class="part2" id="name_data_bn">
                                    <p><span class="bn"><?php echo $_POST['name_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="font-weight:500">Name<span style="margin-left: 95px;" class="clone">:</span> </p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['name_english']; ?></span></p>
                                </div>
                            </div>
                        </div>

                        <div id="mother_content" style="margin-top: 17px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p class="bn">মাতা<span style="margin-left: 98px;" class="clone">:</span></p>
                                </div>
                                <div class="part2" id="motherName_data_bn">
                                    <p><span class="bn"><?php echo $_POST['mother_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="font-weight:500">Mother<span style="margin-left: 87px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['mother_english']; ?></span></p>
                                </div>
                            </div>
                        </div>

                        <div id="motherNanality_content" style="margin-top: 17px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p class="bn">মাতার জাতীয়তা<span style="margin-left: 34px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span class="bn"><?php echo $_POST['mother_n_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="font-weight:500">Nationality<span style="margin-left: 64px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['mother_n_english']; ?></span></p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 16px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p class="bn">পিতা<span style="margin-left: 96px;" class="clone">:</span></p>
                                </div>
                                <div class="part2" id="fatherName_data_bn">
                                    <p><span class="bn"><?php echo $_POST['father_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="font-weight:500">Father<span style="margin-left: 91px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['father_english']; ?></span></p>
                                </div>
                            </div>
                        </div>

                        <div id="fatherNanality_content" style="margin-top: 17px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p class="bn">পিতার জাতীয়তা<span style="margin-left: 34px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span class="bn"><?php echo $_POST['father_n_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="font-weight:500">Nationality<span style="margin-left: 65px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['father_n_english']; ?></span></p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 17px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p class="bn">জন্মস্থান<span style="margin-left: 80px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span class="bn"><?php echo $_POST['pob_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="width: 153px; font-weight:500">Place of Birth<span style="margin-left: 46px;margin-right: 0;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['pob_english']; ?></span></p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top: 30px;" class="new_td">
                            <div class="left">
                                <div class="part1">
                                    <p style="width: 146px;" class="bn">স্থায়ী ঠিকানা<span style="margin-left:57px;margin-right: 0;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span class="bn"><?php echo $_POST['permanent_bangla']; ?></span></p>
                                </div>
                            </div>
                            <div class="right">
                                <div class="part1">
                                    <p style="display:flex; width:154px; font-weight:500">Permanent<br>Address<span style="margin-left: 64px;" class="clone">:</span></p>
                                </div>
                                <div class="part2">
                                    <p><span style="font-weight:500"><?php echo $_POST['permanent_english']; ?></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </span>

            <div class="mr_footer">
                <div class="top">
                    <div class="left">
                        <h2 style="width:10rem; margin-top: 0px;">Seal & Signature</h2>
                        <p style="margin-top: 0px;">Assistant to Registrar</p>
                        <p style="margin-top: 0px;">(Preparation, Verification)</p>
                    </div>
                    <div class="right">
                        <h2 style="width:10rem">Seal & Signature<h2>
                        <p>Registrar</p>
                    </div>
                </div>
                <div style="margin-top:8rem" class="bottom">
                    <p>This certificate is generated from bdris.gov.bd, and to verify this certificate, please scan the above QR Code & Bar Code.</p>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/JsBarcode.all.min.js"></script>
    <script>
        let dob_n = "<?php echo $ubrn; ?>";
        JsBarcode("#barcode", dob_n, {
            format: "CODE128",
            displayValue: false,
        });
    </script>
    <?php
    $filepath = realpath(__DIR__);
    require_once($filepath.'/../inc/protect.php');
    ?>
</body>

</html>