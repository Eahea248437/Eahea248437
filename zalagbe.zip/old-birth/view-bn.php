<?php
$filepath = realpath(__DIR__);
require_once $filepath.'/../inc/loader.php';
require 'vendor/autoload.php';
use Rakibhstu\Banglanumber\NumberToBangla;
Session::checkSession();
$csrf_token =  Session::get('csrf_token');
$user_id =  Session::get('user_id');
$default_amount = 10;
$get_user = $admin->user_by_id(base64_decode($user_id))->fetch_assoc();
if($default_amount > $get_user['amount']){
    header('Location: ../');
}else{
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
             header('Location: ../');
          }else{
             $charge = 10;
             $admin->file_downlaod($charge, base64_decode($user_id));  
          }  
    }
}
?>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">        
        <title>Old Birth Certificate</title>
        <link rel="stylesheet" href="css/bn.css">
        
    
       <style type="text/css" media="print">
        @page 
        {
            size:  auto;   /* auto is the initial value */
            margin: 0mm;  /* this affects the margin in the printer settings */
        }

        html
        {
            background-color: #FFFFFF; 
            margin: 0px;  /* this affects the margin on the html before sending to printer */
        }

        body
        {
            border: solid 0px blue ;
            margin: 10mm 15mm 10mm 15mm; /* margin you want for the content */
        }
    </style>
</head>
    <body>
          <header id="header" class="print header d-flex align-items-center" style="background: #ddd; padding: 5px">
         <nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
            <ul class="d-flex align-items-center">
               <li class="nav-item dropdown" style="list-style: none;">
                  <a href="<?php echo SITEURL; ?>" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;background: blue;padding: 6px 30px;color: #fff;border: none;border-radius: 4px;">Home</a>
                  <button type="button" onclick="window.print();" style="margin-left: 8px;background: green;padding: 6px 30px;color: #fff;border: none;border-radius: 4px;">Print</button>
               </li>
            </ul>
         </nav>
         <!-- End Icons Navigation -->
      </header>
        <div id="root">
            <div class="full mx-auto">
                <div class="flex flex-row">
                    <div class="!w-full">
                        <div class="mx-auto">
                            <div class="flex justify-center items-center flex-col gap-6 my-10">
                                <div class="w-[660px] h-[890px] mx-auto border">
                                    <div class="relative after:absolute after:rounded-sm after:content-[''] after:top-0 after:right-0 after:w-full after:h-full after:border-[1.9px] after:border-black before:absolute before:content-[''] before:-top-[15px] before:-right-[15px] before:w-[687px] before:h-[920px] before:border-[2px] before:border-black before:rounded-sm">
                                        <div class="relative w-full h-[890px] !overflow-hidden bg-cover bg-no-repeat">
                                            <img class="w-full h-full opacity-20" src="./img/bg.jpeg" alt="image">
                                            <div class="absolute top-0 right-0 w-full h-full z-50 p-2">
                                                <div class="relative">
                                                    <h1 class="absolute top-2 right-2 !text-[11.50px] font-semibold !font-nikosh !font-extrabold">জমনি ফরম-৩</h1>
                                                    <div class="text-center">
                                                        <h1 class="font-bold !text-[17.50px] !font-nikosh !font-extrabold">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</h1>
                                                        <h2 class="!font-nikosh !font-extrabold !text-[12.50px] font-semibold">জন্ম ও মৃত্যু নিবন্ধকের কার্যালয়</h2>
                                                        <p class="!font-nikosh !font-extrabold !text-[12.50px]"><?php echo $_POST['address1']; ?></p>
                                                        <p class="!font-nikosh !font-extrabold mt-2 !text-[12.50px]"><?php echo $_POST['address2']; ?></p>
                                                        <p class="!font-nikosh !font-extrabold mb-1 !text-[12.50px]"><?php echo $_POST['address3']; ?></p>
                                                        <p class="!font-nikosh !font-extrabold !text-[16.50px] !font-bold">জন্ম নিবন্ধন সনদ</p>
                                                        <div class="text-[11.50px] text-center font-semibold flex justify-center">
                                                            [
                                                            <p class="!font-nikosh !font-extrabold text-[11.50px] text-center font-semibold mx-[2px]">বিধি ৯ ও ১০ দ্রষ্টব্য</p>
                                                            ]
                                                        </div>
                                                        <div class="text-[11.50px] text-center font-semibold flex justify-center">
                                                            (
                                                            <p class="!font-nikosh !font-extrabold text-[11.50px] text-center font-semibold mx-[2px]">জন্ম নিবন্ধন বহি হতে উদ্ধৃত</p>
                                                            )
                                                        </div>
                                                    </div>
                                                    <div class="flex justify-between">
                                                        <div class="flex flex-col justify-start gap-3">
                                                            <div class="flex flex-row">
                                                                <p class="!font-nikosh !font-extrabold w-[130px] !text-[11.50px]">নিবন্ধন বহি নম্বরঃ</p>
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['registerNo']; ?></p>
                                                            </div>
                                                            <div class="flex flex-row">
                                                                <p class="!font-nikosh !font-extrabold w-[130px] capitalize !text-[11.50px]">নিবন্ধনের তারিখঃ</p>
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['dor']; ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="flex flex-row justify-end gap-1">
                                                            <p class="!font-nikosh !font-extrabold capitalize !text-[11.50px]">সনদ প্রদানের তারিখঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize"><?php echo $_POST['doi']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="flex flex-row items-center my-2">
                                                        <p class="!font-nikosh !font-extrabold w-[130px] !text-[11.50px]">জন্ম নিবন্ধন নাম্বারঃ</p>
                                                        <div class="relative">
                                                            <div class="border border-black flex">
                                                            <?php
                                                            $bengaliNumber = $_POST['brNo']; // Replace this with your 17-digit Bengali number

                                                            // Determine the length of each part
                                                            $partLength = 1;

                                                            // Initialize an array to store the parts
                                                            $parts = [];

                                                            // Split the string into smaller parts using a loop
                                                            for ($i = 0; $i < mb_strlen($bengaliNumber, 'UTF-8'); $i += $partLength) {
                                                                $parts[] = mb_substr($bengaliNumber, $i, $partLength, 'UTF-8');
                                                            }

                                                            // Display the parts
                                                            foreach ($parts as $index => $part) {
                                                                echo '<div class="w-[28.30px] h-[35px] border-r last:border-none border-black flex justify-center items-center"><p class="!font-nikosh !font-extrabold !text-[11.50px]">'.$part.'</p></div>';
                                                            }
                                                            ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="flex flex-row">
                                                        <p class="!font-nikosh !font-extrabold w-[130px] !text-[11.50px] capitalize">নামঃ</p>
                                                        <p class="!font-nikosh !font-extrabold !text-[13px]"><?php echo $_POST['name']; ?></p>
                                                    </div>
                                                    <div class="flex justify-between items-center">
                                                        <div class="flex flex-row items-center my-4">
                                                            <p class="!font-nikosh !font-extrabold w-[130px] !text-[11.50px] capitalize">জন্ম তারিখঃ</p>
                                                            <div class="relative">
                                                                <div class="border border-black flex">
                                                                <?php
                                                            $dobNumber = $_POST['dob']; // Replace this with your 17-digit Bengali number

                                                            // Determine the length of each part
                                                            $dobpartLength = 1;

                                                            // Initialize an array to store the parts
                                                            $dobparts = [];

                                                            // Split the string into smaller parts using a loop
                                                            for ($dobi = 0; $dobi < mb_strlen($dobNumber, 'UTF-8'); $dobi += $dobpartLength) {
                                                                $dobparts[] = mb_substr($dobNumber, $dobi, $dobpartLength, 'UTF-8');
                                                            }

                                                            // Display the parts
                                                            foreach ($dobparts as $dobindex => $dobpart) {
                                                                $din = $dobindex + 1;
                                                                if($dobpart == '/'){
                                                                    echo '<div class="bg-black w-4 h-5 border-r last:border-none border-black flex justify-center items-center"><p class="text-[11.50px]">/</p></div>';
                                                                } else{
                                                                    echo '<div class="w-4 h-5 border-r last:border-none border-black flex justify-center items-center"><p class="!font-nikosh !font-extrabold !text-[11.50px]">'.$dobpart.'</p></div>';
                                                                }
                                                                
                                                            }
                                                            ?>    
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="w-[221px] flex flex-row gap-1">
                                                            <p class="!font-nikosh !font-extrabold capitalize !text-[11.50px]">লিঙ্গঃ</p>
                                                            <p class="!font-nikosh !font-extrabold capitalize !text-[11.50px]"><?php echo $_POST['gendar']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="flex justify-between">
                                                        <div class="flex flex-row">
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px] w-[130px] capitalize">কথায়ঃ</p>
                                                            <?php 
                                                            function banglaToEnglishNumber($banglaNumber){
                                                                $banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
                                                                $englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
                                                            
                                                                $englishNumber = str_replace($banglaDigits, $englishDigits, $banglaNumber);
                                                            
                                                                return $englishNumber;
                                                            }

                                                            $englishNumber = banglaToEnglishNumber($dobNumber);
                                        
                                                            $dateArray = explode('/', $englishNumber);
                                                            $numto = new NumberToBangla($dateArray);
                                                            $day = $numto->bnWord($dateArray[0]);
                                                            $month = $numto->bnMonth($dateArray[1]);
                                                            $year = $numto->bnWord($dateArray[2]);
                                                            ?>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.5px]"><?php echo $day.' '.$month.' '.$year; ?></p>
                                                        </div>
                                                        <div class="w-[221px] flex flex-row gap-1">
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize">সন্তানের ক্রমঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['ooc']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="flex flex-col my-4 gap-3">
                                                        <div class="flex flex-row">
                                                            <p class="!font-nikosh !font-extrabold w-[130px] !text-[11.50px] capitalize">জন্মস্থানঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize"><?php echo $_POST['pob']; ?></p>
                                                        </div>
                                                        <div class="flex flex-row mt-1">
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px] !w-[130px] !max-w-[130px] capitalize">স্থায়ী ঠিকানাঃ</p>
                                                            <div class="w-[512px] !overflow-hidden flex flex-col">
                                                                <div class="w-[1000px]"><p class="!font-nikosh !font-extrabold px-[2px] !text-[11.50px]"><?php echo $_POST['fullAddress']; ?></p></div>
                                                                <!-- <div class="w-[1000px]"><p class="!font-nikosh !font-extrabold px-[2px] !text-[11.50px]"></p></div> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="w-full mx-auto mt-5 rounded-sm border border-black p-2">
                                                        <div class="flex flex-row">
                                                            <p class="w-[178px] !font-nikosh !font-extrabold capitalize !text-[11.50px]">পিতার নামঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize"><?php echo $_POST['fatherName']; ?></p>
                                                        </div>
                                                        <div class="flex justify-between items-center">
                                                            <div class="flex flex-row">
                                                                <p class="w-[178px] !font-nikosh !font-extrabold !text-[11.50px]">পিতার জন্ম নিবন্ধন নম্বরঃ</p>
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['fatherBrn']; ?></p>
                                                            </div>
                                                            <div class="mr-[62px] flex flex-row gap-1">
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize">পিতার জাতীয়তাঃ</p>
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize"> <?php echo $_POST['fatherNationality']; ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="flex flex-row">
                                                            <p class="w-[178px] !font-nikosh !font-extrabold !text-[11.50px]">পিতার জাতীয় পরিচয়পত্র নম্বরঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['fatherNid']; ?></p>
                                                        </div>
                                                        <div class="flex flex-row mt-4">
                                                            <p class="w-[178px] !font-nikosh !font-extrabold capitalize !text-[11.50px]">মাতার নামঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['motherName']; ?></p>
                                                        </div>
                                                        <div class="flex justify-between items-center">
                                                            <div class="flex flex-row">
                                                                <p class="w-[178px] !font-nikosh !font-extrabold !text-[11.50px]">মাতার জন্ম নিবন্ধন নম্বরঃ</p>
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['motherBrn']; ?></p>
                                                            </div>
                                                            <div class="mr-[62px] flex flex-row gap-1">
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize">মাতার জাতীয়তাঃ</p>
                                                                <p class="!font-nikosh !font-extrabold !text-[11.50px] capitalize"> <?php echo $_POST['motherNationality']; ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="flex flex-row">
                                                            <p class="w-[178px] !font-nikosh !font-extrabold !text-[11.50px]">মাতার জাতীয় পরিচয়পত্র নম্বরঃ</p>
                                                            <p class="!font-nikosh !font-extrabold !text-[11.50px]"><?php echo $_POST['motherNid']; ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="gap-[26px] mt-[175px] flex flex-col">
                                                        <div class="w-full flex flex-row">
                                                            <div class="w-2/4 text-right !text-[11.50px] flex justify-end pr-[27px] !font-mono">
                                                                <p class="font-bold"></p>
                                                                <p class="!font-nikosh !font-extrabold">প্রস্ততকারীর স্বাক্ষর</p>
                                                                <p class="font-bold"></p>
                                                            </div>
                                                            <div class="flex items-center justify-end flex-row w-2/4 !text-[11.50px] gap-[2px] pr-[7px]">
                                                                <p class="font-bold">(</p>
                                                                <p class="!font-nikosh !font-extrabold text-right !text-[11.50px]">নিবন্ধকের স্বাক্ষর ও নামসহ সিল</p>
                                                                <p class="font-bold">)</p>
                                                            </div>
                                                        </div>
                                                        <div class="w-full flex flex-row">
                                                            <p class="!font-nikosh !font-extrabold w-[46%] text-left !text-[11.50px] pl-[9px]">নিবন্ধকের কার্যালয়ের সিলমােহর</p>
                                                            <div class="w-2/4 text-left !text-[11.50px] flex justify-start">
                                                                <p class="font-bold"></p>
                                                                <p class="!font-nikosh !font-extrabold">যাচাইকারীর নাম, স্বাক্ষর ও সিল</p>
                                                                <p class="font-bold"></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<script>
//    window.addEventListener('click', function(){
//       window.print()
//    });
</script>
</body></html>