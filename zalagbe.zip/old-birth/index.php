<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Old Birth (Bangla) - ৳ 10</h1>
    </div>

    <section class="section">
        <div class="container">
            <?php
              if($default_amount >= $get_user['amount']){
                  echo $fund = '<div class="alert alert-danger" role="alert">Insufficient balance in your account. Kindly recharge your account balance to proceed.</div>';
              }
            ?>
            <form action="view-bn" method="POST">
                <h3 style="text-align: center; border: 1px solid darkblue; padding: 18px 5px; font-size: 22px; min-width: 285px; margin: 5px; margin-bottom: 32px; border-radius: 10px; background: darkblue; color: #fff;">
                    সঠিক তথ্য সাবমিট করুন পিডিএফ ডাউনলোড করার জন্য
                </h3>
                <div style="display: flex; width: 300px; justify-content: space-between; align-items: center; border: 1px solid gray; padding: 5px; margin-bottom: 20px; border-radius: 5px;">
                    <p style="margin: 0;">ভাষা সিলেক্ট করুন:</p>
                    <a href="index.php" style="background: darkblue; color: #fff; padding: 2px 10px; border-radius: 7px;">বাংলা</a>
                    <a href="birth-en.php" style="color: #333;">ইংরেজি</a>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="first">নাম</label>
                            <input type="text" name="name" class="form-control" placeholder="নাম" id="name" value="" required="">
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="first">পিতার নাম</label>
                            <input type="text" name="fatherName" class="form-control" placeholder="পিতার নাম" id="fatherName" value="" required="">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="first">মাতার নাম</label>
                            <input type="text" name="motherName" class="form-control" placeholder="মাতার নাম" id="motherName" value="" required="">
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="last">ইউনিয়ন / সিটি কর্পোরেশন</label>
                            <select class="form-control" id="addresstypebn">
                                <option value="cityCorporation">সিটি কর্পোরেশন</option>
                                <option value="union">ইউনিয়ন</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="company">ঠিকানা ১</label>
                            <input type="text" class="form-control" placeholder="ঠিকানা ১" id="address1" name="address1" value=" অঞ্চল - ৪, ঢাকা উত্তর সিটি কর্পোরেশন ">
                        </div>
                    </div>

                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="company">ঠিকানা ২</label>
                            <input type="text" class="form-control" placeholder="ঠিকানা ২ (City Corporation)" id="address2" name="address2" value=" সিটি কর্পোরেশন: ঢাকা উত্তর সিটি কর্পোরেশন ">
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="company">ঠিকানা ৩</label>
                            <input type="text" class="form-control" placeholder="ঠিকানা ৩ (District)" id="address3" name="address3" value=" জেলা: ঢাকা, বাংলাদেশ । ">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="last">নিবন্ধন বহি নম্বর</label>
                            <input type="text" name="registerNo" class="form-control" placeholder="201" id="registerNo" value="">
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="url">সনদ প্রদানের তারিখ</label>
                            <input type="text" class="form-control datepicker hasDatepicker" name="doi" id="doi" placeholder="সনদ প্রদানের তারিখ" value="০৭/১১/২০২৩">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="email">নিবন্ধনের তারিখ</label>
                            <input type="text" class="form-control datepicker hasDatepicker" id="dor" name="dor" placeholder="নিবন্ধনের তারিখ" value="০৭/১১/২০২৩">
                        </div>
                    </div>

                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="url">জন্ম নিবন্ধন নাম্বার</label>
                            <input type="text" class="form-control" id="brNo" name="brNo" min="17" max="17" placeholder="২০০০৯১১২০১০০৩১৬২০" value="" required="">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="url">জন্ম তারিখ</label>
                            <input type="text" class="form-control" id="dob" name="dob" placeholder="" value="০১/০১/১৯৯৫">
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="url">সন্তানের ক্রম</label>
                            <select name="ooc" id="ooc" class="form-control">
                                <option value="">Select</option>
                                <option value="১">১</option>
                                <option value="২">২</option>
                                <option value="৩">৩</option>
                                <option value="৪">৪</option>
                                <option value="৫">৫</option>
                                <option value="৬">৬</option>
                                <option value="৭">৭</option>
                                <option value="৮">৮</option>
                                <option value="৯">৯</option>
                                <option value="১০">১০</option>
                                <option value="১১">১১</option>
                                <option value="১২">১২</option>
                                <option value="১৩">১৩</option>
                                <option value="১৪">১৪</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="url">জন্মস্থান</label>
                            <input type="text" class="form-control" id="pob" name="pob" placeholder="জন্মস্থান" value="">
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="form-group">
                            <label for="url">লিঙ্গ</label>

                            <select id="gendar" name="gendar" class="form-control">
                                <option value="পুরুষ">পুরুষ</option>
                                <option value="নারী">নারী</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 mb-4">
                        <div class="form-group">
                            <label for="email">স্থায়ী ঠিকানা</label>
                            <textarea class="form-control" id="fullAddress" name="fullAddress" placeholder=" স্থায়ী ঠিকানা Enter দিয়ে ২য় লাইনে যাবেন" rows="2"></textarea>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="first">পিতার জাতীয় পরিচয়পত্র নম্বর</label>
                            <input type="text" name="fatherNid" class="form-control" placeholder="" id="fatherNid" value="">
                        </div>
                    </div>
                    <!--  col-md-6 mb-4   -->

                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="first">পিতার জন্ম নিবন্ধন নম্বর</label>
                            <input type="text" name="fatherBrn" class="form-control" placeholder="" id="fatherBrn" value="">
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="first">পিতার জাতীয়তা</label>
                            <input type="text" name="fatherNationality" class="form-control" placeholder="পিতার জাতীয়তা" id="fatherNationality" value=" বাংলাদেশী ">
                        </div>
                    </div>
                    <!--  col-md-6 mb-4   -->
                </div>
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="first">মাতার জাতীয় পরিচয়পত্র নম্বর</label>
                            <input type="text" name="motherNid" class="form-control" placeholder="" id="motherNid" value="">
                        </div>
                    </div>
                    <!--  col-md-6 mb-4   -->

                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="first">মাতার জন্ম নিবন্ধন নম্বর</label>
                            <input type="text" name="motherBrn" class="form-control" placeholder="" id="motherBrn" value="">
                        </div>
                    </div>
                    <div class="col-md-4 mb-4">
                        <div class="form-group">
                            <label for="first">মাতার জাতীয়তা</label>
                            <input type="text" name="motherNationality" class="form-control" placeholder="মাতার জাতীয়তা" id="motherNationality" value=" বাংলাদেশী ">
                        </div>
                    </div>
                    <!--  col-md-6 mb-4   -->
                </div>

                <div style="display: flex; justify-content: center; margin-bottom: 50px;">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    <button style="width: 40%;" class="btn btn-success d-block m-auto mt-5" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </section>
</main>
<script src="./js/jquery.min.js"></script>
<script>
  $('select#addresstypebn').change(function(){
    if($('select#addresstypebn').val() == "cityCorporation"){
      $('#address1').val("অঞ্চল - ৪, ঢাকা উত্তর সিটি কর্পোরেশন");
      $('#address2').val("সিটি কর্পোরেশন: ঢাকা উত্তর সিটি কর্পোরেশন");
      $('#address3').val("জেলা: ঢাকা, বাংলাদেশ");
    }else{
      $('#address1').val("সখিপুর ইউনিয়ন পরিষদ");
      $('#address2').val("উপজেলা: ভেদরগঞ্জ");
      $('#address3').val("জেলা: শরীয়তপুর, বাংলাদেশ");
    }
  });
</script>
<?php
require_once($filepath.'/../inc/footer.php');
?>