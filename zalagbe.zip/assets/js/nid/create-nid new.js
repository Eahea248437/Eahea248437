$('#scrollAfterUpload').click(function(){
    $('.my_file').click();
});

$('.my_file').change(function(e){
    
     $('#nid-s-msg').html('<div class="alert alert-info">Loading ****</div>');
     
    // $('.hidden_wrapper').css('display', 'block');
    $('#hidden_nid_profile').val('');
    $('#profile_url').attr('src', '');

    $('#hidden_nid_sign').val('');
    $('#sign_url').attr('src', '');
    
    $('#nameBangla').val('');
    $('#nameEnglish').val('');
    $('#nid').val('');
    $('#pin').val('');
    $('#nameFather').val('');
    $('#nameMother').val('');
    $('#birthPlace').val('');
    $('#dob').val('');
    $('#bloodGroup').val('');
            
    let form = document.getElementById('myForm');
    const form_data = new FormData(form);
    $.ajax({
        'url' : "https://advanced.rlbdserver.com/sign-copy.php",
        "method" : "POST",
        processData:false,
        contentType:false,
        "data" : form_data,
        success:function(data){
            // console.log(data);
            // $('.hidden_wrapper').css('display', 'none');

            $('#hidden_nid_profile').val(data.photo);
            $('#profile_url').attr('src', data.photo);

            $('#hidden_nid_sign').val(data.sign);
            $('#sign_url').attr('src', data.sign);
            
            $('#nameBangla').val(data.name_bn);
            $('#nameEnglish').val(data.name_en);
            $('#nid').val(data.nid_number);
            $('#pin').val(data.nid_pin);
            $('#nameFather').val(data.father_n);
            $('#nameMother').val(data.mother_n);
            $('#birthPlace').val(data.date_of_place);
            
            let dobParts = data.date_of_birth.split('-');
            let formattedDOB = dobParts[2] + ' ' + getMonthAbbreviation(dobParts[1]) + ' ' + dobParts[0];
            $('#dob').val(formattedDOB);
            
            // $('#dob').val(data.date_of_birth);
            $('#bloodGroup').val(data.blood_group);
            
            $('#fulladdress').html(data.address);
            $('#nid-s-msg').html('<div class="alert alert-success">Sign Copy Update successfully.</div>');
        }
    })
});

// Function to get the abbreviated month name
function getMonthAbbreviation(month) {
    const months = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    return months[parseInt(month, 10) - 1];
}

// profile 
const imageInput = document.getElementById('profile');

imageInput.addEventListener('change', function() {
  const file = this.files[0];   

  if (file) {
    const reader = new FileReader();

    reader.addEventListener('load', function() {
       $('#hidden_nid_profile').attr('value', this.result);
       $('#profile_url').attr('src', this.result);
    });

    reader.readAsDataURL(file);
  }
});

// sign 
const imageInput_sign = document.getElementById('sign');

imageInput_sign.addEventListener('change', function() {
  const file = this.files[0];   

  if (file) {
    const reader = new FileReader();

    reader.addEventListener('load', function() {
       $('#hidden_nid_sign').attr('value', this.result);
        $('#sign_url').attr('src', this.result);
    });

    reader.readAsDataURL(file);
  }
});