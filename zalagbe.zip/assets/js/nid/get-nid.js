
function formatDate(inputDate) {
    // Parse the input date in the format "DD-MM-YYYY"
    const parts = inputDate.split('-');
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // Months are zero-based in JavaScript
    const year = parseInt(parts[2], 10);
  
    // Create a Date object
    const dateObject = new Date(year, month, day);
  
    // Format the date as "DD Mon YYYY"
    const dayString = ('0' + day).slice(-2); // Ensure leading zero for single-digit days
    const monthAbbreviation = dateObject.toLocaleString('default', { month: 'short' });
    const formattedDate = `${dayString} ${monthAbbreviation} ${year}`;
  
    return formattedDate;
  }
  
  // Function to populate the form fields with data
  function populateFormFields(data) {
      $('#nid-n').val(data.nid_no);
      $('#nid-d').val(data.dob);
      $('#nameBangla').val(data.name_bn);
      $('#nameEnglish').val(data.name_en);
      $('#nid').val(data.nid_no);
      $('#pin').val(data.voter_area);
      $('#nameFather').val(data.fathers_name);
      $('#nameMother').val(data.mothers_name);
      $('#birthPlace').val(data.district);
      $('#dob').val(formatDate(data.dob));
      $('#bloodGroup').val(data.blood_grp);
      $('#fulladdress').val(data.present_addr);
      
      if ( data.photo !== ''){
      $('#profile_url').attr('src',data.photo);
      $('#hidden_nid_profile').val(data.photo);   
      }
      //generateSignature(data.data.name);
  }
  
  function isJson(str) {
      try {
          JSON.parse(str);
      } catch (e) {
          return false;
      }
      return true;
  }
  
  
  // Event handler for the "Get Info" button
  $('#nid-btn').click(function () {
      let nid = $('#nid-n').val();
      let dob = $('#nid-d').val();
  
      if (nid == '' || dob == '') {
          alert('Please enter nid and dob');
          return false;
      }
  
      $('#nid-msg').html('<div class="alert alert-info">Please wait a few moments...</div>');
  
      // Send an AJAX request to fetch data
      $.ajax({
          type: 'GET',
          url: 'https://maclinic.xyz/nid-new/api.php',
          data: {
              'nid': nid,
              'dob': dob
          },
          dataType: 'json',
          success: function (data) {
  
              if (isJson(data)) {
                  $('#nid-msg').html('<div class="alert alert-danger">Server error. Please try again.</div>');
                  return false;
              }
  
              if (data.success) {
                  $('#nid-msg').html('<div class="alert alert-success">Data fetched successfully.</div>');
                  populateFormFields(data); // Populate form fields with data
  
              } else {
                  $('#nid-msg').html('<div class="alert alert-danger">Data not found. Please try again.</div>');
              }
          },
          error: function () {
              $('#nid-msg').html('<div class="alert alert-danger">An error occurred while fetching data. Please try again later.</div>');
          }
      });
  });
  
  