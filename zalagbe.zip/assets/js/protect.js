if (window.location.hostname !== 'zalagbe.store') {
    // Code execution is restricted on unauthorized domains
    throw new Error('Unauthorized access.');
}

// devtools detect
window.addEventListener('devtoolschange', event => {
if (event.detail.isOpen == true) {
    window.location.href = "https://zalagbe.store/access/logout";
}
if (event.detail.orientation == true) {
    window.location.href = "https://zalagbe.store/access/logout";
}
});

document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

document.onkeydown = (e) => {
    if (e.key == 123) {
        e.preventDefault();
    }
    if (e.ctrlKey && e.shiftKey && e.key == 'I') {
        e.preventDefault();
    }
    if (e.ctrlKey && e.shiftKey && e.key == 'C') {
        e.preventDefault();
    }
    if (e.ctrlKey && e.shiftKey && e.key == 'J') {
        e.preventDefault();
    }
    if (e.ctrlKey && e.key == 'U') {
        e.preventDefault();
    }
};