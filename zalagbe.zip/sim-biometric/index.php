<?php
$page = 'sim-biometric';
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
    	header('Location: ../');
    }else{
        if (isset($_POST) === TRUE && !empty($_POST)) {
            function validation($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            
            // Function to validate phone number (you can replace this with your own validation logic)
            function isValidPhoneNumber($phoneNumber) {
                // Example validation logic (replace with your own)
                return preg_match('/^\d{11}$/', $phoneNumber);
            }
        
            $submit = $admin->add_biometric($_POST);
          
        }else{
            header("Location: ../");
            exit();
        }
    }
}
?>
<style>
.info-container {
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 20px;
}

.info-item {
    font-size: 22px;
    margin-bottom: 10px;
}
.error-message {
    color: red;
    font-weight: bold;
    margin-top: 10px;
}
</style>
<main id="main" class="main">
  <div class="pagetitle">
    <h1>SIM Biometric Info - ৳ 80</h1>
  </div>

  <section class="section">
    <div class="container">
    <?php
      if($charge >= $get_user['amount']){
          echo $fund = '<div class="alert alert-danger" role="alert">Insufficient balance in your account. Kindly recharge your account balance to proceed.</div>';
      }
      ?>
    <h3 style="text-align: center; border: 1px solid darkblue; padding: 18px 5px; font-size: 22px; min-width: 285px; margin: 5px; margin-bottom: 32px; border-radius: 10px; background: darkblue; color: #fff;"><p>নগদ একাউন্টের বায়োমেট্রিক ইনফো ১০০% আসবে।</p><p> যেকোনো অপারেটর, তবে নগদ একাউন্টের নাম্বার ছাড়া কিছু কিছৃ অপারেটর নাম্বারের ইনফো আসতে অথবা নাও আসতে পারে।</p></h3>
      <form id="search-form" action="" method="POST">
        <label class="form-label">Phone number:</label>
        <input class="form-control" type="text" name="phone" id="phone" placeholder="01xxxxxxxxx" required=""><br>
        <button type="submit" style="width: 40%;" class="btn btn-success d-block m-auto mt-5">Search</button>
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
      </form>
      <div class="row">
            <div class="col-sm-12">
                <div class="pagetitle mt-5">
                    <h1>User Application</h1>
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-responsive">
                  <table class="table datatable table-striped table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Type</th>
                            <th scope="col">ID NO</th>
                            <th scope="col">Name</th>
                            <th scope="col">Status</th>
                            <th scope="col">Date</th>
                            <?php
                            if ($user_role == 'admin') {
                                echo '<th scope="col">Action</th>';
                            }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if ($user_role == 'admin') {
                                $get_data = $admin->all_biometric(1);
                            }else{
                                $get_data = $admin->all_biometric(base64_decode($user_id));
                            }
                            if ($get_data) {
                                $i = 0;
                                while ($row = $get_data->fetch_assoc()) {
                                $i++;
                            ?>
                        <tr>
                            <td scope="row"><?php echo $i; ?></td>
                            <td><?php echo $row['phone']; ?></td>
                            <td><?php echo $row['operator']; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo $row['nid']; ?></td>
                            <td><?php echo $row['dob']; ?></td>
                            <td>
                                <?php if($row['status'] == 'Pending'){?>
                                    <span class="btn btn-primary btn-sm"><?php echo $row['status']; ?></span>
                                <?php } ?>
                                <?php if($row['status'] == 'Success'){?>
                                    <span class="btn btn-success btn-sm"><?php echo $row['status']; ?></span>
                                <?php } ?>
                            </td>
                            <td><?php echo (new DateTime("@".strtotime($row['created'])))->setTimeZone(new DateTimeZone('Asia/Dhaka'))->format('d-m-Y h:i A'); ?></td>
                            <?php
                            if ($user_role == 'admin') { ?>
                                <td><a href="update?id=<?php echo base64_encode($row['id']); ?>&user=<?php echo base64_encode($row['user_id']); ?>"><span class="btn btn-primary btn-sm">Edit</span></a> | <a href="?delete=<?php echo base64_encode($row['id']); ?>"><span class="btn btn-info btn-sm">Delete</span></a></th>
                            <?php }
                            ?>
                        </tr>
                        <?php } }?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
  </section>
</main>
<?php
require_once($filepath.'/../inc/footer.php');
?>