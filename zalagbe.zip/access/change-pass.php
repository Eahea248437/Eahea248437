<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $submit = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Access not allow!</div>';
    }else{
        $submit = $admin->user_password($_POST);
    }
}
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Change Password</h1>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="container">
        <?php if(isset($submit)){ echo $submit; } ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                <div class="row mb-3">
                    <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Current Password</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="current_pass" type="password" class="form-control">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">New Password</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="new_pass" type="password" class="form-control">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Re-enter New Password</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="renew_pass" type="password" class="form-control">
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Change Password</button>
                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                </div>
            </form>
        </div>
    </section>
</main>
<?php
require_once($filepath.'/../inc/footer.php');
?>