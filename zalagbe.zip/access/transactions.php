<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Transaction History</h1>
    </div>

    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-responsive">
                                          <table class="table datatable table-striped table-hover">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Username</th>
                                                    <th scope="col">Trx ID</th>
                                                    <th scope="col">Deposit</th>
                                                    <th scope="col">Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if ($user_role == 'admin') {
                                                        $get_data = $admin->all_transaction();
                                                    }else{
                                                        $get_data = $admin->user_transaction(base64_decode($user_id));
                                                    }
                                                    if ($get_data) {
                                                        $i = 0;
                                                        while ($row = $get_data->fetch_assoc()) {
                                                        $i++;
                                                    ?>
                                                <tr>
                                                    <td scope="row"><?php echo $i; ?></td>
                                                    <td><?php echo $row['username']; ?></td>
                                                    <td><?php echo $row['trx_id']; ?></td>
                                                    <td><?php echo $row['amount']; ?></td>
                                                    <td><?php echo (new DateTime("@".strtotime($row['created'])))->setTimeZone(new DateTimeZone('Asia/Dhaka'))->format('d-m-Y h:i A'); ?></td>
                                                </tr>
                                                <?php } } ?>
                                            </tbody>
                                          </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php require_once($filepath.'/../inc/footer.php'); ?>