<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');

if ($user_role != 'admin') {
    header('Location: ../');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $submit = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Access not allow!</div>';
    }else{
        $submit = $admin->add_user($_POST);
    }
}
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Create User</h1>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="container">
        <?php if(isset($submit)){ echo $submit; } ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                <div class="row mb-3">
                    <label class="col-md-4 col-lg-3 col-form-label">Username</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="signup_username" type="text" class="form-control" required placeholder="Enter your username">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">Password</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="signup_password" type="password" class="form-control" required placeholder="Enter your password">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">Confirm Password</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="confirm_password" type="password" class="form-control" required placeholder="Re enter your password">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">Mobile</label>
                    <div class="col-md-8 col-lg-9">
                        <input name="signup_mobile" type="text" class="form-control" required placeholder="Enter your mobile">
                    </div>
                </div>

                <!--<div class="row mb-3">-->
                <!--    <label class="col-md-4 col-lg-3 col-form-label">Status</label>-->
                <!--    <div class="col-md-8 col-lg-9">-->
                <!--        <div class="form-check">-->
                <!--            <input class="form-check-input" type="radio" name="status" id="status" value="1" checked="">-->
                <!--            <label class="form-check-label" for="status">Active</label>-->
                <!--        </div>-->
                <!--        <div class="form-check">-->
                <!--            <input class="form-check-input" type="radio" name="status" id="status" value="2">-->
                <!--            <label class="form-check-label" for="status">Inactive</label>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="text-center">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                </div>
            </form>
        </div>
    </section>
</main>
<?php
require_once($filepath.'/../inc/footer.php');
?>