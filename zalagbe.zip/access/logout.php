<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/loader.php');

Session::logout();
$db->redirect(SITEURL.'login');