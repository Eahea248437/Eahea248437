<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');

if ($user_role != 'admin') {
    header('Location: ../');
}

if(isset($_GET['delete'])) {
    $id = $helper->validation($_GET['delete']);
    $delete = $admin->user_remove(base64_decode($id));
}
?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>All Users</h1>
    </div>

    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-responsive">
                                          <table class="table datatable table-striped table-hover">
                                            <thead>
                                              <tr>
                                                <th scope="col">ID</th>
                                                <th scope="col">Username</th>
                                                <th scope="col">Mobile</th>
                                                <th scope="col">Balance</th>
                                                <th scope="col">Date</th>
                                                <th scope="col">Action</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              <?php
                                                    $get_data = $admin->all_user();
                                                    if ($get_data) {
                                                        $i = 0;
                                                        while ($row = $get_data->fetch_assoc()) {
                                                        $i++;
                                                    ?>
                                                <tr>
                                                    <td scope="row"><?php echo $i; ?></td>
                                                    <td><?php echo $row['username']; ?></td>
                                                    <td><?php echo $row['mobile']; ?></td>
                                                    <td><?php echo $row['amount']; ?></td>
                                                    <td><?php echo (new DateTime("@".strtotime($row['created'])))->setTimeZone(new DateTimeZone('Asia/Dhaka'))->format('d-m-Y h:i A'); ?></td>
                                                    <td>
                                                        <a href="user-edit?id=<?php echo base64_encode($row['id']); ?>" class="btn btn-primary btn-sm"><i class="bi bi-pen"></i> Edit</a>
                                                        | <a href="?delete=<?php echo base64_encode($row['id']);?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to <?php echo $row['username']; ?> delete this user?');"><i class="bi bi-trash"></i></a> 
                                                    </td>
                                                </tr>
                                                <?php } } ?>
                                            </tbody>
                                          </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php require_once($filepath.'/../inc/footer.php'); ?>