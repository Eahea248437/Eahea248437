<?php
$page = 'index';
require('inc/header.php'); ?>
  <?php include('inc/sidebar.php'); ?>

  <main id="main" class="main">
    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12" style="height: 100vh;">
          <h1 class="text-center">Welcome to Seba Center</h1>
          <h3 class="text-center pt-3">Your IP: <?php echo $user_ip; ?></h3>
            <!--<div class="modal fade" id="popupModal" tabindex="-1">-->
            <!--    <div class="modal-dialog modal-dialog-centered">-->
            <!--        <div class="modal-content">-->
            <!--            <div class="modal-header">-->
            <!--            <h5 class="modal-title">Site Update Info</h5>-->
            <!--                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>-->
            <!--            </div>-->
            <!--            <div class="modal-body">-->
            <!--                <p>এনাআইডি সাইনকপি পুনঃচালু করা হয়েছে</p>-->
            <!--                <p>তারিখ: 31-12-2023</p>-->
            <!--            </div>-->
            <!--            <div class="modal-footer">-->
            <!--                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
        </div>         
      </div>
    </section>

  </main><!-- End #main -->
  <?php include('inc/footer.php'); ?>