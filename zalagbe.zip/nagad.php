<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process the form data
    $userId = $_POST["userId"];

    $url = "https://app.mynagad.com/api/wallet/generateAuthCode/deviceChange";
    $headers = array(
        "X-KM-UserId: " . $userId,
        "X-KM-User-AspId: 100012345612345",
        "X-KM-User-Agent: ANDROID/1152",
        "X-KM-DEVICE-FGP: 19DC58E052A91F5B2EB59399AABB2B898CA68CFE780878C0DB69EAAB0553C3C6",
        "X-KM-Accept-language: bn",
        "X-KM-AUTH-TOKEN: eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIwMTYxNDM1ODk5NiIsInBob25lIjoiMDE2MTQzNTg5OTYiLCJhc3BJZCI6IjEwMDAxMjM0NTYxMjM0NSIsImNyZWF0ZWQiOjE3MDI3ODE3MzkwNjgsInJhbmRvbVZhbHVlIjoiMTcwMjc4MTczOTA2OCIsInVzZXJUeXBlIjoiQ1UiLCJ0eXBlIjoiQUNDRVNTX1RPS0VOIiwiZXhwIjoxNzAyNzgyMDM5LCJ1c2VySWQiOiI3NjQ4NTA4OCIsIm1wYUlkIjoiMTcwMTk1MjMyNTU2MDQ3MjU1NTI3MjYzMzc0NDMwNTEiLCJlbWFpbCI6bnVsbH0.SRPX__T23OP15UAp08eisRko1vfGwXcQNS0L-Sx7S5nLb-rXgPT8OKwEC1jIGdIgzqZzUsGZ8Tp8OAbjOQPdPg",
        "X-KM-AppCode: 01",
        "Content-Type: application/json; charset=UTF-8",
        "Content-Length: 21",
        "Host: app.mynagad.com:20002",
        "Connection: Keep-Alive",
        "Accept-Encoding: gzip",
        "User-Agent: okhttp/3.14.9"
    );
    
    $data = array(
        "userId" => $userId
    );
    
    $ch = curl_init($url);
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($ch);
    
    if ($response === false) {
        // cURL error occurred
        echo 'Curl error: ' . curl_error($ch);
    } else {
        // Check HTTP status code
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($httpCode >= 200 && $httpCode < 300) {
            // Successful request
            echo $response;
        } else {
            // Request failed
            echo 'HTTP error code: ' . $httpCode;
        }
    }
    
    curl_close($ch);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Example</title>
</head>
<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="userId">User ID:</label>
        <input type="text" id="userId" name="userId" required value="76485088">
        <br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>