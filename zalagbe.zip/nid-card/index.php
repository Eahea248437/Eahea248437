<?php
$page = 'nid-card';
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>NID Card Make - ৳ 10</h1>
    </div>
    <section class="section">
        <div class="container">
            <?php
            if($default_amount >= $get_user['amount']){
                echo $fund = '<div class="alert alert-danger" role="alert">Insufficient balance in your account. Kindly recharge your account balance to proceed.</div>';
            }
            ?>
            <div style="padding: 2rem;">
                <div class="row justify-content-center">
                    <div class="col-xl-8">
                        <form action="" enctype="multipart/form-data" id="myForm">
                            <p id="nid-s-msg" class="text-center"></p>
                            <div class="file-upload-contain">
                                <div class="file-input theme-explorer-fas file-input-ajax-new">
                                    <div id="scrollAfterUpload" class="file-preview">
                                        <div class="file-drop-zone clickable">
                                            <div class="file-drop-zone-title">
                                                <div class="upload-area">
                                                    <i class="far fa-images"></i>
                                                    <p>ব্রাউজ বা টেনে আনুন সাইন কপি পিডিএফ ফাইল</p>
                                                    <div><button type="button" class="btn btn-success">ব্রাউজ ফাইল</button></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($default_amount < $get_user['amount']){?>
                                        <input style="opacity: 0" type="file" name="pdf" class="my_file">
                                    <?php } ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <h1 class="text-center text-danger">OR</h1>

                <div class="row justify-content-center" style="padding:10px;border:2px solid blue;margin-bottom:10px;border-radius:5px;max-width:500px;margin:0 auto">
                    <p id="nid-msg" class="text-center"></p>

                    <h3 class="text-center"> Enter NID Info </h3>
                    <div class="col-xl-8">
                        <label class="form-label">NID No</label>
                        <input id="nid-n" type="text" class="form-control"><br>
                        <label class="form-label">Date of Birth</label>
                        <input id="nid-d" type="date" class="form-control" max="2006-01-01"><br>

                        <center><button <?php if($default_amount < $get_user['amount']){ echo 'id="nid-btn"'; } ?> class="btn btn-success">Get Info</button></center>

                    </div>
                </div><br>

                <form action="view" method="POST">

                    <div>
                        <h3 style="text-align: center;">NID Info</h3>
                        <div class="row">
                            <div style="display: flex;align-items: center;justify-content: center;" class="col-6">
                                <img id="profile_url" style="width:5rem;">
                                <input type="hidden" name="nid_profile" id="hidden_nid_profile">
                            </div>
                            <div style="display: flex;align-items: center;justify-content: center;" class="col-6">
                                <img id="sign_url" style="width: 10rem;">
                                <input type="hidden" name="nid_sign" id="hidden_nid_sign">
                            </div>

                            <div style="margin-bottom: 10px;" class="col-md-6 col-sm-4 mb-3">
                                <label class="form-label" for="first" style="color: black;">NID Photo</label>
                                <input id="profile" style="width: 100%;" type="file" name="nidphoto" class="form-control">
                            </div>
                            <div style="margin-bottom: 10px;" class="col-md-6 col-sm-4 mb-3">
                                <label class="form-label" for="first" style="color: black;">NID Sign</label>
                                <input id="sign" style="width: 100%;" type="file" class="form-control">
                            </div>
                            <!--  col-md-6   -->
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="first">Name (Bangla)</label>
                                    <input type="text" name="nameBangla" class="form-control" id="nameBangla">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="last">Name (English)</label>
                                    <input type="text" name="nameEnglish" class="form-control" id="nameEnglish">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="company">NID Number</label>
                                    <input type="text" class="form-control" id="nid" name="nid">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="phone">PIN Number</label>
                                    <input type="text" class="form-control" name="pin" id="pin">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                        </div>
                        <!--  row   -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="email">Father Name</label>
                                    <input type="text" class="form-control" id="nameFather" name="nameFather">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="url">Mother Name</label>
                                    <input type="text" class="form-control" name="nameMother" id="nameMother">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                        </div>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="email">Birth Place</label>
                                    <input type="text" class="form-control" id="birthPlace" name="birthPlace">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="url">Date Of Birth</label>
                                    <input type="text" class="form-control" id="dob" name="dob">
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="url">Issue date</label>
                                    <input type="text" class="form-control" name="issued" value="06/11/2023">
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="form-group">
                                    <label class="form-label" for="url">Blood Group</label>
                                    <input type="text" class="form-control" id="bloodGroup" name="bloodGroup">
                                </div>
                            </div>
                            <!--  col-md-6   -->
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label" for="email">Full Address</label>
                                    <textarea class="form-control" id="fulladdress" name="fulladdress" value="" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <!--  row   -->
                        <button type="submit" name="submit" style="width: 40%;" class="btn btn-success d-block m-auto mt-5">Submit</button>
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                    </div>
                </form>
            </div>
        </div>
    </section>
</main>
<?php
if($default_amount > $get_user['amount']){
    
}else{ ?>
    <script src="<?php echo SITEURL ?>assets/js/nid/create-nid.js"></script>
    <script src="<?php echo SITEURL ?>assets/js/nid/get-nid.js"></script>
<?php } ?>
<?php
require_once($filepath.'/../inc/footer.php');
?>