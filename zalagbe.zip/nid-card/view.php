<?php
$filepath = realpath(__DIR__);
require_once $filepath.'/../inc/loader.php';
Session::checkSession();
$csrf_token =  Session::get('csrf_token');
$user_id =  Session::get('user_id');
$default_amount = 10;
$get_user = $admin->user_by_id(base64_decode($user_id))->fetch_assoc();
if($default_amount > $get_user['amount']){
    header('Location: ../');
}else{
   if($_SERVER['REQUEST_METHOD'] == 'POST'){
      if (empty($_POST['fulladdress'])) {
         header('Location: ../');
      }else{
         if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
             header('Location: ../');
          }else{
             $charge = 10;
             $admin->file_downlaod($charge, base64_decode($user_id));  
          }   
      }
   }
}

function bangla_number($int) {
   $engNumber = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 0);
   $bangNumber = array('১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '০');

   $converted = str_replace( $engNumber, $bangNumber, $int );
   return $converted;
}
?>


<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
      <title>NID Print</title>
      <link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/bootstrap.min.css">
      <link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/print.min.css">
      <link href="fonts/kalpurush.css" rel="stylesheet">
      <style type="text/css" media="print">
         @media print {
            @page {
               margin-top: 0;
               margin-bottom: 0;
               size: A4 !important;
               color-adjust: exact !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
               background-color: #fff !important;
            }
            body {
               padding-top: 0px;
               padding-bottom: 72px;
            }
            .print {
               display: none !important;
            }
         }
         body {
            position: relative;
         }
      </style>
   </head>
   <body>
      <!-- ======= Header ======= -->
      <header id="header" class="print header d-flex align-items-center" style="background: #ddd; padding: 5px">
         <nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
            <ul class="d-flex align-items-center">
               <li class="nav-item dropdown" style="list-style: none;">
                  <a href="<?php echo SITEURL; ?>" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;">Home</a>
                  <button type="button" onclick="window.print();" class="btn btn-success mb-2 mt-2" style="margin-left: 8px;">Print</button>
               </li>
            </ul>
         </nav>
         <!-- End Icons Navigation -->
      </header>
      <!-- End Header -->
      
      <div class="dis containerlol d-flex align-items-center justify-content center">
         <div class="col-12">
            <div class="mainbox" id="mainbox">
               <div class="imgtem w100 position-relative" id="pdf">
                  <span class="bname"><?php echo $_POST["nameBangla"]?></span>
                  <span class="ename" style="text-transform: uppercase;font-size: 14px;"><?php echo $_POST["nameEnglish"]?></span>
                  <span class="fname"><?php echo $_POST["nameFather"]?></span>
                  <span class="mname"><?php echo $_POST["nameMother"]?></span>
                  <span id="date" class="issue"></span>
                  <span class="dob"><?php echo $_POST["dob"]?></span>
                  <span class="cardnumber"><?php echo $_POST["nid"]?></span>
                  <span class="signeture">
                  <img src="<?php echo $_POST['nid_sign']; ?>">
                  </span>
                  <span class="profilepic">
                  <img src="<?php echo $_POST['nid_profile']; ?>">
                  </span>
                  <span class="erase"> </span>
                  <div class="address3">
                     <p class="h1">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</p>
                     <p class="h2">Government of the People's Republic of Bangladesh</p>
                     <p class="h3">National ID<?php // if(Session::get('userId') == 'SlC7NV0N') { echo 'Demo'; } ?> Card</p>
                     <p class="h4">/ জাতীয় পরিচয় পত্র</p>
                     <p class="bn">নাম: </p>
                     <p class="en">Name: </p>
                     <p class="fn">পিতা: </p>
                     <p class="mn">মাতা: </p>
                     <p class="db">Date of Birth: </p>
                     <p class="idno">ID NO: </p>
                  </div>
                  <p class="address2">
                     এই কার্ডটি গণপ্রজাতন্ত্রী বাংলাদেশ সরকারের সম্পত্তি। কার্ডটি ব্যবহারকারী ব্যতীত অন্য <br>
                     কোথাও পাওয়া গেলে নিকটস্থ পোস্ট অফিসে জমা দেবার জন্য অনুরোধ করা হলো। <br>
                  </p>
                  <p class="address">ঠিকানা:</p>
                  <p class="addresss"><?php echo $_POST["fulladdress"]?></p>
                  <p></p>
                  <span class="rokto"> রক্তের গ্রুপ </span>
                  <span class="rokto2"> / Blood Group: <span style="color: red;font-weight: 600;"><?php echo $_POST["bloodGroup"]?></span></span>
                  <span class="disth">জন্মস্থান: </span>
                  <span class="pd">প্রদানকারী কর্তৃপক্ষের স্বাক্ষর </span>
                  <span class="pi">প্রদানের তারিখ: <?php echo bangla_number($_POST["issued"]); ?></span>
                  <span class="dist"><?php echo $_POST["birthPlace"]?></span>
                  <span class="barcode">
                     <div id="barcode"></div>
                  </span>
                  <img class="template" src="<?php echo SITEURL ?>assets/img/nid/bg.jpg" alt="">
               </div>
            </div>
         </div>
         <input type="text" id="textToEncode" style="width: 100%; height: 200px; visibility: hidden;">
      </div>
      <script>
         document.addEventListener("keydown", e => {
           // USE THIS TO DISABLE CONTROL AND ALL FUNCTION KEYS
           // if (e.ctrlKey || (e.keyCode>=112 && e.keyCode<=123)) {
           // THIS WILL ONLY DISABLE CONTROL AND F12
           if (e.ctrlKey || e.keyCode==123) {
             e.stopPropagation();
             e.preventDefault();
           }
         });
      </script>
      <script>
         document.addEventListener("contextmenu", e => e.preventDefault(), false);
      </script>
      <script>
         window.onload = function () {
             var hub3_code = '<pin><?php echo $_POST['pin']; ?></pin><name><?php echo $_POST['nameEnglish']; ?></name><DOB><?php echo $_POST['dob']; ?></DOB><FP></FP><F>Right Index</F><TYPE>A</TYPE><V>2.0</V><ds>302c0214103fc01240542ed736c0b48858c1c03d80006215021416e73728de9618fedcd368c88d8f3a2e72096d</ds>';
         
             var textToEncode = document.getElementById("textToEncode");
             textToEncode.value = hub3_code;
         
             PDF417.init(hub3_code);
         
             var barcode = PDF417.getBarcodeArray();
         
             // block sizes (width and height) in pixels
             var bw = 2;
             var bh = 2;
         
             // create canvas element based on number of columns and rows in barcode
             var canvas = document.createElement("canvas");
             canvas.width = bw * barcode["num_cols"];
             canvas.height = bh * barcode["num_rows"];
             document.getElementById("barcode").appendChild(canvas);
         
             var ctx = canvas.getContext("2d");
         
             // graph barcode elements
             var y = 0;
             // for each row
             for (var r = 0; r < barcode["num_rows"]; ++r) {
                 var x = 0;
                 // for each column
                 for (var c = 0; c < barcode["num_cols"]; ++c) {
                     if (barcode["bcode"][r][c] == 1) {
                         ctx.fillRect(x, y, bw, bh);
                     }
                     x += bw;
                 }
                 y += bh;
             }
         };
      </script>
      
      <script src="<?php echo SITEURL; ?>assets/js/nid/bcmath.min.js"></script>
      <script src="<?php echo SITEURL; ?>assets/js/nid/pdf417.min.js"></script>

      <?php
      $filepath = realpath(__DIR__);
      require_once($filepath.'/../inc/protect.php');
      ?>
   </body>
</html>