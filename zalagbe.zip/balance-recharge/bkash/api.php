<?php
session_start();
$config = array(
    'mode' => 'live',
    'app_key' => '4RSdNWbnL6jRy6bPeHoR3It8tc',
    'app_secret' => 'HzDG5Tf2rzw6EICx3ttOjYsfmLoI0VMO3pf4c9b4llepS1vXmiCs',
    'username' => '01610636505',
    'password' => '[?!Dp5b-Rr3',
    'callback' => 'https://sebacenter.xyz/recharge/success',
    );
function get_base_url(){
        global $config;
        if($config['mode'] == 'sandbox'){
            $base = "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/";
        }
        else {
            $base = "https://tokenized.pay.bka.sh/v1.2.0-beta/tokenized/";
        }
        return $base;
    }

function create_payment($amount){
        global $config;
        $token = getToken();
        $requestbody = array(
            'mode' => '0011',
            'payerReference' => ' ',
            'callbackURL' => $config['callback'],
            'amount' => $amount,
            'currency' => 'BDT',
            'intent' => 'sale',
            'merchantInvoiceNumber' => "Inv".date('YmdH').rand(1000, 10000)
        );
        $requestbodyJson = json_encode($requestbody);

        $header = array(
            'Content-Type:application/json',
            'Authorization:' .$token,
            'X-APP-Key:'.$config['app_key']
        );

        $url = curl_init(get_base_url().'checkout/create');
        curl_setopt($url, CURLOPT_HTTPHEADER, $header);
        curl_setopt($url, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($url, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($url, CURLOPT_POSTFIELDS, $requestbodyJson);
        curl_setopt($url, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($url, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $resultdata = curl_exec($url);
        curl_close($url);
        return json_decode($resultdata)->bkashURL;
    }

    function getToken(){
        global $config;
        $_SESSION['token'] = '';
        $request_data = array('app_key'=> $config['app_key'], 'app_secret'=> $config['app_secret']);
        $request_data_json=json_encode($request_data);

        $header = array(
                'Content-Type:application/json',
                'username:'.$config['username'],
                'password:'.$config['password']
                );
       
        $url = curl_init(get_base_url().'checkout/token/grant');
        curl_setopt($url,CURLOPT_HTTPHEADER, $header);
        curl_setopt($url,CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($url,CURLOPT_RETURNTRANSFER, true);
        curl_setopt($url,CURLOPT_POSTFIELDS, $request_data_json);
        curl_setopt($url,CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($url, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

        $resultdata = curl_exec($url);
        curl_close($url);

        $token = json_decode($resultdata)->id_token;
        $_SESSION['token'] = $token;
        return $token;
    }
    
   function callback(){
        $data = array(
            'success' => false,
            'msg' => 'Payment Failed',
            );
        $allRequest = isset($_GET) ? $_GET: array();
        if(isset($allRequest['status']) && $allRequest['status'] == 'failure'){
            $data['msg'] = 'Payment Failed';
        }else if(isset($allRequest['status']) && $allRequest['status'] == 'cancel'){
          $data['msg'] = 'Payment Cancelled';
        }else{
            
            $resultdata = execute($allRequest['paymentID']);
            $result_data_array = json_decode($resultdata,true);
            if(array_key_exists("statusCode",$result_data_array) && $result_data_array['statusCode'] != '0000'){
                $data['msg'] = $result_data_array['statusMessage'];
                return $data;
            }else if(array_key_exists("statusMessage",$result_data_array)){
                sleep(1);
                $resultdata = query($allRequest['paymentID']);
                $resultdata = json_decode($resultdata,true);
                if($resultdata['transactionStatus'] == 'Initiated'){
                   $data['msg'] = 'initiated';
                   return $data;
                }
            }
            
             $data['success'] = true;
             $data['msg'] = 'Payment Successfull';
        }
        return $data;
    }

    function execute($paymentID) {
        global $config;
        $auth = $_SESSION['token'];
        
        $requestbody = array(
            'paymentID' => $paymentID
        );
        $requestbodyJson = json_encode($requestbody);

        $header = array(
            'Content-Type:application/json',
            'Authorization:' . $auth,
            'X-APP-Key:'.$config['app_key']
        );

        $url = curl_init(get_base_url().'checkout/execute');
        curl_setopt($url, CURLOPT_HTTPHEADER, $header);
        curl_setopt($url, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($url, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($url, CURLOPT_POSTFIELDS, $requestbodyJson);
        curl_setopt($url, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($url, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $resultdata = curl_exec($url);
        curl_close($url);
        
        return $resultdata;
    }

    function query($paymentID){
        global $config;
        $auth = $_SESSION['token'];
        
        $requestbody = array(
            'paymentID' => $paymentID
        );
        $requestbodyJson = json_encode($requestbody);

        $header = array(
            'Content-Type:application/json',
            'Authorization:' . $auth,
            'X-APP-Key:'.$config['app_key']
        );

        $url = curl_init(get_base_url().'checkout/payment/status');
        curl_setopt($url, CURLOPT_HTTPHEADER, $header);
        curl_setopt($url, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($url, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($url, CURLOPT_POSTFIELDS, $requestbodyJson);
        curl_setopt($url, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($url, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $resultdata = curl_exec($url);
        curl_close($url);
        
        return $resultdata;
    }
?>