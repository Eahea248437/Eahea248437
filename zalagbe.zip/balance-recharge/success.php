<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
require_once('bkash/api.php');
$data = callback();

if ($data['success'] == true){
    $allRequest = isset($_GET) ? $_GET: array();
    $info = query($allRequest['paymentID']);
    $info = json_decode($info, true);
    
    /* GET DATA */
    $amount = $info['amount'];
    $trxID = $info['trxID'];
    $current = $get_user['amount'];
    $userID = base64_decode($user_id);
    // $transactionStatus = $info['transactionStatus'];
    // $statusCode = $info['statusCode'];
    // $statusMessage = $info['statusMessage'];

    if ($amount >= 500) {
        $bonus = 0.30 * $amount;
        $deposited = $amount + $bonus;
        $balance = $deposited + $current;
        $admin->add_transaction($userID, $trxID, $amount);
        $admin->update_transaction($userID, $balance);
    } else {
        $balance = $current + $amount;
        $admin->add_transaction($userID, $trxID, $amount);
        $admin->update_transaction($userID, $balance);
    }
?>
<style>
    .invoice {
        margin-top: 20px;
        border-top: 1px solid #ccc;
        padding-top: 20px;
    }

    .invoice h5 {
        color: #4CAF50;
    }

    .invoice p {
        margin-bottom: 5px;
    }
</style>
<main id="main" class="main">
    <section class="section">
        <div class="container mt-5">
            <div class="card">
                <div class="card-body text-center">
                    <h2 class="text-success">Recharge Successful!</h2>
                    <p class="text-muted">Your balance has been successfully processed.</p>
                    <div class="invoice mt-4">
                        <h5>Invoice Details</h5>
                        <p><strong>Transaction ID:</strong> <?php echo $trxID; ?></p>
                        <p><strong>Amount:</strong> ৳<?php echo $amount; ?></p>
                        <p><strong>Balance:</strong> ৳<?php echo $balance; ?></p>
                    </div>
                    <a href="../" class="btn btn-primary mt-3">Continue</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php } else { ?>
<main id="main" class="main">
    <section class="section">
        <div class="container mt-5">
            <div class="card">
                <div class="card-body text-center">
                    <h2 class="text-danger">Recharge Unsuccessful!</h2>
                    <p class="text-muted">We are sorry, but your bKash recharge has failed.</p>
                    <a href="../" class="btn btn-primary mt-3">Go to Dashboard</a>
                </div>
            </div>
        </div>
    </section>
</main>
<?php }
require_once($filepath.'/../inc/footer.php');
?>