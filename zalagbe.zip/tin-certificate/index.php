<?php
$page = 'tin-certificate';
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    function validation($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    $tinNumber = validation($_POST['tinNumber']);
}
?>
<main id="main" class="main">

  <div class="pagetitle">
    <h1>টিন সার্টিফিকেট - ৳ 30</h1>
  </div>

  <section class="section">
    <div class="container">
    <?php
      if($default_amount >= $get_user['amount']){
          echo '<div class="alert alert-danger" role="alert">আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই। দয়া করে আপনার অ্যাকাউন্টের ব্যালেন্স পুনরায় চার্জ করুন।</div>';
      }
      ?>
      <h3 style="text-align: center; border: 1px solid darkblue; padding: 18px 5px; font-size: 22px; min-width: 285px; margin: 5px; margin-bottom: 32px; border-radius: 10px; background: darkblue; color: #fff;">সঠিক তথ্য সাবমিট করুন পিডিএফ ডাউনলোড করার জন্য</h3>
      <form id="search-form" action="view" method="POST">
        <label class="form-label">টিন নাম্বার দিন:</label>
        <input class="form-control" type="text" name="tinNumber" id="tinNumber" placeholder="Enter TIN Number" required=""><br>
        <button type="submit" style="width: 40%;" class="btn btn-success d-block m-auto mt-5">সার্চ করুন</button>
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
      </form>
    </div>
  </section>
</main>
<?php
require_once($filepath.'/../inc/footer.php');
?>