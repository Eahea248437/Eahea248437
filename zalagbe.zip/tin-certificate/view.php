<?php
$filepath = realpath(__DIR__);
require_once $filepath.'/../inc/loader.php';
Session::checkSession();
$csrf_token =  Session::get('csrf_token');
$user_id =  Session::get('user_id');
$default_amount = 10;
$get_user = $admin->user_by_id(base64_decode($user_id))->fetch_assoc();
if($default_amount > $get_user['amount']){
    header('Location: ../');
}else{
	if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
	    header('Location: ../');
	}
}
?>
<html lang="en">
<head>
    <title>TIN Certificate</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/bootstrap.min.css">
    <style>
        *, html, body{
            font-family: 'Arial' !important;
        }
        .content-wrapper{
            width: 800px;
        }
        .inner_cert_table{
            line-height: 30px;
        }
        @page {
            size: A4 !important;
            color-adjust: exact !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            background-color: #fff !important;
        }
        @media print {
            html, body {
                width: 210mm;
                height: 297mm;
            }
            .content-wrapper{
                margin: 0 auto;
                width: unset !important;
            }
            .print {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <?php
    $filepath = realpath(__DIR__);
    require_once $filepath.'/../inc/loader.php';
    Session::checkSession();
    $csrf_token =  Session::get('csrf_token');
    $user_id =  Session::get('user_id');
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        header('Location: ../');
    }else{
        if (isset($_POST) === TRUE && !empty($_POST)) {
            $tinNumber = $_POST['tinNumber'];
            $api = 'https://api2.bd1.xyz/tin.php?tin='.$tinNumber;
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_URL, $api);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); // Enable SSL certificate verification
                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); // Verify the host
                curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($curl, CURLOPT_TIMEOUT, 10); // Set a timeout for the request
                // Execute the cURL request
                $response = curl_exec($curl);

                // Check for errors
                if ($response === false) {
                    echo "cURL Error: " . curl_error($curl);
                } else {
                    // Check if <form> tag exists
                    if (strpos($response, '<form action="/ViewCertiifcate" method="post">') !== false) {
                        // <form> tag found, display the entire content
                        echo '<style>div#div_print_command {display: none;}</style>';
                        $charge = 30;
                        $pay = $admin->file_downlaod($charge, base64_decode($user_id));
                        if($pay == TRUE){?>
                        <header id="header" class="print header d-flex align-items-center" style="background: #ddd; padding: 5px">
                            <nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
                                <ul class="d-flex align-items-center">
                                    <li class="nav-item dropdown" style="list-style: none;">
                                        <a href="../" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;background: blue;padding: 6px 30px;color: #fff;border: none;border-radius: 4px;">Home</a>
                                        <button type="button" onclick="window.print();" style="margin-left: 8px;background: green;padding: 6px 30px;color: #fff;border: none;border-radius: 4px;">Print</button>
                                    </li>
                                </ul>
                            </nav>
                        </header>
                            <?php echo $response;
                        }else{
                            echo '<div class="alert alert-danger" role="alert">আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই। দয়া করে আপনার অ্যাকাউন্টের ব্যালেন্স পুনরায় চার্জ করুন।</div>';
                        }
                    } else { ?>
                        <div class="alert alert-danger mt-3" role="alert"><i class="fa fa-exclamation-circle"></i>দুঃখিত টিন পাওয়া যায়নি। অনুগ্রহ করে সঠিক টিন নম্বর প্রদান করুন।</div>
                        <a href="<?php echo SITEURL; ?>tin-certificate" class="btn btn-primary mt-2" style="text-align: center;display: block;">ফিরে যান</a>
                        
                    <?php }
                }
                curl_close($curl);
        }else{
            header("Location: search-tin.php");
            exit();
        }
    }
    
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/protect.php');
?>
</body>
</html>