<?php include('inc/header.php'); ?>
<main id="main" class="main">

  <div class="pagetitle">
    <h1>Surokkha</h1>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="container">
    </div>
  </section>
</main>
<?php include('inc/footer.php'); ?>