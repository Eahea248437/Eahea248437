<?php $filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
    	$error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Access denied! Unauthorized process.</div>';
    }else{
        if (isset($_POST) === TRUE && !empty($_POST)) {
            function validation($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            
            $nid = validation($_POST['nid']);
            $dob = validation($_POST['dob']);
            
            $url = 'https://taka.bet/server/17digit.php?nid='.$nid.'&dob='.date('Y-m-d', strtotime($dob));
            // Initialize cURL session
            $ch = curl_init($url);
            
            // Set cURL options
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            // Execute cURL session and get the HTML content
            $html = curl_exec($ch);
            
            // Check for cURL errors
            if (curl_errno($ch)) {
                echo 'Curl error: ' . curl_error($ch);
                exit;
            }
            
            // Close cURL session
            curl_close($ch);
            
            // Remove HTML tags and extract specific data using regular expressions
            $pattern = "/<strong>([^<]+)<\/strong>\s*([^<]+)<br>/";
            preg_match_all($pattern, $html, $matches);
            
            // Create an associative array with extracted data
            $extractedData = array_combine($matches[1], $matches[2]);
            
            // Get HTTP response code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        }else{
            $error = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Server error...</div>';
        }
    }
}
?>
<style>
.info-container {
    border: 1px solid #ccc;
    border-radius: 10px;
    padding: 10px;
    margin: 20px;
}

.info-item {
    font-size: 18px;
    margin-bottom: 10px;
}
.error-message {
    color: red;
    font-weight: bold;
    margin-top: 10px;
}
</style>
<main id="main" class="main">
  <div class="pagetitle">
    <h1>NID Smart ID Info - ৳ Free</h1>
  </div>

  <section class="section">
    <div class="container">
    <h3 style="text-align: center; border: 1px solid darkblue; padding: 18px 5px; font-size: 22px; min-width: 285px; margin: 5px; margin-bottom: 32px; border-radius: 10px; background: darkblue; color: #fff;">এখান থেকে ১৩ ডিজিট এবং ১৭ ডিজিট থেকে ১০ ডিজিট নাম্বার সংগ্রহ করুন ফ্রিতে।</h3>
      <?php if(isset($error)){ echo $error; } ?>
      <form id="search-form" action="" method="POST">
        <div class="form-group mb-3">
            <label class="form-label">NID No:</label>
            <input class="form-control" type="text" name="nid" id="nid" placeholder="Enter your 13 or 17 digit NID number" required="">
        </div>
         <div class="form-group mb-3">
             <label class="form-label">Date of Brith:</label>
            <input class="form-control" type="date" name="dob" id="dob" required="">
        </div>
        <button type="submit" style="width: 40%;" class="btn btn-success d-block m-auto mt-5">Search</button>
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
      </form>
        <div class="container">
            <?php if(isset($extractedData['name:'])){ echo '<div class="info-container"><p class="info-item"><b>Name (BN):</b> '.$extractedData['name:'].'</p>'; } ?>
            <?php if(isset($extractedData['nameEn:'])){ echo '<p class="info-item"><b>Name (EN):</b> '.$extractedData['nameEn:'].'</p>'; } ?>
            <?php if(isset($extractedData['nid:'])){ echo '<p class="info-item"><b>NID NO:</b> '.$extractedData['nid:'].'</p>'; } ?>
            <?php if(isset($extractedData['smartId:'])){ echo '<p class="info-item"><b>Smart ID:</b> '.$extractedData['smartId:'].'</p>'; } ?>
            <?php if(isset($extractedData['dob:'])){ echo '<p class="info-item"><b>Date of Brith:</b> '.$extractedData['dob:'].'</p>'; } ?>
            <?php if(isset($extractedData['address:'])){ echo '<p class="info-item"><b>Present Address:</b> '.$extractedData['address:'].'</p>'; } ?>
            <?php if(isset($extractedData['addressPerm:'])){ echo '<p class="info-item"><b>Permanent Address:</b> '.$extractedData['addressPerm:'].'</p></div>'; } ?>
        </div>
    </div>
  </section>
</main>
<?php
require_once($filepath.'/../inc/footer.php');
?>