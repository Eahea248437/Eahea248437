<?php
$page = 'nid-server-copy';
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/header.php');
?>
<main id="main" class="main">
  <div class="pagetitle">
    <h1>এনআইডি সার্ভার কপি - ৳ 20</h1>
  </div>
  <section class="section">
    <div class="container">
    <?php
      if($default_amount >= $get_user['amount']){
          echo $fund = '<div class="alert alert-danger" role="alert">আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই। দয়া করে আপনার অ্যাকাউন্টের ব্যালেন্স পুনরায় চার্জ করুন।</div>';
      }

      if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
      }
    
       // Form submission handling
       if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            $submit = '<div class="alert alert-danger" role="alert"><i class="fa fa-exclamation-circle"></i> Access not allowed!</div>';
        } else {
            $nid = $_POST['nid'];
            $dob = $_POST['dob'];

            // Validate the NID and DOB
            
        }
        if (isset($submit)) {echo $submit;}
    }
      ?>
      <h3 style="text-align: center; border: 1px solid darkblue; padding: 18px 5px; font-size: 22px; min-width: 285px; margin: 5px; margin-bottom: 32px; border-radius: 10px; background: darkblue; color: #fff;">সঠিক তথ্য সাবমিট করুন পিডিএফ ডাউনলোড করার জন্য</h3>
      <form id="search-form" action="view-new" method="POST">
        <label class="form-label" for="nid">এনআইডি নং:</label>
        <input class="form-control" type="text" name="nid" id="nid" placeholder="আপনার এনআইডি নং দিন" required><br>

        <label class="form-label" for="dob">জন্ম তারিখ:</label>
        <input class="form-control" type="date" name="dob" id="dob" required><br>
        <button type="submit" style="width: 40%;" class="btn btn-success d-block m-auto mt-5">Search</button>
        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
      </form>
    </div>
  </section>
</main>
<?php
require_once($filepath.'/../inc/footer.php');
?>