<?php
$filepath = realpath(__DIR__);
require_once $filepath.'/../inc/loader.php';
Session::checkSession();
$csrf_token =  Session::get('csrf_token');
$user_id =  Session::get('user_id');
$default_amount = 10;
$get_user = $admin->user_by_id(base64_decode($user_id))->fetch_assoc();
if($default_amount > $get_user['amount']){
    header('Location: ../');
}else{
	if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
	    header('Location: ../');
	}
}

$nid = isset( $_POST['nid'] ) ? $_POST['nid'] : '';
$dob = isset( $_POST['dob'] ) ? $_POST['dob'] : '';

// Include the Simple HTML DOM Parser library
// $filepath = realpath(__DIR__);
// require_once($filepath.'/../inc/simple_html_dom.php');

// URL of the website to scrape
//$url = 'https://taka.bet/server/17digit.php?nid=8263048111&dob=2000-09-28';

// $url_17digit = 'https://taka.bet/server/17digit.php?nid='.$nid.'&dob='.date('Y-m-d', strtotime($dob));

// // Create a DOM object
// $html = file_get_html($url_17digit);

// // Find the specific div by its ID
// $targetDiv = $html->find('#result', 0);

// // Display the content of the div
// if ($targetDiv) {
//     //echo $targetDiv->innertext;

//     // Get the content of the div
//     $content = $targetDiv->innertext;

//     // Remove <br> tags and trim spaces
//     $content = str_replace('<br>', '', $content);
//     $content = trim($content);

//     // Extract JSON data
//     $jsonData = substr($content, strpos($content, '{'));

//     // Decode the JSON string
//     $decodedData = json_decode($jsonData, true);

//     // Check if decoding was successful
//     if ($decodedData !== null) {
//         // Access and display individual data fields
//         // 'Name: ' . $decodedData['data']['name'] . '<br>';
//         // 'English Name: ' . $decodedData['data']['nameEn'] . '<br>';
//         // 'NID: ' . $decodedData['data']['nid'] . '<br>';
//         // 'Smart ID: ' . $decodedData['data']['smartId'] . '<br>';
//         // 'Date of Birth: ' . $decodedData['data']['dob'] . '<br>';
//         // 'Address: ' . $decodedData['data']['address'] . '<br>';
//         // 'Permanent Address: ' . $decodedData['data']['addressPerm'] . '<br>';

// 		$smartId = $decodedData['data']['smartId'];
// 		$smartDob = $decodedData['data']['dob'];
//     } else {
//         echo 'Error decoding JSON.';
//     }
// } else {
//     echo 'Div not found.';
// }

//////


$url = 'https://maclinic.xyz/nid-new/api.php?nid='.$nid.'&dob='.date("d-m-Y", strtotime($dob));
//$url = 'https://maclinic.xyz/nid-new/api.php?nid='.'4639647835'.'&dob='.'11-02-1995';
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
));
$content = curl_exec($curl);
curl_close($curl);
$content = json_decode($content);

$name = '';
$name_en = '';
$father = '';
$mother = '';
$blood = '';
$gender = '';
$nid_no = '';
$spouse = '';
$pin = '';
$voter_area = '';
$voter_no = '';
$present_a = '';
$permanent_a = '';
$mobile = '';
$religion = '';
$bplace = '';
$date_of_birth = '';
if (  isset($content->success) && $content->success == true  ){
	$charge = 10;
	$admin->file_downlaod($charge, base64_decode($user_id));
    $nid_no = $content->nid_no;
    $date_of_birth = date('d F Y', strtotime($content->dob));
    $name = $content->name_bn;
    $name_en = $content->name_en;
    $father = $content->fathers_name;
    $mother = $content->mothers_name;
    $blood = $content->blood_grp;
    if ( strtolower($content->gender) == '1' ){
    $gender = 'পুরুষ';
    }
    elseif ( strtolower($content->gender) == '2' ){
    $gender = 'মহিলা';
    }
    
    $spouse = $content->spouse;
    $pin =  $content->voter_area;
    $voter_area = $content->district;
    $voter_no = '';
    $present_a = $content->present_addr;
    $permanent_a = $content->permanent_addr;
    $mobile = $content->mobile;
    $religion = $content->religion;
    $bplace = $content->district;
    $upazila = $content->upazila;
    
    $qr_data = "$name $nid $dob";
    // include 'qr/index.php';
    // $qr = '$qr_data';
    
    $photo = $content->photo;
?>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link href="fonts/kalpurush.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/print.min.css">
	<style>
	*, html, body, p{
		font-family: 'Kalpurush', sans-serif !important;
	}
	@page {
		size: A4;
		margin: 0px;
	}

	body {
		margin: 0;
	}

	.background {
		background-color: lightgrey;
		position: relative;
		width: 750px;
		height: 1065px;
		margin: auto;
	}

	.crane {
		max-width: 100%;
		height: 100%;
	}

	.topTitle {
		position: absolute;
		left: 21%;
		top: 8%;
		width: auto;
		font-size: 42px;
		color: rgb(255, 182, 47);
	}

	#loadMe {
		visibility: hidden;
	}

	@media print {
		html,body {
			width: 210mm;
			height: 297mm;
			background-color: #fff !important;
		}

		.print {
			display: none !important;
		}
	}

#print {

    background: #03a9f4;
    padding: 8px;
    width: 700px;
    height: 40px;
    border: 0px;
    font-size: 25px;
    font-weight: bold;
    cursor: pointer;
    box-shadow: 1px 4px 4px #878787;
    color: #fff;
    border-radius: 10px;
    margin: 20px;
    display: none;
}
#present_addr, #permanent_addr {
    text-align: left;
}
	</style>
	    <style>
        .print-button {
            position: absolute;
            left: 89%;
            top: 11.55%;
            width: auto;
            font-size: 11px;
            color: #fff;
            cursor: pointer;
        }
    </style>

<style type="text/css" media="print">
         @media print {
            @page {
               margin-top: 0;
               margin-bottom: 0;
               size: A4 !important;
               color-adjust: exact !important;
               -webkit-print-color-adjust: exact !important;
               print-color-adjust: exact !important;
               background-color: #fff !important;
            }
            body {
               padding-top: 0px;
               padding-bottom: 72px;
            }
            .print {
               display: none !important;
            }
         }
         body {
            position: relative;
         }
      </style>
</head>
<body>
      <!-- ======= Header ======= -->
      <header id="header" class="print header d-flex align-items-center" style="background: #ddd; padding: 5px">
         <nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
            <ul class="d-flex align-items-center">
               <li class="nav-item dropdown" style="list-style: none;">
                  <a href="<?php echo SITEURL; ?>" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;">Home</a>
                  <button type="button" onclick="window.print();" class="btn btn-success mb-2 mt-2" style="margin-left: 8px;">Print</button>
               </li>
            </ul>
         </nav>
         <!-- End Icons Navigation -->
      </header>
      <!-- End Header -->
<div class="background">
	<img class="crane" src="cb.jpg" height="1000px" width="750px">
	<div style="position: absolute; left: 30%; top: 8%;width: auto;font-size: 16px; color: rgb(255 224 0);"><b>National Identity Registration Wing (NIDW)</b></div>
	<div style="position: absolute; left: 37%; top: 11%;width: auto;font-size: 14px; color: rgb(255, 47, 161);"><b>Select Your Search Category</b></div>
	<div style="position: absolute; left: 45%; top: 12.8%;width: auto;font-size: 12px; color: rgb(8, 121, 4);">Search By NID / Voter No.</div>
	<div style="position: absolute; left: 45%; top: 14.3%;width: auto;font-size: 12px; color: rgb(7, 119, 184);">Search By Form No.</div>
	<div style="position: absolute; left: 30%; top: 16.9%;width: auto;font-size: 12px; color: rgb(252, 0, 0);"><b>NID or Voter No*</b></div>
	<div style="position: absolute; left: 45%; top: 16.9%; width: auto; font-size: 12px; color: rgb(143, 143, 143);"><?php echo $nid_no;?></div>
	<div style="position: absolute;left: 62.9%;top: 17.1%;width: auto;font-size: 11px;color: rgb(255 255 255);">Submit</div>
    <div class="print-button" onclick="window.print();">Print</div>
	<div style="position: absolute; left: 37%; top: 27%; width: auto; font-size: 16px; color: rgb(7, 7, 7);"><b>জাতীয় পরিচিতি তথ্য</b></div>
	<div style="position: absolute; left: 37%; top: 29.7%; width: auto; font-size: 13px; color: rgb(7, 7, 7);">জাতীয় পরিচয় পত্র নম্বর</div>
	<div id="nid_no" style="position: absolute; left: 55%; top: 29.7%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $nid_no;?></div>
	<div style="position: absolute; left: 37%; top: 32.5%; width: auto; font-size: 13px; color: rgb(7, 7, 7);">পিন নাম্বার</div>
	<div id="nid_father" style="position: absolute; left: 55%; top: 32.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $pin;?></div>
	<div style="position: absolute; left: 37%; top: 35%; width: auto; font-size: 13px; color: rgb(7, 7, 7);">স্বামী/স্ত্রীর নাম</div>
	<div id="nid_mother" style="position: absolute; left: 55%; top: 35%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $spouse;?></div>
	<div style="position: absolute; left: 37%; top: 37.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">স্মার্ট কার্ড নাম্বার</div>
	<div id="spouse" style="position: absolute; left: 55%; top: 37.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $nid_no;?></div>
	<div style="position: absolute; left: 37%; top: 40.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">ভোটার এলাকা</div>
	<div id="voter_area" style="position: absolute; left: 55%; top: 40.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $voter_area;?></div>
	<div style="position: absolute; left: 37%; top: 43%; width: auto; font-size: 16px; color: rgb(7, 7, 7);"><b>ব্যক্তিগত তথ্য</b></div>
	<div style="position: absolute; left: 37%; top: 45.6%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><b>নাম (বাংলা)<b></div>
	<div id="name_bn" style="position: absolute; font-weight: bold; left: 55%; top: 45.6%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><b><?php echo $name;?><b></div>
	<div style="position: absolute; left: 37%; top: 48.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">নাম (ইংরেজি)</div>
	<div id="name_en" style="position: absolute; left: 55%; top:48.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $name_en;?></div>
	<div style="position: absolute; left: 37%; top: 51%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">জন্ম তারিখ</div>
	<div id="dob" style="position: absolute; left: 55%; top: 51%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $date_of_birth;?></div>
	<div style="position: absolute; left: 37%; top: 53.7%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">পিতার নাম</div>
	<div id="fathers_name" style="position: absolute; left: 55%; top: 53.7%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $father;?></div>
	<div style="position: absolute; left: 37%; top: 56.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">মাতার নাম</div>
	<div id="mothers_name" style="position: absolute; left: 55%; top: 56.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $mother;?></div>
	<div style="position: absolute; left: 37%; top: 59%; width: auto; font-size: 16px; color: rgb(7, 7, 7);"><b>অন্যান্য তথ্য</b></div>
	<div style="position: absolute; left: 37%; top: 62.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">লিঙ্গ</div>
	<div id="gender" style="position: absolute; left: 55%; top: 62.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $gender;?></div>
	<div style="position: absolute; left: 37%; top: 64.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">মোবাইল নম্বর</div>
	<div id="mobile_no" style="position: absolute; left: 55%; top: 64.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $mobile;?></div>
	<div style="position: absolute; left: 37%; top: 67.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">ধর্ম</div>
	<div id="blood_grp" style="position: absolute; left: 55%; top: 67.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo ucfirst($religion); ?></div>
	<div style="position: absolute; left: 37%; top: 70%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">জন্মস্থান</div>
	<div id="birth_place" style="position: absolute; left: 55%; top: 70%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $bplace;?></div>
	<div style="position: absolute; left: 37%; top: 72.8%; width: auto; font-size: 16px; color: rgb(7, 7, 7);"><b>বর্তমান ঠিকানা</b></div>
	<div id="present_addr" style="position: absolute; left: 37%; top: 75.5%; width: 48%; font-size: 12px; color: rgb(7, 7, 7);"><?php echo $present_a;?></div>
	<div style="position: absolute; left: 37%; top: 81.5%; width: auto; font-size: 16px; color: rgb(7, 7, 7);"><b>স্থায়ী ঠিকানা</b></div>
	<div id="permanent_addr" style="position: absolute; left: 37%; top: 84.3%; width: 48%; font-size: 12px; color: rgb(7, 7, 7);"><?php echo $permanent_a;?></div>
	<div style="position: absolute;top: 92%;width: 100%;font-size: 12px;text-align: center;color: rgb(255, 0, 0);">উপরে প্রদর্শিত তথ্যসমূহ জাতীয় পরিচয়পত্র সংশ্লিষ্ট, ভোটার তালিকার সাথে সরাসরি সম্পর্কযুক্ত নয়।</div>
	<div style="position: absolute;top: 93.5%;width: 100%;text-align: center;font-size: 12px;color: rgb(3, 3, 3);">This is Software Generated Report From Bangladesh Election Commission, Signature &amp; Seal Aren't Required.</div>
	<div style="position: absolute;  left: 16%; top: 25.7%; width: auto; font-size: 12px; color: rgb(3, 3, 3);">
	   <img id="photo" src="<?php echo $photo;?>" height="140px" width="121px" style="border-radius: 10px"></div>
	<div style="position: absolute;  left: 17.5%; top: 44%; width: auto; font-size: 12px; color: rgb(3, 3, 3);">
	 <img id="qr" src="<?php echo 'https://chart.googleapis.com/chart?choe=UTF-8&cht=qr&chld=H|0&chs=150x150&chl='.$qr_data ?>" height="100px" width="100px"></div>
	<div id="name_en2" style="position: absolute;font-weight: bold;left: 15.5%;top: 39.6%;height: 32px;width: 130px;font-size: 13px;color: rgb(7, 7, 7);margin: auto;align-items: center;" align="center"><?php echo $name_en; ?></div>
</div>
<?php } else{?>
      <!-- ======= Header ======= -->
      <header id="header" class="print header d-flex align-items-center" style="background: #ddd; padding: 5px">
         <nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
            <ul class="d-flex align-items-center">
               <li class="nav-item dropdown" style="list-style: none;">
                  <a href="../" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;background: blue;padding: 6px 30px;color: #fff;border: none;border-radius: 4px;">Home</a>
               </li>
            </ul>
         </nav>
         <!-- End Icons Navigation -->
      </header>
    <h1>তথ্য পাওয়া যায়নি। দায়া করে আবার চেষ্টা করুন।</h1>
<?php } ?>
<?php
$filepath = realpath(__DIR__);
require_once($filepath.'/../inc/protect.php');
?>
</body>
</html>