<?php
error_reporting(0);
$filepath = realpath(__DIR__);
require_once $filepath.'/../inc/loader.php';
Session::checkSession();
$csrf_token =  Session::get('csrf_token');
$user_id =  Session::get('user_id');
$default_amount = 10;
$get_user = $admin->user_by_id(base64_decode($user_id))->fetch_assoc();
if($default_amount > $get_user['amount']){
    header('Location: ../');
}else{
	if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
	    header('Location: ../');
	}
}
?>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link href="fonts/kalpurush.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo SITEURL ?>assets/css/nid/print.min.ss">
	<link rel="stylesheet" href="<?php echo SITEURL ?>/nid-server-copy/print.css">
</head>
<body class="container">
<?php 
// API endpoint
$nid = isset($_POST['nid']) ? trim($_POST['nid']) : ''; //4639647835
$dob = isset($_POST['dob']) ? trim($_POST['dob']) : ''; //1995-02-11
$submit = $admin->chk_nidServer($nid, $dob);
if(!$submit){
    // Define the API endpoint and parameters
    $url = "https://apiv1.xyz/nid-api?nid=$nid&dob=$dob";

    // Initialize cURL session
    $ch = curl_init();
    // Set the URL and other options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Enable SSL verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // Verify the host

    // Execute the cURL request and get the response
    $response = curl_exec($ch);

    // Check for errors
    if ($response === false) {
        $error = curl_error($ch);
        echo "<tr><td colspan='2'>cURL Error: $error</td></tr>";
    } else {
        // Decode the JSON response
        $data = json_decode($response, true);

        // Check if the request was successful
        if ($data['status'] == 'success') {
            $charge = 20;
            $admin->file_downlaod($charge, base64_decode($user_id));
            // Helper function to handle empty fields
            function checkField($field) {
                return isset($field) && !empty($field) ? $field : 'N/A';
            }
?>
	<!-- ======= Header ======= -->
	<header id="header" class="print header d-flex align-items-center" style="background: #ddd;padding: 5px;margin-bottom: 30px;">
		<nav class="header-nav ms-auto" style="margin: 0 auto;display: block;width: max-content;">
		<ul class="d-flex align-items-center" style="margin: 0;">
			<li class="nav-item dropdown" style="list-style: none;">
				<a href="<?php echo SITEURL; ?>" class="btn btn-primary mb-2 mt-2" style="margin-left: 8px;">Home</a>
				<button type="button" onclick="window.print();" class="btn btn-success mb-2 mt-2" style="margin-left: 8px;">Print</button>
			</li>
		</ul>
		</nav>
		<!-- End Icons Navigation -->
	</header>
	<!-- End Header -->
	<div class="background">
    	<img class="crane" src="cb11.png" height="1000px" width="750px">
    <div class="print-button" onclick="window.print();">Print</div>
    	<div id="name_en2" style="position: absolute;font-weight: bold;left: 34%;top: 29%;height: 32px;width: 250px;font-size: 13px;color: rgb(7, 7, 7);margin: auto;align-items: center;" align="center"> <?php echo checkField($data['nameEn']); ?>
	</div>
    <div style="position: absolute;font-weight: bold; left: 11%; top: 33.8%; width: auto; font-size: 16px; color: rgb(7, 7, 7);">
        <b>জাতীয় পরিচিতি তথ্য</b>
    </div>
    <div style="position: absolute;font-weight: bold; left: 11%; top: 36.8%; width: auto; font-size: 13px; color: rgb(7, 7, 7);">জাতীয় পরিচয় পত্র নম্বর</div>
    <div id="nid_no" style="position: absolute;font-weight: bold; left: 32%; top: 36.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo checkField($data['nidNo']); ?> </div>
    <div style="position: absolute;font-weight: bold; left: 11%; top: 39.8%; width: auto; font-size: 13px; color: rgb(7, 7, 7);">পিন নাম্বার</div>
    <div id="nid_father" style="position: absolute;font-weight: bold; left: 32%; top: 39.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo checkField($data['nidNo']); ?> </div>
    <div style="position: absolute; font-weight: bold; left: 11%; top: 42.3%; width: auto; font-size: 13px; color: rgb(7, 7, 7);">ফরম নাম্বার </div>
    <div id="nid_father" style="position: absolute; font-weight: bold; left: 32%; top: 42.3%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo 'NIDFN' . sprintf('%06d', rand(0, 999999)); ?> </div>
    <div style="position: absolute;font-weight: bold; left: 11%; top: 67%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">স্বামী/স্ত্রীর নাম</div>
    <div id="nid_mother" style="position: absolute; font-weight: bold;left: 32%; top: 67%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"></div>
    <div style="position: absolute;font-weight: bold; left: 11%; top: 44.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">ভোটার নম্বার</div>
    <div id="voter_number" style="position: absolute; font-weight: bold; left: 32%; top: 44.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo sprintf('%08d', rand(0, 999999)); ?> </div>
    <div style="position: absolute;font-weight: bold; left: 11%; top: 47.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">ভোটার এলাকা</div>
    <div id="voter_area" style="position: absolute;font-weight: bold; left: 32%; top: 47.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo checkField($data['presentAddress']['villageOrRoad']); ?> </div>
    <div style="position: absolute; left: 11%; top: 50.5%; width: auto; font-size: 16px; color: rgb(7, 7, 7);">
        <b>ব্যক্তিগত তথ্য</b>
    </div>
    <div style="position: absolute; left: 11%; top: 53.1%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">
        <b>নাম (বাংলা) <b></b>
        </b>
    </div>
    <div id="name_bn" style="position: absolute; font-weight: bold; left: 32%;;; top: 53.1%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">
        <b> <?php echo checkField($data['nameBn']); ?> </b>
    </div>
    <b>
        <div style="position: absolute; left: 11%; top: 56%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">নাম (ইংরেজি)</div>
        <div id="name_en" style="position: absolute; left: 32%; top:56%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo checkField($data['nameEn']); ?> </div>
        <div style="position: absolute; left: 11%; top:59%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">জন্ম তারিখ</div>
        <div id="dob" style="position: absolute; left: 32%; top: 59%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo $data['dateOfBirth']; ?> </div>
        <div style="position: absolute; left: 11%; top: 61.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">পিতার নাম</div>
        <div id="fathers_name" style="position: absolute; left: 32%; top: 61.5%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo checkField($data['fatherName']); ?> </div>
        <div style="position: absolute; left: 11%; top: 64.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">মাতার নাম</div>
        <div id="mothers_name" style="position: absolute; left: 32%; top: 64.2%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo checkField($data['motherName']); ?> </div>
        <div style="position: absolute; left: 11%; top: 69.5%; width: auto; font-size: 16px; color: rgb(7, 7, 7);"><b>অন্যান্য তথ্য</b></div>
        <div style="position: absolute; left: 11%; top: 72.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">লিঙ্গ</div>
        <div id="gender" style="position: absolute; left: 32%; top: 72.8%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo ($data['gender'] === 'male') ? 'পুরুষ' : (($data['gender'] === 'female') ? 'মহিলা' : 'তথ্য নাই'); ?> </div>
        <div style="position: absolute; left: 11%; top: 75.3%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">শিক্ষাগত যোগ্যতা </div>
        <div id="mobile_no" style="position: absolute; left: 32%; top: 75.3%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"> তথ্য নাই </div>
        <div style="position: absolute; left: 11%; top: 78%; width: auto; font-size: 14px; color: rgb(7, 7, 7);">জন্মস্থান</div>
        <div id="birth_place" style="position: absolute; left: 32%; top: 78%; width: auto; font-size: 14px; color: rgb(7, 7, 7);"><?php echo $data['permanentAddress']['district'];?></div>
        <div style="position: absolute; left: 11%; top: 80.8%; width: auto; font-size: 16px; color: rgb(7, 7, 7);">
            <b>বর্তমান ঠিকানা</b>
        </div>
        <div id="present_addr" style="position: absolute; left: 11%; top: 83.8%; width: 80%; font-size: 14px; color: rgb(7, 7, 7);"> 
        <?php echo $data['presentAddress']['villageOrRoad'].', '.$data['presentAddress']['homeHolding']. ', '.$data['presentAddress']['mouzaMoholla']. ', '.$data['presentAddress']['mouzaMoholla'].', '.$data['presentAddress']['upazila']. ', '. $data['presentAddress']['postOffice'].'-'.$data['presentAddress']['postalCode']. ', '.$data['presentAddress']['district'].', '.$data['presentAddress']['division']; ?>
        </div>
        <div style="position: absolute; left: 11%; top: 88%; width: auto; font-size: 16px; color: rgb(7, 7, 7);">
            <b>স্থায়ী ঠিকানা</b>
        </div>
        <div id="permanent_addr" style="position: absolute; left: 11%; top: 91%; width: 80%; font-size: 14px; color: rgb(7, 7, 7);"> <?php echo $data['permanentAddress']['villageOrRoad'].', '.$data['permanentAddress']['homeHolding']. ', '.$data['permanentAddress']['mouzaMoholla']. ', '.$data['permanentAddress']['mouzaMoholla'].', '.$data['permanentAddress']['upazila']. ', '. $data['permanentAddress']['postOffice'].'-'.$data['permanentAddress']['postalCode']. ', '.$data['permanentAddress']['district'].', '.$data['permanentAddress']['division']; ?></div>
        <div style="position: absolute;  left: 42%; top: 15.7%; width: auto; font-size: 12px; color: rgb(3, 3, 3);">
            <img id="photo" src="<?php echo checkField($data['photo']); ?>" height="140px" width="121px" style="border-radius: 10px">
        </div>
        <div style="position: absolute;  left: 17.5%; top: 44%; width: auto; font-size: 12px; color: rgb(3, 3, 3);"></div>
    </b>
</div>
<?php
        } else {?>
        <div class="alert alert-danger mt-3" role="alert"><i class="fa fa-exclamation-circle"></i>দুঃখিত এনআইডি পাওয়া যায়নি। অনুগ্রহ করে সঠিক টিন নম্বর প্রদান করুন।</div>
        <a href="<?php echo SITEURL; ?>nid-server-copy" class="btn btn-primary mt-2" style="text-align: center;display: block;">ফিরে যান</a>
        <?php }
    }
    // Close the cURL session
    curl_close($ch);
}else{?>
    <div class="mt-3"><?php echo $submit; ?></div>
    <a href="<?php echo SITEURL; ?>nid-server-copy" class="btn btn-primary mt-2" style="text-align: center;display: block;">ফিরে যান</a>
<?php }

$filepath = realpath(__DIR__);
//require_once($filepath.'/../inc/protect.php');
?>
</body>
</html>