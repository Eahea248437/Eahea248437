<?php
session_start(); // Start the session

// Bypass2 API URL
$url = "https://apiv1.xyz/cdms/access/Bypass2.php";
$timeout = '1800'; // 30 min

// Check if the session has a timestamp and if it is within the 30-minute window
if (isset($_SESSION['bypass2_start_time']) && (time() - $_SESSION['bypass2_start_time']) < $timeout && isset($_SESSION['bypass2_data']) && $_SESSION['bypass2_data']['P0_CURR_URL'] === "CDMS") {
    // If within 5 minutes and "CDMS" was found, directly proceed to NID API
    $data = $_SESSION['bypass2_data']; // Retrieve the session data
} else {
    // Initialize a cURL session for Bypass2 API
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the response as a string
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow any redirects
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); // Set content type to JSON

    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        // Return JSON error response
        $errorResponse = array("error" => curl_error($ch));
        header('Content-Type: application/json');
        echo json_encode($errorResponse);
        exit;
    }

    // Decode the JSON response into an associative array
    $data = json_decode($response, true);

    // If the response contains "CDMS"
    if (isset($data['P0_CURR_URL']) && $data['P0_CURR_URL'] === "CDMS") {
        // Store data in the session
        $_SESSION['bypass2_start_time'] = time(); // Set session start time
        $_SESSION['bypass2_data'] = $data; // Store the API response

        // Proceed with the NID API logic
    }

    // Close the cURL session
    curl_close($ch);
}

// NID API logic, which will run if "CDMS" was found within 5 minutes or after the time expires
if (isset($data['P0_CURR_URL']) && $data['P0_CURR_URL'] === "CDMS") {
    $nid = $_GET['nid'];
    $dob = $_GET['dob'];

    // URL of the API page with validated parameters
    $url = "https://apiv1.xyz/cdms/api.php?" . http_build_query(['nid' => $nid, 'dob' => $dob]);

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the output instead of outputting it directly
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Follow redirects if any
    curl_setopt($ch, CURLOPT_TIMEOUT, 30); // Timeout in seconds

    // Execute the cURL session and fetch the response
    $response = curl_exec($ch);

    // Check for cURL errors
    if ($response === false) {
        die(json_encode(['error' => 'Error fetching the content from the URL: ' . curl_error($ch)]));
    }

    // Close the cURL session
    curl_close($ch);

    // Create a new DOMDocument object
    $dom = new DOMDocument;

    // Suppress warnings due to invalid HTML
    libxml_use_internal_errors(true);

    // Load the HTML into the DOMDocument object
    $dom->loadHTML($response);

    // Clear errors
    libxml_clear_errors();

    // Create a new DOMXPath object
    $xpath = new DOMXPath($dom);

    // Data extraction
    $data = [];

    // Personal fields
    $data['status'] = 'success';
    $data['photo'] = $xpath->query("//input[@id='P600_PATH']")->item(0)->getAttribute('value');
    $data['nidNo'] = $xpath->query("//span[@id='P600_NID']")->item(0)->nodeValue;
    $data['nameBn'] = $xpath->query("//span[@id='P600_PERSON_NAME']")->item(0)->nodeValue;
    $data['nameEn'] = $xpath->query("//span[@id='P600_PERSON_NAME_ENG']")->item(0)->nodeValue;
    $data['fatherName'] = $xpath->query("//span[@id='P600_FATH_NM']")->item(0)->nodeValue;
    $data['motherName'] = $xpath->query("//span[@id='P600_MOTH_NM']")->item(0)->nodeValue;
    $data['dateOfBirth'] = $xpath->query("//span[@id='P600_APP_BORNYEAR']")->item(0)->nodeValue;
    $data['bloodGroup'] = $xpath->query("//span[@id='P600_BLOOD_GR']")->item(0)->nodeValue;
    $data['gender'] = $xpath->query("//span[@id='P600_GEND']")->item(0)->nodeValue;

    // Permanent address fields
    $data['permanentAddress'] = [
        "division" => $xpath->query("//span[@id='P600_DIVISION']")->item(0)->nodeValue,
        "district" => $xpath->query("//span[@id='P600_DISTRICT']")->item(0)->nodeValue,
        "upazila" => $xpath->query("//span[@id='P600_UPOZILA']")->item(0)->nodeValue,
        "mouzaMoholla" => $xpath->query("//span[@id='P600_ADDITIONALMOUZAORMOHOLLA']")->item(0)->nodeValue,
        "villageOrRoad" => $xpath->query("//span[@id='P600_ADDI_VILL_OR_ROAD']")->item(0)->nodeValue,
        "homeHolding" => $xpath->query("//span[@id='P600_HOMEORHOLDINGNO']")->item(0)->nodeValue,
        "region" => $xpath->query("//span[@id='P600_REGION']")->item(0)->nodeValue,
        "postOffice" => $xpath->query("//span[@id='P600_POSTOFFICE']")->item(0)->nodeValue,
        "postalCode" => $xpath->query("//span[@id='P600_POSTALCODE']")->item(0)->nodeValue,
    ];

    // Present address fields
    $data['presentAddress'] = [
        "division" => $xpath->query("//span[@id='P600_PDIVISION']")->item(0)->nodeValue,
        "district" => $xpath->query("//span[@id='P600_PDISTRICT']")->item(0)->nodeValue,
        "upazila" => $xpath->query("//span[@id='P600_PUPOZILA']")->item(0)->nodeValue,
        "mouzaMoholla" => $xpath->query("//span[@id='P600_PADDITIONALMOUZAORMOHOLLA']")->item(0)->nodeValue,
        "villageOrRoad" => $xpath->query("//span[@id='P600_PADDI_VILL_OR_ROAD']")->item(0)->nodeValue,
        "homeHolding" => $xpath->query("//span[@id='P600_PHOMEORHOLDINGNO']")->item(0)->nodeValue,
        "region" => $xpath->query("//span[@id='P600_PREGION']")->item(0)->nodeValue,
        "postOffice" => $xpath->query("//span[@id='P600_PPOSTOFFICE']")->item(0)->nodeValue,
        "postalCode" => $xpath->query("//span[@id='P600_PPOSTALCODE']")->item(0)->nodeValue,
    ];

    // Add additional fields
    $data['admin'] = 'CyberBlack';
    $data['telegram'] = 'https://t.me/cyberblackbd';

    // Convert the extracted data to JSON format
    $json_data = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    // Print the JSON data
    header('Content-Type: application/json');
    echo $json_data;
}
?>
