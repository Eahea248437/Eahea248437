<?php
$configfile = 'config.php';
if (!file_exists($configfile)) {
    echo '<meta http-equiv="refresh" content="0; url=install" />';
    exit();
}

include "config.php";

if(!isset($_SESSION)) {
    session_start();
}

if (isset($_SESSION['sec-username'])) {
    $uname = $_SESSION['sec-username'];
    if ($uname == $settings['username']) {
        echo '<meta http-equiv="refresh" content="0; url=dashboard.php" />';
        exit;
    }
}

$_GET  = filter_input_array(INPUT_GET, FILTER_SANITIZE_SPECIAL_CHARS);
$_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_SPECIAL_CHARS);

$error = 0;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="author" content="Antonov_WEB">
		<meta name="generator" content="Cyber Black" />
		<meta name="robots" content="noindex, nofollow">
        <title>Cyber Black &rsaquo; Admin Panel</title>

        <!-- CSS -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v6.5.1/css/all.css">
		<link href="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/3.2.0/css/adminlte.min.css" rel="stylesheet">

        <!-- Favicon -->
        <link rel="shortcut icon" href="assets/img/favicon.png">
    </head>

    <body class="login-page <?php
if ($settings['dark_mode'] == 1) {
    echo 'dark-mode';
}
?>">
	<div class="login-box">
	    <form action="" method="post">

		<div class="card card-outline card-primary">
		<div class="card-header text-center">
			<h1><svg style="width: 60px;height: auto;" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="256" height="256" viewBox="0 0 256 256" xml:space="preserve"><defs></defs><g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)" ><path d="M 33.844 33.055 c 0 -6.151 5.004 -11.156 11.156 -11.156 s 11.156 5.005 11.156 11.156 S 51.151 44.21 45 44.21 S 33.844 39.206 33.844 33.055 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" /><path d="M 62.76 78.142 C 58.231 82.64 52.66 86.359 45 90 c -7.66 -3.641 -13.231 -7.36 -17.76 -11.858 v -9.476 c 0 -9.793 7.967 -17.76 17.76 -17.76 s 17.76 7.967 17.76 17.76 V 78.142 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" /><path d="M 76.953 38.15 c 0 13.831 -2.873 23.93 -7.497 31.587 v -1.07 c 0 -9.45 -5.391 -17.659 -13.256 -21.73 c 4.052 -3.275 6.652 -8.278 6.652 -13.882 c 0 -9.844 -8.009 -17.852 -17.852 -17.852 c -9.843 0 -17.852 8.009 -17.852 17.852 c 0 5.604 2.6 10.607 6.652 13.882 c -7.865 4.07 -13.256 12.28 -13.256 21.73 v 1.07 c -4.624 -7.656 -7.497 -17.756 -7.497 -31.586 V 15.899 C 23.743 14.577 34.468 9.242 45 0 c 10.533 9.242 21.256 14.577 31.953 15.899 V 38.15 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round" /></g></svg> Cyber Black</h1>
		</div>
		<div class="card">
           <div class="card-body text-white card-primary card-outline">
<?php
if (isset($_POST['signin'])) {
    $ip = addslashes(htmlentities($_SERVER['REMOTE_ADDR']));
	if ($ip == "::1") {
		$ip = "127.0.0.1";
	}
	@$date = @date("d F Y");
    @$time = @date("H:i");
    
    $username = mysqli_real_escape_string($mysqli, $_POST['username']);
    $password = hash('sha256', $_POST['password']);

    if ($username == $settings['username'] && $password == $settings['password']) {
        
        $checklh = $mysqli->query("SELECT id FROM `psec_logins` WHERE `username`='$username' AND ip='$ip' AND date='$date' AND time='$time' AND successful='1'");
        if (mysqli_num_rows($checklh) == 0) {
            $log = $mysqli->query("INSERT INTO `psec_logins` (username, ip, date, time, successful) VALUES ('$username', '$ip', '$date', '$time', '1')");
        }
        
        $_SESSION['sec-username'] = $username;
        
        echo '<meta http-equiv="refresh" content="0;url=dashboard.php">';
    } else {
        $checklh = $mysqli->query("SELECT id FROM `psec_logins` WHERE `username`='$username' AND ip='$ip' AND date='$date' AND time='$time' AND successful='0'");
        if (mysqli_num_rows($checklh) == 0) {
            $log = $mysqli->query("INSERT INTO `psec_logins` (username, ip, date, time, successful) VALUES ('$username', '$ip', '$date', '$time', '0')");
        }
        
        echo '
		<div class="alert alert-danger">
              <i class="fas fa-exclamation-circle"></i> The entered <strong>Username</strong> or <strong>Password</strong> is incorrect.
        </div>';
        $error = 1;
    }
}
?> 
			<div class="form-group has-feedback <?php
if ($error == 1) {
    echo 'has-danger';
}
?>">
            <div class="input-group mb-3">
				<input type="username" name="username" class="form-control <?php
if ($error == 1) {
    echo 'is-invalid';
}
?>" placeholder="Username" <?php
if ($error == 1) {
    echo 'autofocus';
}
?> required>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
				</div>
            </div>
			</div>
            <div class="form-group has-feedback">
			    <div class="input-group mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
				<div class="input-group-append">
                    <span class="input-group-text"><i class="fas fa-key"></i></span>
				</div>
				</div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <button type="submit" name="signin" class="btn btn-md btn-primary btn-block btn-flat"><i class="fas fa-sign-in-alt"></i>
&nbsp;Sign In</button>
                </div>
            </div>
			</div>
			</div>
        </form> 
		
		</div>
    </body>
</html>