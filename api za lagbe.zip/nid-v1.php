<?php
// Initialize a cURL session
$curl = curl_init();

// Set the URL of the API
$nid = $_GET['nid'];
$dob = $_GET['dob'];
$url = "https://apiv1.xyz/nid-api?" . http_build_query(['nid' => $nid, 'dob' => $dob]);

// Set cURL options
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); // Return the response as a string instead of outputting it
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); // Follow redirects if any

// Execute the cURL request
$response = curl_exec($curl);

// Check for errors
if (curl_errno($curl)) {
    // Output the error in JSON format
    header('Content-Type: application/json');
    echo json_encode(['error' => 'CURL Error: ' . curl_error($curl)]);
} else {
    // Decode the JSON response if needed
    $data = json_decode($response, true);
    
    // Check if JSON decoding was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        // Output the JSON decode error in JSON format
        header('Content-Type: application/json');
        echo json_encode(['error' => 'JSON Decode Error: ' . json_last_error_msg()]);
    } else {
        // Set the header to indicate this is a JSON response
        header('Content-Type: application/json');
        // Output the response in JSON format
        echo json_encode($data);
    }
}

// Close the cURL session
curl_close($curl);
?>
