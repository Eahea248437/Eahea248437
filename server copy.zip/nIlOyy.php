<?php
if (isset($_POST['clear_logs'])) {
    $file = 'NiLoY.txt';
    if (file_exists($file)) {
        $handle = fopen($file, 'w');
        fclose($handle);
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

$logEntries = file('NiLoY.txt', FILE_IGNORE_NEW_LINES);
$logEntries = array_reverse($logEntries);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=750px, initial-scale=1.0">
    <title>Log Details</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #777;
            height: 100%;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 10px;
        }
        .log-table {
            width: 100%;
            max-width: 800px;
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .table-container {
            max-height: 70vh; /* Adjust this value as needed */
            overflow-y: auto;
        }
        .table-container::-webkit-scrollbar {
            width: 8px;
        }
        .table-container::-webkit-scrollbar-thumb {
            background-color: #007bff;
            border-radius: 10px;
        }
        @media screen and (max-width: 600px) {
            .log-table {
                max-width: 90%;
            }
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: #fff;
            font-weight: bold;
            text-transform: uppercase;
        }
        td {
            background-color: #f9f9f9;
        }
        tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="log-table">
            <h1><button onclick="window.location.href='NiLoY.php';" style="all: unset; cursor: pointer;">User's History</button></h1>
            <form method="post" action="">
                <input type="submit" name="clear_logs" value="Clear Logs">
            </form>
            <div class="table-container">
                <table id="logTable">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>API Key</th>
                            <th>NID Number</th>
                            <th>Date of Birth</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($logEntries as $logEntry) {
                            $logDetails = explode(" | ", $logEntry);
                            echo "<tr>";
                            foreach ($logDetails as $index => $detail) {
                                if ($index == 4) {
                                    echo "<td class='status'>$detail</td>";
                                } else {
                                    echo "<td>$detail</td>";
                                }
                            }
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        const statusCells = document.querySelectorAll('.status');
        statusCells.forEach(cell => {
            const statusText = cell.textContent.trim();
            if (statusText === 'Success') {
                cell.style.backgroundColor = '#4CAF50';
                cell.style.color = '#fff';
            } else {
                cell.style.backgroundColor = '#f44336';
                cell.style.color = '#fff';
            }
        });

        const nidCells = document.querySelectorAll('tbody tr td:nth-child(3)');
        let prevNID = '';
        nidCells.forEach(cell => {
            if (cell.textContent.trim() === prevNID) {
                cell.style.backgroundColor = '#800080';
                cell.style.color = '#fff';
            }
            prevNID = cell.textContent.trim();
        });
    </script>
</body>
</html>