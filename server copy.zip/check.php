<?php
session_start();
$key = $_GET['key'] ?? null;
if (!$key) {
    die('নিজের Key ব্যবহার করুন.');
}
$rateLimit = 4;
$rateLimitTime = 60; 
if (!isset($_SESSION['requests'])) {
    $_SESSION['requests'] = [];
}
$currentTime = time();
$_SESSION['requests'] = array_filter($_SESSION['requests'], function($timestamp) use ($currentTime, $rateLimitTime) {
    return ($currentTime - $timestamp) < $rateLimitTime;
});
if (count($_SESSION['requests']) >= $rateLimit) {
    die('বেশি ট্রাই না করাই ভালো 😑.');
}
$_SESSION['requests'][] = $currentTime;
$data = json_decode(file_get_contents('NiLoY.json'), true);
if (!$data) {
    die('Error.');
}
$key = htmlspecialchars($key, ENT_QUOTES, 'UTF-8');
$response = '';
if (isset($data[$key])) {
    $tokenBalance = htmlspecialchars($data[$key], ENT_QUOTES, 'UTF-8');
    if ($tokenBalance == '0') {
        $response = "Sorry $key, Your Balance Is Zero. Please Kindly Recharge.";
    } else {
        $response = "Dearly $key, You're Available Balance Is $tokenBalance Token";
    }
} else {
    $response = "Sorry, $key Not Found In The Database.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Token Balance Checker</title>
    <style>
        body {
            background-color: #121212;
            color: #ffffff;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #1e1e1e;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            text-align: center;
        }
        .message {
            font-size: 1.2em;
            margin: 10px 0;
        }
        .highlight {
            color: #03a9f4;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="message"><?php echo $response; ?></div>
    </div>
</body>
</html>