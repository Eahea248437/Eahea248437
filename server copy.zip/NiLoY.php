
<?php
$filename = 'NiLoY.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $json = json_decode(file_get_contents($filename), true);

    switch ($data['action']) {
        case 'fetch':
            echo json_encode($json);
            exit;
        case 'add':
            $json[$data['key']] = $data['value'];
            file_put_contents($filename, json_encode($json));
            echo json_encode(['status' => 'success']);
            exit;
        case 'update':
            if (array_key_exists($data['key'], $json)) {
                $json[$data['key']] = $data['value'];
                file_put_contents($filename, json_encode($json));
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Key not found']);
            }
            exit;
        case 'remove':
            if (array_key_exists($data['key'], $json)) {
                unset($json[$data['key']]);
                file_put_contents($filename, json_encode($json));
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Key not found']);
            }
            exit;
        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
            exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KEY MANAGEMENT</title>
    <style>
        body { background-color: #000; color: #fff; font-family: Arial, sans-serif; }
        .container { max-width: 600px; margin: 0 auto; padding: 2px; }
        input, button { margin: 10px 0; padding: 4px; width: 30%; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 4px; border: 1px solid #fff; text-align: center; }
        td button { width: 60px; }
        h1 { text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <h1><button onclick="window.location.href='nIlOyy.php';" style="all: unset; cursor: pointer;">Control Panel</button></h1>
    <input type="text" id="key" placeholder="KEY NAME">
    <input type="number" id="value" placeholder="BALANCE">
    <button onclick="addKey()">Add Key</button>
        <table id="keyTable">
            <thead>
                <tr>
                    <th>Key</th>
                    <th>Balance</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
    <script>
        function ajaxRequest(data, callback) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    callback(JSON.parse(xhr.responseText));
                }
            };
            xhr.send(JSON.stringify(data));
        }

        function fetchKeys() {
            ajaxRequest({ action: 'fetch' }, function(response) {
                const tbody = document.querySelector('#keyTable tbody');
                tbody.innerHTML = '';
                for (const key in response) {
                    const row = `<tr>
                        <td>${key}</td>
                        <td>${response[key]}</td>
                        <td>
                            <button onclick="updateKey('${key}')">Update</button>
                            <button onclick="removeKey('${key}')">Delete</button>
                        </td>
                    </tr>`;
                    tbody.innerHTML += row;
                }
            });
        }

        function addKey() {
            const key = document.getElementById('key').value;
            const value = document.getElementById('value').value;
            ajaxRequest({ action: 'add', key: key, value: value }, fetchKeys);
        }

        function updateKey(key) {
    const value = prompt("Add Balance To " + key);
    if (value !== null && value.trim() !== '') {
        ajaxRequest({ action: 'update', key: key, value: value }, fetchKeys);
    }
}

function removeKey(key) {
    if (confirm("Are you sure you want to remove " + key + "?")) {
        ajaxRequest({ action: 'remove', key: key }, fetchKeys);
    }
}

        fetchKeys();
    </script>
</body>
</html>