<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>নির্বাচন কমিশন অধিদপ্তর</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap');
        body, html {
            margin: 0;
            font-family: 'Orbitron', sans-serif;
            background-color: #000;
            color: #fff;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background: rgba(18, 18, 18, 0.9);
            border: 1px solid #333;
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.5);
            border-radius: 15px;
            text-align: center;
            position: relative;
        }
        .logo {
            margin-bottom: 3px;
            position: absolute;
            top: -60px;
            left: 50%;
            transform: translateX(-50%);
        }
        .logo img {
            width: 100px;
            height: auto;
            border-radius: 50%;
            background: #000;
            padding: 10px;
            box-shadow: 0 0 15px rgba(0, 255, 255, 0.5);
        }
        h1 {
            color: #0ff;
            margin-bottom: 20px;
            text-shadow: 0 0 20px #0ff;
            margin-top: 48px;
            line-height: 1.2;
        }
        form {
            margin-top: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
            color: #bbb;
            text-align: left;
        }
        input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: none;
            border-radius: 5px;
            background: #333;
            color: #fff;
            font-size: 16px;
            box-shadow: inset 0 0 5px rgba(0, 255, 255, 0.5);
            transition: box-shadow 0.3s, background-color 0.3s, border 0.3s;
        }
        input[type="text"]:focus {
            border: 1px solid #0ff;
            box-shadow: 0 0 10px #0ff;
        }
        button[type="submit"] {
            width: 100%;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            background: linear-gradient(90deg, #00f, #0ff);
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s, box-shadow 0.3s;
            box-shadow: 0 0 10px rgba(0, 255, 255, 0.5);
        }
        button[type="submit"]:hover {
            background: linear-gradient(90deg, #0ff, #00f);
            box-shadow: 0 0 20px rgba(0, 255, 255, 1);
        }
        button[type="submit"]:disabled {
            background: #444;
            cursor: not-allowed;
            box-shadow: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="https://i.ibb.co/5vXXV2P/image-downloader-1713535837094.png" alt="logo">
        </div>
        <h1>নির্বাচন কমিশন অধিদপ্তর<br>(Server Copy)</h1>
        <form id="nidForm" action="ServerCopy.php" method="post">
            <label for="key">Secret Key:</label>
            <input type="text" id="key" name="key" required>
            <label for="nid">NID Number:</label>
            <input type="text" id="nid" name="nid" placeholder="জাতীয় পরিচয় পত্র নম্বর (১০/১৭)" required>
            <label for="dob">Date of Birth:</label>
            <input type="text" id="dob" name="dob" placeholder="Year-Month-Date" required>
            <button type="submit" id="submit-btn" disabled>Get ServerCopy</button>
        </form>
    </div>
<script>
    function updateNIDWithDOB() {
        const nidInput = document.getElementById('nid');
        const dobInput = document.getElementById('dob');
        if (nidInput.value.length === 13 && dobInput.value) {
            const dobYear = dobInput.value.split('-')[0];
            nidInput.value = dobYear + nidInput.value;
        }
    }

    function checkNIDLength() {
        const nidInput = document.getElementById('nid');
        const submitButton = document.getElementById('submit-btn');
        submitButton.disabled = ![10, 13, 17].includes(nidInput.value.length);
    }

    function handleInputChange() {
        updateNIDWithDOB();
        checkNIDLength();
    }

    document.getElementById('nid').addEventListener('input', handleInputChange);
    document.getElementById('dob').addEventListener('input', handleInputChange);
</script>
</body>
</html>